#!/usr/bin/env python3
"""FARO-IoT v7 toll validation: paired admit/reject counterfactuals.

For a sample of decision points (task i under seed s), the same simulation is run twice with
FARO-IoT deciding every task except i: once with task i forced ADMITTED (with the toll-free
FARO-IoT decision) and once forced REJECTED. The measured externality of admitting i is the
change in the number of OTHER tasks completed safely on time:
    ext_i = (count_admit - own_success_i) - count_reject      (negative = later tasks lost)
It is compared with the toll unit u_i = (s_i/S_r) * T_q_hat * mean(1/D) that FARO-IoT charges
(times eta). Output: toll_validation.csv (one row per decision point).

  python toll_validation.py --dataset DNN-EdgeIIoT-dataset.csv --workers 20
"""
import argparse, os, sys, multiprocessing as mp
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import faro_iot as F

_TRACE = None

def run_branch(args):
    seed, task_id, action, eta, wl, cv = args
    F.EXT_ETA = eta; F.DEMAND_CV = cv
    q, lam, crev = F.DEFAULT_Q, F.DEFAULT_LAMBDA_B, F.DEFAULT_C_REV
    decide, post = F._decide_fn_for("FARO-IoT", q, lam, crev, F.RHO_D, beta=F.BETA_MISS, seed=seed)
    alt, _ = F._decide_fn_for("FARO-IoT-NoToll", q, lam, crev, F.RHO_D, beta=F.BETA_MISS, seed=seed)
    log = []
    F.FORCE_DECISION = dict(task_id=task_id, action=action, alt_decide=alt, log=log, invd_ref=decide.invd)
    try:
        m, df = F.run_experiment(_TRACE, F.WORKLOADS[wl], decide, lam, seed, reporting_c_rev=crev, q=q,
                                 workload_name=wl, algorithm_name="FARO-IoT", post_update_fn=post,
                                 keep_dataframe=True)
    finally:
        F.FORCE_DECISION = None
    count = int(df["safe_ontime_req"].fillna(False).astype(bool).sum())
    own = df.loc[df.task_id == task_id, "safe_ontime_req"].fillna(False).astype(bool)
    own = bool(own.iloc[0]) if len(own) else False
    info = {k: v for k, v in (log[0] if log else {}).items() if k != "task_id"}
    return dict(seed=seed, task_id=task_id, action=action, count=count, own=own, **info)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--workers", type=int, default=20)
    ap.add_argument("--max-tasks", type=int, default=300_000)
    ap.add_argument("--points", type=int, default=80, help="decision points per seed")
    ap.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3])
    ap.add_argument("--eta", type=float, default=4.0)
    ap.add_argument("--workload", default="HEAVY")
    ap.add_argument("--demand-cv", type=float, default=0.0)
    ap.add_argument("--out", default="runs/v7/V12_toll_validation/toll_validation.csv")
    a = ap.parse_args()
    global _TRACE
    _TRACE, _ = F.load_trace(a.dataset, max_tasks=a.max_tasks)
    ids = _TRACE["task_id"].to_numpy()
    lo, hi = int(0.2 * len(ids)), int(0.8 * len(ids))
    jobs = []
    for s in a.seeds:
        rng = np.random.default_rng(np.random.SeedSequence([s, 9_001]))
        for tid in rng.choice(ids[lo:hi], size=a.points, replace=False):
            for act in ("admit", "reject"):
                jobs.append((s, int(tid), act, a.eta, a.workload, a.demand_cv))
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with mp.get_context("fork").Pool(a.workers) as pool:
        rows = pool.map(run_branch, jobs, chunksize=1)
    d = pd.DataFrame(rows)
    A = d[d.action == "admit"].set_index(["seed", "task_id"]); R = d[d.action == "reject"].set_index(["seed", "task_id"])
    out = A.drop(columns=["action", "count", "own"]).copy()
    out["own_success"] = A["own"]
    out["ext_other"] = (A["count"] - A["own"].astype(int)) - R["count"]
    out.reset_index().to_csv(a.out, index=False)
    ok = out[out.alt_admits == True]
    print(f"points={len(out)}  toll-free-admissible={len(ok)}")
    if len(ok):
        ok = ok.assign(bin=pd.cut(ok.toll_unit, [-1e-9, 1e-9, 0.02, 0.05, 0.1, 0.2, 1e9]))
        print(ok.groupby("bin", observed=True).agg(n=("ext_other", "size"), mean_ext=("ext_other", "mean"),
                                                  toll_unit=("toll_unit", "mean")).round(3).to_string())
        print("Spearman(toll_unit, -ext_other) =", round(ok.toll_unit.corr(-ok.ext_other, method="spearman"), 3))
    print("wrote", a.out)

if __name__ == "__main__":
    main()
