#!/usr/bin/env bash
# v7b: toll validation in the congested part of the trace (tasks 600k-900k), 3 seeds x (40 toll-rejected + 40 admitted)
#   cd FARO-IoT && export FARO_DATASET=... && nohup bash run_v7b_tollval.sh > v7b.log 2>&1 &
set -uo pipefail
PY=${PY:-python}; WORKERS=${WORKERS:-20}
DATA=$(realpath "${FARO_DATASET:?set FARO_DATASET}")
mkdir -p runs/v7b
for cv in 0.0 1.0; do
  echo "[$(date '+%F %T')] >>> toll validation cv=$cv"
  $PY toll_validation.py --dataset "$DATA" --workers "$WORKERS" --demand-cv $cv --start 600000 --max-tasks 300000 \
      --points 40 --out runs/v7b/toll_validation_cv$cv.csv > runs/v7b/tollval_cv$cv.log 2>&1 \
    && echo "[$(date '+%F %T')] <<< cv=$cv done" || { echo "!!! cv=$cv FAILED"; tail -20 runs/v7b/tollval_cv$cv.log; }
done
echo "[$(date '+%F %T')] V7B FINISHED -- zip with: zip -r v7b_results.zip runs/v7b"
