# FARO-IoT

Simulation code for the paper:

> **FARO-IoT: A Simulation-Driven Finality-Risk-Aware Orchestration Framework for Edge-Fog-Cloud IoT Systems**
> Nour Ahmad Kaymih, Yazan Adnan Mohd Ali, Haythem Bany Salameh, Yaser Jararweh.
> Submitted to *The Journal of Supercomputing* (Springer Nature).

FARO-IoT decides, for every IoT task recorded on a proof-of-work (PoW) ledger, the execution tier (edge, fog or cloud), the confirmation depth and whether to admit the task at all. It fixes the minimum depth that meets the task's reversal-risk limit, computes the on-time probability with an exact Erlang model of confirmation time and a work-weighted queue prediction, and admits a task only when its utility stays positive after a Naor-inspired toll for the delay it imposes on later tasks.

The simulator is a trace-driven discrete-event simulation (SimPy) over two public traces, Edge-IIoTset and UNSW-NB15, and compares FARO-IoT with 20 baselines and variants under common random numbers.

## Repository contents

| File | Purpose |
|---|---|
| `faro_iot.py` | The full simulator: trace loading, task profiles, PoW ledger, edge/fog/cloud server pools, FARO-IoT and every baseline, metrics, 40 integrity tests and report generation |
| `paired_stats.py` | Paired block-bootstrap confidence intervals and the latency non-inferiority test |
| `select_tuned_v7.py` | Selects each tuned baseline's parameter on development seeds only |
| `toll_validation.py` | Paired admit/reject counterfactuals that check the externality toll |
| `run_v7_campaign.sh` | Runs the complete experiment campaign reported in the paper |
| `run_v7b_tollval.sh` | Toll validation in the congested part of the trace |
| `prepare_unsw_nb15.py` | Builds the UNSW-NB15 arrival trace from the four raw CSV files |
| `results/v7/` | Result tables of the campaign reported in the paper (see `results/README.md`) |
| `CHANGELOG.md` | Changes in this version |

## Installation

Python 3.10 or later.

```bash
git clone https://github.com/yazansaifan2012-gif/FARO-IoT.git
cd FARO-IoT
pip install -r requirements.txt
```

## Data

The traces are not redistributed here. Download them from their original sources and place them as described in [`data/README.md`](data/README.md):

- **Edge-IIoTset**: `DNN-EdgeIIoT-dataset.csv`
- **UNSW-NB15**: the four raw files `UNSW-NB15_1.csv` to `UNSW-NB15_4.csv`, converted with `prepare_unsw_nb15.py`

Both traces are used only as arrival processes. Their attack labels are never read by any policy.

## Quick start

Run the 40 integrity tests on the first 500 tasks of the trace:

```bash
python faro_iot.py --dataset data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv --mode test500
```

Run a short comparison of FARO-IoT against RTD-adapted:

```bash
python faro_iot.py --dataset data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv \
    --profile quick --seed 1 --workload HEAVY \
    --algorithm FARO-IoT --algorithm RTD-adapted --results-dir runs/quick
```

Results are written to `<results-dir>/results/` as CSV tables, with a summary in `FINAL_EXPERIMENT_REPORT.md`. Run `python faro_iot.py --help` for every option.

## Reproducing the paper

The full campaign uses 2.1 million Edge-IIoTset tasks and 2.0 million UNSW-NB15 tasks per run, five evaluation seeds and three workloads. It was run on a 32-core server with 20 worker processes.

```bash
export FARO_DATASET=data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv
export UNSW_PATH=data/UNSW_NB15/unsw_nb15_trace.csv
nohup bash run_v7_campaign.sh > v7_campaign.log 2>&1 &
```

The script runs these stages in order:

1. the integrity tests;
2. tuning of the baselines on development seeds 101 and 102;
3. the new experiments;
4. every evaluation experiment;
5. the toll validation.

Stages can be selected with `ONLY="T V"`, and finished experiments are skipped on restart. Each experiment directory receives `PAIRED_STATS.csv` from `paired_stats.py`.

The v7 campaign re-runs FARO-IoT and the four tuned baselines (QueueCap-k, SafeProb-θ, WorkCap-w, SizeGate-g) in every experiment, and every policy in the new experiments. The remaining baselines in Tables 5, 6 and 10 (RTD-adapted, SafeSlack, TS-Bandit, FixedDepth, FARO-v2, Fang-adapted, SharpEdge-adapted and the FARO-IoT variants; Fang-adapted is named `"Fang et al.-adapted"` in the code) come from the earlier v6 campaign. That campaign used the same simulator, seeds and settings, and FARO-IoT reproduces it exactly. To regenerate them, pass those policies with `--algorithm`, for example `--algorithm RTD-adapted --algorithm SafeSlack`.

| Paper element | Campaign directory |
|---|---|
| Table 5 (main setting) | `V1_main` |
| Table 6 (independent deadlines) | `V2_indep` |
| Fig. 4 (load scaling) | `V5_*` |
| Table 7 (service and demand variability) | `V6_*` |
| Table 8 (size-independent deadlines) | `V10_sizefree_*` |
| Table 9 (paired differences) | `PAIRED_STATS.csv` in each directory |
| Table 10 (UNSW-NB15) | `V3_unsw`, `V7_unsw_*` |
| Capacity, chain and attacker-share rows | `V8_*`, `V9_*` |
| Tuning (Section 5.1.3) | `T_*`, `tuning_summary.csv`, `tuned.env` |

## Main parameters

| Parameter | Value |
|---|---|
| Servers (edge, fog, cloud) | 2, 4, 16 |
| Processing rate | 1, 4, 16 GHz |
| Block rate | 2 blocks/s |
| Attacker share | 0.15 |
| Utility weights γ, C_rev, β | 0.5, 2, 2 |
| Toll weight η | 4 (selected on development seeds) |
| Evaluation seeds | 1 to 5 |
| Development seeds | 101 and 102 |

Every parameter is registered with its provenance in `faro_iot.py` and written to `provenance_table_final.csv` with each run.

## Citation

If you use this code, please cite the paper. A `CITATION.cff` file is included, and the full reference will be added on publication.

## License

Released under the MIT License. See [`LICENSE`](LICENSE).

## Contact

Corresponding author: Yaser Jararweh, Jordan University of Science and Technology (yJararweh@just.edu.jo).
