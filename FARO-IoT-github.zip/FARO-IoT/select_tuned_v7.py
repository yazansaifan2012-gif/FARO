#!/usr/bin/env python3
"""v7: select the single parameter of each tuned baseline on DEVELOPMENT seeds only (same rule as v6:
highest mean SOCR_req over every regime x workload x dev-seed cell). FARO-IoT keeps eta = 4 from v6.
Writes <root>/tuned.env with KCAP, THETA, WCAP, GATE and <root>/tuning_summary.csv (all candidates)."""
import glob, os, sys
import pandas as pd
root = sys.argv[1] if len(sys.argv) > 1 else "runs/v7"
fs = glob.glob(os.path.join(root, "T_*", "results", "final_results_by_seed.csv"))
if not fs:
    sys.exit("no tuning results found")
d = pd.concat([pd.read_csv(f).assign(regime=f.split(os.sep)[-3]) for f in fs], ignore_index=True)
m = d.groupby("algorithm")["M16_SOCR_req_pct"].mean().sort_values(ascending=False)
per = d.pivot_table(index="algorithm", columns="regime", values="M16_SOCR_req_pct", aggfunc="mean")
print(per.assign(mean=m).sort_values("mean", ascending=False).round(3).to_string())
out = {}
for key, pref in (("KCAP", "QueueCap-"), ("THETA", "SafeProb-"), ("WCAP", "WorkCap-"), ("GATE", "SizeGate-")):
    grid = m[[a for a in m.index if a.startswith(pref)]]
    best = grid.idxmax(); val = best[len(pref):]
    vals = sorted(float(a[len(pref):]) for a in grid.index)
    if float(val) in (vals[0], vals[-1]):
        print(f"[note] {key}={val} is at the edge of its grid {vals}")
    out[key] = val
with open(os.path.join(root, "tuned.env"), "w") as fh:
    fh.write("ETA=4\n")
    for k, v in out.items():
        fh.write(f"{k}={v}\n")
per.assign(mean=m).sort_values("mean", ascending=False).to_csv(os.path.join(root, "tuning_summary.csv"))
print("selected", out)
