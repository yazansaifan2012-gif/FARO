# Results of the v7 campaign

These are the result tables of the campaign reported in the paper, produced by `run_v7_campaign.sh`. Each
experiment directory contains:

| File | Content |
|---|---|
| `results/final_results_by_seed.csv` | Every metric per policy, workload and seed |
| `results/final_results_mean_std_ci.csv` | Means, standard deviations and 95% intervals over seeds |
| `results/PAIRED_STATS.csv` | Paired block-bootstrap differences and the latency non-inferiority test |
| `results/validation_tests_final.csv` | Outcome of the integrity tests |
| `results/provenance_table_final.csv` | Every parameter with its value and provenance |
| `FINAL_EXPERIMENT_REPORT.md` | Readable summary of the run |
| `experiment_manifest.json` | Exact configuration of the run |

The primary metric is `M16_SOCR_req_pct`, the Safe On-Time Completion Rate under each task's own risk requirement.

- `tuning_summary.csv` and `tuned.env` record how the tuned baselines were selected on development seeds 101 and 102.
- `V12_toll_validation/` holds the paired admit/reject counterfactuals.

Raw per-task arrays (`.npz`) and figures are not included because of their size. Dataset paths in the logs have
been replaced by `<project>`.
