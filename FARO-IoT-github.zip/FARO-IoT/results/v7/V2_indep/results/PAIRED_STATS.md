# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    86.99     83.23     3.75     3.72     3.79         yes            +6.1%      +6.2%        +4.1%  +4.2%        yes             yes
   LIGHT SafeProb-05    86.99     84.53     2.46     2.44     2.48         yes            +4.9%      +4.9%        +3.2%  +3.3%        yes             yes
   LIGHT SizeGate-02    86.99     83.27     3.72     3.69     3.74         yes            +6.2%      +6.2%        +4.1%  +4.2%        yes             yes
   LIGHT   WorkCap-8    86.99     83.27     3.72     3.69     3.74         yes            +6.2%      +6.2%        +4.1%  +4.2%        yes             yes
  MEDIUM  QueueCap-4    89.41     85.70     3.71     3.42     4.05         yes            +4.6%      +4.6%        +3.2%  +3.3%        yes             yes
  MEDIUM SafeProb-05    89.41     87.48     1.92     1.91     1.94         yes            +3.4%      +3.4%        +2.5%  +2.5%        yes             yes
  MEDIUM SizeGate-02    89.41     86.22     3.18     3.16     3.21         yes            +4.6%      +4.6%        +3.2%  +3.2%        yes             yes
  MEDIUM   WorkCap-8    89.41     86.05     3.36     3.27     3.46         yes            +4.5%      +4.6%        +3.2%  +3.2%        yes             yes
   HEAVY  QueueCap-4    47.09     46.95     0.14     0.12     0.16         yes           +24.5%     +25.6%        -9.1%  +5.8%         no              no
   HEAVY SafeProb-05    47.09     43.67     3.41     3.06     3.75         yes           -75.4%     -74.6%       -72.4% -72.2%        yes             yes
   HEAVY SizeGate-02    47.09     47.10    -0.01    -0.03    -0.00  no (worse)           -10.6%     -10.0%        -8.3%  -8.0%        yes             yes
   HEAVY   WorkCap-8    47.09     46.89     0.20     0.16     0.23         yes           -24.0%     -23.1%       -28.4% -22.5%        yes             yes
