# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 09:26:10 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3, 4, 5]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 47.10 | 9.43 | 23.55 | 47.10 | 0.378 | 47.10 | 4.512 | 0.00 | 47.10 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 47.09 | 15.77 | 32.91 | 47.09 | 0.399 | 47.09 | 4.033 | 0.00 | 47.09 | 2.03 | 0.152 |
| HEAVY | QueueCap-4 | 46.95 | 9.39 | 23.46 | 46.95 | 0.377 | 46.95 | 3.240 | 0.15 | 47.02 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 46.89 | 9.28 | 23.30 | 46.89 | 0.376 | 46.89 | 5.308 | 0.53 | 47.13 | 1.69 | 0.198 |
| HEAVY | SafeProb-0.5 | 43.67 | 5.92 | 17.76 | 43.67 | 0.341 | 43.67 | 16.397 | 7.96 | 47.45 | 1.56 | 0.216 |
| LIGHT | FARO-IoT | 86.99 | 14.31 | 39.63 | 86.99 | 0.689 | 86.99 | 0.854 | 13.01 | 100.00 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 84.53 | 12.96 | 37.16 | 84.53 | 0.667 | 84.53 | 0.814 | 8.46 | 92.34 | 1.62 | 0.207 |
| LIGHT | SizeGate-0.2 | 83.27 | 12.46 | 35.91 | 83.27 | 0.655 | 83.27 | 0.804 | 7.52 | 90.03 | 1.60 | 0.210 |
| LIGHT | WorkCap-8 | 83.27 | 12.46 | 35.91 | 83.27 | 0.655 | 83.27 | 0.804 | 7.52 | 90.03 | 1.60 | 0.210 |
| LIGHT | QueueCap-4 | 83.23 | 12.46 | 35.89 | 83.23 | 0.655 | 83.23 | 0.804 | 7.52 | 90.00 | 1.60 | 0.210 |
| MEDIUM | FARO-IoT | 89.41 | 15.11 | 41.34 | 89.41 | 0.710 | 89.41 | 0.892 | 10.56 | 99.96 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 87.48 | 13.86 | 39.41 | 87.48 | 0.692 | 87.48 | 0.862 | 7.52 | 94.59 | 1.64 | 0.204 |
| MEDIUM | SizeGate-0.2 | 86.22 | 13.36 | 38.15 | 86.22 | 0.681 | 86.22 | 0.853 | 6.57 | 92.29 | 1.62 | 0.207 |
| MEDIUM | WorkCap-8 | 86.05 | 13.33 | 38.07 | 86.05 | 0.679 | 86.05 | 0.853 | 6.58 | 92.10 | 1.62 | 0.207 |
| MEDIUM | QueueCap-4 | 85.70 | 13.28 | 37.92 | 85.70 | 0.677 | 85.70 | 0.853 | 6.57 | 91.73 | 1.62 | 0.207 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 1061.5 s (17.69 min).
