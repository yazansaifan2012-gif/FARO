# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    89.18     89.18    -0.00    -0.00    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT SafeProb-05    89.18     89.18    -0.00    -0.00    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT SizeGate-02    89.18     89.18    -0.00    -0.00    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT   WorkCap-8    89.18     89.18    -0.00    -0.00    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM  QueueCap-4    92.00     92.00     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM SafeProb-05    92.00     92.00     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM SizeGate-02    92.00     92.00     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM   WorkCap-8    92.00     92.00     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   HEAVY  QueueCap-4    84.53     84.39     0.14     0.12     0.17         yes            +8.0%      +9.8%       +22.5% +24.0%         no              no
   HEAVY SafeProb-05    84.53     80.86     3.66     2.91     4.42         yes           -66.2%     -62.9%       -75.3% -74.7%        yes             yes
   HEAVY SizeGate-02    84.53     84.53     0.00    -0.01     0.01        n.s.           -10.8%      -9.5%       -11.1% -10.4%        yes             yes
   HEAVY   WorkCap-8    84.53     84.34     0.19     0.14     0.24         yes           -20.9%     -18.6%       -18.2% -17.5%        yes             yes
