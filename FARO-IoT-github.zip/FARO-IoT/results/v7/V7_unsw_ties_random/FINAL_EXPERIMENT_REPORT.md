# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 12:21:42 UTC

## 1. Dataset Audit

- Source: `toniot:<project>/data/UNSW_NB15/unsw_nb15_trace.csv (1 file(s); integer-second ties mode=random)` (SHA-256 `eaf8978c884b5a43...`)
- Raw rows: 2,540,047 | Valid-timestamp rows: 2,540,047 | Invalid: 0
- Final task count used: 2,000,000
- Trace duration: 2319481.713 s | Mean arrival rate: 0.8623 tasks/s
- Payload (tcp.len) bytes: mean=3882.85, median=1540.00, std=8039.62, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | FARO-IoT | 84.53 | 19.85 | 47.55 | 84.53 | 0.690 | 84.53 | 2.564 | 0.00 | 84.53 | 1.80 | 0.184 |
| HEAVY | SizeGate-0.2 | 84.53 | 16.93 | 42.30 | 84.53 | 0.679 | 84.53 | 2.875 | 0.00 | 84.53 | 1.70 | 0.197 |
| HEAVY | QueueCap-4 | 84.39 | 16.88 | 42.19 | 84.39 | 0.678 | 84.39 | 2.375 | 0.07 | 84.44 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 84.34 | 17.03 | 42.54 | 84.34 | 0.678 | 84.34 | 3.242 | 0.29 | 84.58 | 1.71 | 0.196 |
| HEAVY | SafeProb-0.5 | 80.87 | 18.96 | 45.01 | 80.87 | 0.659 | 80.87 | 7.589 | 4.74 | 84.89 | 1.80 | 0.183 |
| LIGHT | QueueCap-4 | 89.18 | 18.75 | 45.98 | 89.18 | 0.719 | 89.18 | 0.857 | 10.82 | 100.00 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 89.18 | 18.75 | 45.98 | 89.18 | 0.719 | 89.18 | 0.857 | 10.82 | 100.00 | 1.70 | 0.197 |
| LIGHT | SizeGate-0.2 | 89.18 | 18.75 | 45.98 | 89.18 | 0.719 | 89.18 | 0.857 | 10.82 | 100.00 | 1.70 | 0.197 |
| LIGHT | WorkCap-8 | 89.18 | 18.75 | 45.98 | 89.18 | 0.719 | 89.18 | 0.857 | 10.82 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 89.18 | 18.75 | 45.98 | 89.18 | 0.719 | 89.18 | 0.857 | 10.82 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 92.00 | 19.02 | 46.89 | 92.00 | 0.741 | 92.00 | 0.888 | 8.00 | 100.00 | 1.70 | 0.197 |
| MEDIUM | QueueCap-4 | 92.00 | 19.02 | 46.89 | 92.00 | 0.741 | 92.00 | 0.888 | 8.00 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 92.00 | 19.02 | 46.89 | 92.00 | 0.741 | 92.00 | 0.888 | 8.00 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SizeGate-0.2 | 92.00 | 19.02 | 46.89 | 92.00 | 0.741 | 92.00 | 0.888 | 8.00 | 100.00 | 1.70 | 0.197 |
| MEDIUM | WorkCap-8 | 92.00 | 19.02 | 46.89 | 92.00 | 0.741 | 92.00 | 0.888 | 8.00 | 100.00 | 1.70 | 0.197 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 723.5 s (12.06 min).
