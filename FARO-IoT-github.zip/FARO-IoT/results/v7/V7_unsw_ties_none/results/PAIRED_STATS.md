# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    89.00     88.16     0.83     0.58     1.11         yes            -0.4%      -0.3%        -0.1%  -0.0%        yes             yes
   LIGHT SafeProb-05    89.00     89.03    -0.03    -0.03    -0.03  no (worse)            +0.3%      +0.3%        +0.2%  +0.2%        yes             yes
   LIGHT SizeGate-02    89.00     89.03    -0.03    -0.03    -0.03  no (worse)            +0.3%      +0.3%        +0.2%  +0.2%        yes             yes
   LIGHT   WorkCap-8    89.00     88.96     0.04     0.02     0.06         yes            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM  QueueCap-4    91.83     91.05     0.78     0.52     1.09         yes            +0.0%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM SafeProb-05    91.83     91.84    -0.01    -0.01    -0.01  no (worse)            +0.1%      +0.2%        +0.1%  +0.1%        yes             yes
  MEDIUM SizeGate-02    91.83     91.84    -0.01    -0.01    -0.01  no (worse)            +0.1%      +0.2%        +0.1%  +0.1%        yes             yes
  MEDIUM   WorkCap-8    91.83     91.80     0.03     0.01     0.04         yes            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   HEAVY  QueueCap-4    84.49     84.35     0.14     0.11     0.16         yes           +10.8%     +12.6%       +22.3% +23.4%         no              no
   HEAVY SafeProb-05    84.49     81.28     3.21     2.54     3.89         yes           -66.0%     -62.4%       -76.4% -75.9%        yes             yes
   HEAVY SizeGate-02    84.49     84.50    -0.01    -0.02    -0.00  no (worse)            -9.0%      -7.8%       -10.1%  -9.7%        yes             yes
   HEAVY   WorkCap-8    84.49     84.38     0.11     0.07     0.15         yes           -19.4%     -17.1%       -17.7% -17.1%        yes             yes
