# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 12:09:34 UTC

## 1. Dataset Audit

- Source: `toniot:<project>/data/UNSW_NB15/unsw_nb15_trace.csv (1 file(s); integer-second ties mode=none)` (SHA-256 `eaf8978c884b5a43...`)
- Raw rows: 2,540,047 | Valid-timestamp rows: 2,540,047 | Invalid: 0
- Final task count used: 2,000,000
- Trace duration: 2319481.000 s | Mean arrival rate: 0.8623 tasks/s
- Payload (tcp.len) bytes: mean=3882.85, median=1540.00, std=8039.62, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 84.50 | 16.91 | 42.25 | 84.50 | 0.678 | 84.50 | 2.849 | 0.00 | 84.50 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 84.49 | 18.59 | 44.86 | 84.49 | 0.684 | 84.49 | 2.592 | 0.00 | 84.49 | 1.75 | 0.190 |
| HEAVY | WorkCap-8 | 84.38 | 16.99 | 42.44 | 84.38 | 0.678 | 84.38 | 3.217 | 0.23 | 84.57 | 1.70 | 0.196 |
| HEAVY | QueueCap-4 | 84.35 | 16.87 | 42.17 | 84.35 | 0.677 | 84.35 | 2.339 | 0.06 | 84.40 | 1.70 | 0.197 |
| HEAVY | SafeProb-0.5 | 81.28 | 18.93 | 44.53 | 81.28 | 0.661 | 81.28 | 7.628 | 4.25 | 84.88 | 1.78 | 0.186 |
| LIGHT | SafeProb-0.5 | 89.03 | 18.73 | 45.93 | 89.03 | 0.718 | 89.03 | 0.861 | 10.97 | 100.00 | 1.70 | 0.197 |
| LIGHT | SizeGate-0.2 | 89.03 | 18.73 | 45.93 | 89.03 | 0.718 | 89.03 | 0.861 | 10.97 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 89.00 | 18.72 | 45.91 | 89.00 | 0.718 | 89.00 | 0.863 | 11.00 | 100.00 | 1.70 | 0.197 |
| LIGHT | WorkCap-8 | 88.96 | 18.72 | 45.90 | 88.96 | 0.717 | 88.96 | 0.863 | 11.01 | 99.96 | 1.70 | 0.197 |
| LIGHT | QueueCap-4 | 88.16 | 18.56 | 45.51 | 88.16 | 0.711 | 88.16 | 0.867 | 11.09 | 99.16 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 91.84 | 19.00 | 46.82 | 91.84 | 0.739 | 91.84 | 0.900 | 8.16 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SizeGate-0.2 | 91.84 | 19.00 | 46.82 | 91.84 | 0.739 | 91.84 | 0.900 | 8.16 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 91.83 | 18.99 | 46.81 | 91.83 | 0.739 | 91.83 | 0.901 | 8.17 | 100.00 | 1.70 | 0.197 |
| MEDIUM | WorkCap-8 | 91.80 | 18.99 | 46.80 | 91.80 | 0.739 | 91.80 | 0.900 | 8.17 | 99.96 | 1.70 | 0.197 |
| MEDIUM | QueueCap-4 | 91.05 | 18.83 | 46.42 | 91.05 | 0.733 | 91.05 | 0.901 | 8.18 | 99.16 | 1.70 | 0.197 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 683.9 s (11.40 min).
