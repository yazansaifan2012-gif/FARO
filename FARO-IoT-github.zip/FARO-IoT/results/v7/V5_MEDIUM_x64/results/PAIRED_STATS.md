# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
  MEDIUM  QueueCap-4    60.37     39.22    21.15    19.62    22.64         yes           +19.9%     +22.3%        +9.7% +11.5%         no              no
  MEDIUM SafeProb-05    60.37     50.82     9.55     8.51    10.63         yes           -34.6%     -33.0%       -24.8% -23.1%        yes             yes
  MEDIUM SizeGate-02    60.37     58.50     1.88     1.60     2.15         yes            -1.0%      +0.4%        +1.8%  +3.0%        yes             yes
  MEDIUM   WorkCap-8    60.37     58.55     1.82     1.60     2.03         yes           +19.5%     +21.9%        +9.7% +11.2%         no              no
