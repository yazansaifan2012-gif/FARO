# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 13:47:48 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=0.5, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 47.10 | 9.41 | 23.53 | 47.10 | 0.378 | 47.10 | 7.998 | 0.08 | 47.14 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 47.10 | 10.78 | 28.22 | 47.10 | 0.387 | 47.10 | 7.209 | 0.01 | 47.10 | 1.83 | 0.177 |
| HEAVY | QueueCap-4 | 46.93 | 9.34 | 23.40 | 46.93 | 0.377 | 46.93 | 5.849 | 0.20 | 47.02 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 46.91 | 9.25 | 23.26 | 46.91 | 0.376 | 46.91 | 7.907 | 0.48 | 47.13 | 1.69 | 0.198 |
| HEAVY | SafeProb-0.5 | 42.45 | 5.63 | 17.07 | 42.45 | 0.331 | 42.45 | 22.132 | 10.70 | 47.54 | 1.55 | 0.217 |
| LIGHT | FARO-IoT | 87.01 | 14.33 | 39.64 | 87.01 | 0.690 | 87.01 | 3.395 | 12.99 | 100.00 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 84.50 | 12.96 | 37.14 | 84.50 | 0.667 | 84.50 | 3.241 | 8.46 | 92.32 | 1.62 | 0.207 |
| LIGHT | SizeGate-0.2 | 83.24 | 12.45 | 35.87 | 83.24 | 0.655 | 83.24 | 3.202 | 7.53 | 90.01 | 1.60 | 0.210 |
| LIGHT | WorkCap-8 | 83.24 | 12.45 | 35.87 | 83.24 | 0.655 | 83.24 | 3.202 | 7.53 | 90.01 | 1.60 | 0.210 |
| LIGHT | QueueCap-4 | 83.20 | 12.45 | 35.86 | 83.20 | 0.655 | 83.20 | 3.202 | 7.53 | 89.98 | 1.60 | 0.210 |
| MEDIUM | FARO-IoT | 87.65 | 14.53 | 40.09 | 87.65 | 0.695 | 87.65 | 3.433 | 12.35 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 85.26 | 13.18 | 37.70 | 85.26 | 0.673 | 85.26 | 3.290 | 8.21 | 92.88 | 1.63 | 0.206 |
| MEDIUM | SizeGate-0.2 | 83.99 | 12.68 | 36.43 | 83.99 | 0.662 | 83.99 | 3.250 | 7.27 | 90.58 | 1.61 | 0.209 |
| MEDIUM | WorkCap-8 | 83.83 | 12.65 | 36.36 | 83.83 | 0.660 | 83.83 | 3.251 | 7.27 | 90.41 | 1.61 | 0.209 |
| MEDIUM | QueueCap-4 | 83.48 | 12.60 | 36.20 | 83.48 | 0.658 | 83.48 | 3.252 | 7.28 | 90.03 | 1.61 | 0.209 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 739.8 s (12.33 min).
