# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    87.01     83.20     3.80     3.73     3.88         yes            +6.0%      +6.1%        +4.0%  +4.2%        yes             yes
   LIGHT SafeProb-05    87.01     84.50     2.50     2.45     2.55         yes            +4.8%      +4.8%        +3.2%  +3.3%        yes             yes
   LIGHT SizeGate-02    87.01     83.24     3.77     3.70     3.84         yes            +6.0%      +6.1%        +4.0%  +4.2%        yes             yes
   LIGHT   WorkCap-8    87.01     83.24     3.77     3.70     3.84         yes            +6.0%      +6.1%        +4.0%  +4.2%        yes             yes
  MEDIUM  QueueCap-4    87.65     83.48     4.17     3.79     4.62         yes            +5.6%      +5.7%        +3.7%  +3.9%        yes             yes
  MEDIUM SafeProb-05    87.65     85.26     2.39     2.34     2.44         yes            +4.4%      +4.4%        +3.0%  +3.1%        yes             yes
  MEDIUM SizeGate-02    87.65     83.99     3.66     3.59     3.72         yes            +5.6%      +5.7%        +3.8%  +3.9%        yes             yes
  MEDIUM   WorkCap-8    87.65     83.83     3.82     3.68     3.97         yes            +5.6%      +5.7%        +3.7%  +3.9%        yes             yes
   HEAVY  QueueCap-4    47.10     46.93     0.17     0.14     0.21         yes           +23.2%     +25.2%        +5.0%  +5.4%         no              no
   HEAVY SafeProb-05    47.10     42.45     4.65     4.06     5.19         yes           -67.4%     -65.8%       -59.8% -59.3%        yes             yes
   HEAVY SizeGate-02    47.10     47.10    -0.00    -0.03     0.02        n.s.            -9.9%      -9.0%        -6.4%  -6.0%        yes             yes
   HEAVY   WorkCap-8    47.10     46.91     0.19     0.15     0.22         yes            -8.8%      -8.0%       -27.7% -24.0%        yes             yes
