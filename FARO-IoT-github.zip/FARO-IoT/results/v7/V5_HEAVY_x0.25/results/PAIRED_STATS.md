# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   HEAVY  QueueCap-4    86.96     86.24     0.73     0.65     0.80         yes            +9.2%     +10.1%       +22.3% +23.6%         no              no
   HEAVY SafeProb-05    86.96     86.31     0.65     0.23     1.08         yes           -57.7%     -53.5%       -76.5% -76.1%        yes             yes
   HEAVY SizeGate-02    86.96     87.24    -0.28    -0.32    -0.24  no (worse)            -4.3%      -3.1%        -8.2%  -7.7%        yes             yes
   HEAVY   WorkCap-8    86.96     87.33    -0.37    -0.44    -0.30  no (worse)           -12.5%     -10.5%       -14.8% -14.4%        yes             yes
