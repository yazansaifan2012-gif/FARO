# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    34.58     34.60    -0.02    -0.05    -0.00  no (worse)            -0.0%      +0.0%        -0.0%  -0.0%        yes             yes
   LIGHT SafeProb-05    34.58     34.58    -0.00    -0.01    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT SizeGate-02    34.58     34.58    -0.00    -0.01    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT   WorkCap-8    34.58     34.58    -0.00    -0.01    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM  QueueCap-4    36.30     36.41    -0.11    -0.24    -0.02  no (worse)            -0.0%      +0.2%        -0.0%  -0.0%        yes             yes
  MEDIUM SafeProb-05    36.30     36.29     0.01     0.00     0.01         yes            +0.0%      +0.0%        -0.0%  +0.0%        yes             yes
  MEDIUM SizeGate-02    36.30     36.29     0.01     0.00     0.01         yes            +0.0%      +0.0%        -0.0%  +0.0%        yes             yes
  MEDIUM   WorkCap-8    36.30     36.36    -0.06    -0.14    -0.00  no (worse)            -0.0%      +0.1%        -0.0%  -0.0%        yes             yes
   HEAVY  QueueCap-4    47.09     46.93     0.16     0.14     0.18         yes           +22.3%     +23.6%       -11.3%  +6.8%         no              no
   HEAVY SafeProb-05    47.09     40.11     6.98     6.22     7.73         yes           -75.4%     -74.3%       -72.2% -71.9%        yes             yes
   HEAVY SizeGate-02    47.09     47.10    -0.01    -0.02     0.01        n.s.           -10.0%      -9.1%        -6.2%  -5.9%        yes             yes
   HEAVY   WorkCap-8    47.09     46.72     0.37     0.31     0.43         yes           -25.2%     -23.9%       -29.5% -22.2%        yes             yes
