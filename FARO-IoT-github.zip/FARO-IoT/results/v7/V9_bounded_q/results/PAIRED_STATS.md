# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload         comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT FARO-IoT-NoPenalty    62.22     62.23    -0.01    -0.01    -0.01  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT    FARO-IoT-NoToll    62.22     62.25    -0.03    -0.04    -0.03  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   LIGHT       FixedDepth-3    62.22     31.11    31.10    30.94    31.27         yes           +23.5%     +23.6%       +21.5% +21.7%         no             yes
   LIGHT         QueueCap-4    62.22     51.78    10.43    10.35    10.51         yes            +4.1%      +4.2%        +3.3%  +3.4%        yes             yes
   LIGHT        RTD-adapted    62.22     51.78    10.43    10.35    10.52         yes            +4.1%      +4.2%        +3.3%  +3.3%        yes             yes
   LIGHT        SafeProb-05    62.22     54.28     7.93     7.86     8.00         yes            +3.8%      +3.8%        +3.0%  +3.1%        yes             yes
   LIGHT          SafeSlack    62.22     62.26    -0.05    -0.05    -0.04  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   LIGHT        SizeGate-02    62.22     51.78    10.43    10.35    10.52         yes            +4.1%      +4.2%        +3.3%  +3.4%        yes             yes
   LIGHT   TS-Bandit-masked    62.22     50.35    11.87    11.79    11.94         yes            -2.2%      -2.0%        -1.6%  -1.4%        yes             yes
   LIGHT          WorkCap-8    62.22     51.78    10.43    10.35    10.52         yes            +4.1%      +4.2%        +3.3%  +3.4%        yes             yes
  MEDIUM FARO-IoT-NoPenalty    66.25     66.28    -0.03    -0.04    -0.02  no (worse)            -0.0%      -0.0%        -0.0%  -0.0%        yes             yes
  MEDIUM    FARO-IoT-NoToll    66.25     66.32    -0.07    -0.10    -0.05  no (worse)            -0.1%      -0.1%        -0.1%  -0.1%        yes             yes
  MEDIUM       FixedDepth-3    66.25     33.36    32.90    32.74    33.06         yes           +22.6%     +22.8%       +21.0% +21.4%         no              no
  MEDIUM         QueueCap-4    66.25     55.97    10.28    10.16    10.40         yes            +3.6%      +3.6%        +2.9%  +3.0%        yes             yes
  MEDIUM        RTD-adapted    66.25     56.18    10.07     9.98    10.16         yes            +3.6%      +3.6%        +2.9%  +3.0%        yes             yes
  MEDIUM        SafeProb-05    66.25     58.68     7.57     7.50     7.64         yes            +3.3%      +3.3%        +2.7%  +2.8%        yes             yes
  MEDIUM          SafeSlack    66.25     66.34    -0.08    -0.12    -0.06  no (worse)            -0.1%      -0.1%        -0.1%  -0.1%        yes             yes
  MEDIUM        SizeGate-02    66.25     56.18    10.07     9.98    10.16         yes            +3.6%      +3.6%        +2.9%  +3.0%        yes             yes
  MEDIUM   TS-Bandit-masked    66.25     52.92    13.33    13.22    13.43         yes            -9.7%      -9.3%        -6.5%  -6.1%        yes             yes
  MEDIUM          WorkCap-8    66.25     56.17    10.09    10.00    10.17         yes            +3.6%      +3.6%        +2.9%  +3.0%        yes             yes
   HEAVY FARO-IoT-NoPenalty    47.07     47.07     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   HEAVY    FARO-IoT-NoToll    47.07     46.36     0.71     0.51     0.90         yes           -70.4%     -69.2%       -68.7% -68.5%        yes             yes
   HEAVY       FixedDepth-3    47.07     21.49    25.58    23.98    27.16         yes           -72.0%     -70.7%       -70.4% -70.2%        yes             yes
   HEAVY         QueueCap-4    47.07     46.93     0.14     0.12     0.15         yes            +9.2%      +9.7%       -19.8%  -9.7%        yes              no
   HEAVY        RTD-adapted    47.07     42.83     4.24     3.84     4.64         yes           -72.0%     -70.8%       -70.4% -70.2%        yes             yes
   HEAVY        SafeProb-05    47.07     41.90     5.17     4.71     5.62         yes           -72.2%     -71.0%       -70.7% -70.5%        yes             yes
   HEAVY          SafeSlack    47.07     24.76    22.31    20.60    23.96         yes           -74.2%     -73.1%       -73.0% -72.8%        yes             yes
   HEAVY        SizeGate-02    47.07     47.10    -0.03    -0.04    -0.02  no (worse)           -16.0%     -15.1%       -17.2% -16.9%        yes             yes
   HEAVY   TS-Bandit-masked    47.07     41.70     5.37     4.89     5.82         yes           -74.0%     -73.4%       -70.8% -70.7%        yes             yes
   HEAVY          WorkCap-8    47.07     46.75     0.32     0.27     0.36         yes           -26.5%     -25.3%       -35.3% -29.7%        yes             yes
