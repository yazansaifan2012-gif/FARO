# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 08:49:47 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3, 4, 5]
- q=0.25, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 47.10 | 9.43 | 23.55 | 47.10 | 0.393 | 47.10 | 5.512 | 0.00 | 47.10 | 3.70 | 0.165 |
| HEAVY | FARO-IoT | 47.07 | 2.91 | 11.70 | 47.07 | 0.382 | 47.07 | 4.631 | 0.00 | 47.07 | 3.31 | 0.188 |
| HEAVY | FARO-IoT-NoPenalty | 47.07 | 2.91 | 11.70 | 47.07 | 0.382 | 47.07 | 4.631 | 0.00 | 47.07 | 3.31 | 0.188 |
| HEAVY | QueueCap-4 | 46.93 | 9.39 | 23.45 | 46.93 | 0.392 | 46.93 | 4.240 | 0.18 | 47.02 | 3.70 | 0.165 |
| HEAVY | WorkCap-8 | 46.75 | 9.20 | 23.16 | 46.75 | 0.390 | 46.75 | 6.305 | 0.81 | 47.13 | 3.69 | 0.166 |
| HEAVY | FARO-IoT-NoToll | 46.36 | 4.68 | 16.82 | 46.36 | 0.381 | 46.36 | 15.642 | 2.23 | 47.41 | 3.46 | 0.179 |
| HEAVY | RTD-adapted | 42.83 | 5.87 | 17.53 | 42.83 | 0.354 | 42.83 | 16.556 | 9.71 | 47.43 | 3.56 | 0.174 |
| HEAVY | SafeProb-0.5 | 41.90 | 5.75 | 17.15 | 41.90 | 0.346 | 41.90 | 16.675 | 11.67 | 47.43 | 3.56 | 0.174 |
| HEAVY | TS-Bandit-masked | 41.70 | 16.40 | 28.22 | 41.70 | 0.365 | 41.70 | 17.803 | 12.07 | 47.43 | 5.83 | 0.127 |
| HEAVY | SafeSlack | 24.76 | 3.87 | 10.76 | 24.76 | 0.205 | 24.76 | 17.964 | 47.84 | 47.46 | 3.70 | 0.165 |
| HEAVY | FixedDepth-3 | 21.49 | 0.00 | 0.00 | 43.01 | 0.341 | 43.01 | 16.530 | 9.33 | 47.43 | 3.00 | 0.207 |
| LIGHT | SafeSlack | 62.26 | 9.07 | 26.51 | 62.26 | 0.515 | 62.26 | 1.849 | 37.74 | 100.00 | 3.70 | 0.165 |
| LIGHT | FARO-IoT-NoToll | 62.25 | 9.07 | 26.51 | 62.25 | 0.515 | 62.25 | 1.849 | 37.75 | 100.00 | 3.70 | 0.165 |
| LIGHT | FARO-IoT-NoPenalty | 62.23 | 9.06 | 26.49 | 62.23 | 0.515 | 62.23 | 1.851 | 37.77 | 100.00 | 3.70 | 0.165 |
| LIGHT | FARO-IoT | 62.22 | 9.06 | 26.48 | 62.22 | 0.515 | 62.22 | 1.851 | 37.78 | 100.00 | 3.70 | 0.165 |
| LIGHT | SafeProb-0.5 | 54.28 | 7.06 | 21.92 | 54.28 | 0.448 | 54.28 | 1.783 | 17.97 | 66.17 | 3.57 | 0.173 |
| LIGHT | WorkCap-8 | 51.78 | 6.57 | 20.67 | 51.78 | 0.427 | 51.78 | 1.778 | 15.83 | 61.52 | 3.56 | 0.173 |
| LIGHT | RTD-adapted | 51.78 | 6.57 | 20.67 | 51.78 | 0.427 | 51.78 | 1.778 | 15.83 | 61.52 | 3.56 | 0.173 |
| LIGHT | SizeGate-0.2 | 51.78 | 6.57 | 20.67 | 51.78 | 0.427 | 51.78 | 1.778 | 15.83 | 61.52 | 3.56 | 0.173 |
| LIGHT | QueueCap-4 | 51.78 | 6.57 | 20.67 | 51.78 | 0.427 | 51.78 | 1.778 | 15.83 | 61.52 | 3.56 | 0.173 |
| LIGHT | TS-Bandit-masked | 50.35 | 10.58 | 24.91 | 50.35 | 0.420 | 50.35 | 1.892 | 18.17 | 61.53 | 3.75 | 0.163 |
| LIGHT | FixedDepth-3 | 31.11 | 0.00 | 0.00 | 62.25 | 0.494 | 62.25 | 1.499 | 12.95 | 71.52 | 3.00 | 0.207 |
| MEDIUM | SafeSlack | 66.34 | 9.89 | 28.60 | 66.34 | 0.549 | 66.34 | 1.888 | 33.66 | 100.00 | 3.70 | 0.165 |
| MEDIUM | FARO-IoT-NoToll | 66.32 | 9.88 | 28.59 | 66.32 | 0.549 | 66.32 | 1.888 | 33.62 | 99.92 | 3.70 | 0.165 |
| MEDIUM | FARO-IoT-NoPenalty | 66.28 | 9.86 | 28.55 | 66.28 | 0.549 | 66.28 | 1.886 | 33.38 | 99.49 | 3.70 | 0.166 |
| MEDIUM | FARO-IoT | 66.25 | 9.85 | 28.53 | 66.25 | 0.548 | 66.25 | 1.886 | 33.31 | 99.34 | 3.69 | 0.166 |
| MEDIUM | SafeProb-0.5 | 58.68 | 7.90 | 24.06 | 58.68 | 0.485 | 58.68 | 1.825 | 17.03 | 70.73 | 3.58 | 0.172 |
| MEDIUM | RTD-adapted | 56.18 | 7.39 | 22.82 | 56.18 | 0.464 | 56.18 | 1.821 | 14.96 | 66.07 | 3.57 | 0.173 |
| MEDIUM | SizeGate-0.2 | 56.18 | 7.39 | 22.82 | 56.18 | 0.464 | 56.18 | 1.821 | 14.96 | 66.07 | 3.57 | 0.173 |
| MEDIUM | WorkCap-8 | 56.17 | 7.39 | 22.81 | 56.17 | 0.464 | 56.17 | 1.821 | 14.96 | 66.05 | 3.57 | 0.173 |
| MEDIUM | QueueCap-4 | 55.97 | 7.37 | 22.73 | 55.97 | 0.462 | 55.97 | 1.821 | 14.96 | 65.82 | 3.57 | 0.173 |
| MEDIUM | TS-Bandit-masked | 52.92 | 9.75 | 37.32 | 52.92 | 0.449 | 52.92 | 2.089 | 19.94 | 66.10 | 3.95 | 0.150 |
| MEDIUM | FixedDepth-3 | 33.36 | 0.00 | 0.00 | 66.74 | 0.529 | 66.74 | 1.537 | 12.24 | 76.05 | 3.00 | 0.207 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 2564.9 s (42.75 min).
