# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    89.28     89.24     0.05    -0.00     0.12        n.s.            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT SafeProb-05    89.28     89.31    -0.02    -0.03    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT SizeGate-02    89.28     89.31    -0.02    -0.03    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT   WorkCap-8    89.28     89.31    -0.02    -0.03    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
  MEDIUM  QueueCap-4    92.00     91.40     0.61     0.19     1.15         yes            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM SafeProb-05    92.00     92.01    -0.01    -0.01    -0.00  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM SizeGate-02    92.00     92.01    -0.01    -0.01    -0.00  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM   WorkCap-8    92.00     91.76     0.24     0.08     0.46         yes            +0.1%      +0.1%        +0.0%  +0.1%        yes             yes
   HEAVY  QueueCap-4    47.09     46.93     0.16     0.14     0.18         yes           +22.6%     +23.9%        -9.3%  +7.7%         no              no
   HEAVY SafeProb-05    47.09     40.54     6.55     5.84     7.23         yes           -75.5%     -74.4%       -72.4% -72.1%        yes             yes
   HEAVY SizeGate-02    47.09     47.10    -0.01    -0.02     0.01        n.s.           -10.0%      -9.2%        -6.2%  -5.8%        yes             yes
   HEAVY   WorkCap-8    47.09     46.73     0.36     0.30     0.41         yes           -25.4%     -24.1%       -28.8% -21.9%        yes             yes
