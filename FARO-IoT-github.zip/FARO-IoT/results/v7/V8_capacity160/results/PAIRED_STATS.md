# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    81.08     81.12    -0.05    -0.08    -0.02  no (worse)            +0.3%      +0.5%        +0.8%  +1.6%        yes             yes
   LIGHT SafeProb-05    81.08     81.09    -0.02    -0.02    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.2%        yes             yes
   LIGHT SizeGate-02    81.08     81.09    -0.02    -0.02    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.2%        yes             yes
   LIGHT   WorkCap-8    81.08     81.09    -0.02    -0.02    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.2%        yes             yes
  MEDIUM  QueueCap-4    83.92     83.82     0.09    -0.03     0.24        n.s.            +1.0%      +2.0%        +2.6%  +5.5%        yes             yes
  MEDIUM SafeProb-05    83.92     83.92    -0.00    -0.01    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.1%        yes             yes
  MEDIUM SizeGate-02    83.92     83.92    -0.00    -0.01    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.1%        yes             yes
  MEDIUM   WorkCap-8    83.92     83.93    -0.01    -0.06     0.03        n.s.            +0.5%      +1.0%        +1.3%  +3.0%        yes             yes
   HEAVY  QueueCap-4    47.09     46.93     0.16     0.13     0.18         yes           +22.5%     +23.8%       -10.4%  +7.6%         no              no
   HEAVY SafeProb-05    47.09     40.56     6.53     5.82     7.23         yes           -75.5%     -74.4%       -72.5% -72.1%        yes             yes
   HEAVY SizeGate-02    47.09     47.10    -0.01    -0.02     0.01        n.s.           -10.0%      -9.2%        -6.3%  -5.9%        yes             yes
   HEAVY   WorkCap-8    47.09     46.73     0.36     0.29     0.41         yes           -25.4%     -24.1%       -29.0% -22.1%        yes             yes
