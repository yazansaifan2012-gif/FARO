# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 13:09:11 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 47.10 | 9.45 | 23.58 | 47.10 | 0.378 | 47.10 | 4.414 | 0.00 | 47.10 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 47.09 | 16.21 | 33.57 | 47.09 | 0.401 | 47.09 | 3.971 | 0.00 | 47.09 | 2.06 | 0.149 |
| HEAVY | QueueCap-4 | 46.93 | 9.39 | 23.46 | 46.93 | 0.377 | 46.93 | 3.240 | 0.19 | 47.02 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 46.73 | 9.62 | 23.97 | 46.73 | 0.376 | 46.73 | 5.321 | 0.84 | 47.13 | 1.72 | 0.194 |
| HEAVY | SafeProb-0.5 | 40.56 | 15.10 | 30.02 | 40.56 | 0.348 | 40.56 | 16.218 | 14.50 | 47.44 | 2.13 | 0.140 |
| LIGHT | QueueCap-4 | 81.12 | 17.38 | 42.32 | 81.12 | 0.655 | 81.12 | 1.497 | 18.81 | 99.92 | 1.70 | 0.197 |
| LIGHT | WorkCap-8 | 81.09 | 17.38 | 42.31 | 81.09 | 0.655 | 81.09 | 1.500 | 18.91 | 100.00 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 81.09 | 17.38 | 42.31 | 81.09 | 0.655 | 81.09 | 1.500 | 18.91 | 100.00 | 1.70 | 0.197 |
| LIGHT | SizeGate-0.2 | 81.09 | 17.38 | 42.31 | 81.09 | 0.655 | 81.09 | 1.500 | 18.91 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 81.08 | 17.36 | 42.29 | 81.08 | 0.655 | 81.08 | 1.501 | 18.92 | 100.00 | 1.70 | 0.197 |
| MEDIUM | WorkCap-8 | 83.93 | 17.65 | 43.25 | 83.93 | 0.677 | 83.93 | 1.532 | 15.85 | 99.73 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 83.92 | 17.66 | 43.26 | 83.92 | 0.677 | 83.92 | 1.538 | 16.08 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SizeGate-0.2 | 83.92 | 17.66 | 43.26 | 83.92 | 0.677 | 83.92 | 1.538 | 16.08 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 83.92 | 17.65 | 43.25 | 83.92 | 0.677 | 83.92 | 1.539 | 16.08 | 100.00 | 1.70 | 0.197 |
| MEDIUM | QueueCap-4 | 83.82 | 17.60 | 43.16 | 83.82 | 0.676 | 83.82 | 1.523 | 15.61 | 99.33 | 1.70 | 0.197 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 747.8 s (12.46 min).
