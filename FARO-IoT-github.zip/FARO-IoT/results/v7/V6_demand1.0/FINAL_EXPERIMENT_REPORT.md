# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 11:58:05 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 68.05 | 13.76 | 34.24 | 68.05 | 0.547 | 68.05 | 3.026 | 0.45 | 68.35 | 1.71 | 0.196 |
| HEAVY | FARO-IoT | 68.02 | 14.31 | 35.21 | 68.02 | 0.549 | 68.02 | 2.637 | 0.11 | 68.10 | 1.73 | 0.193 |
| HEAVY | WorkCap-8 | 51.56 | 10.60 | 26.16 | 51.56 | 0.415 | 51.56 | 4.877 | 0.54 | 51.84 | 1.71 | 0.195 |
| HEAVY | QueueCap-4 | 45.58 | 9.17 | 22.87 | 45.58 | 0.366 | 45.58 | 3.293 | 0.13 | 45.64 | 1.70 | 0.197 |
| HEAVY | SafeProb-0.5 | 27.15 | 5.55 | 13.74 | 27.15 | 0.218 | 27.15 | 16.121 | 0.75 | 27.36 | 1.71 | 0.196 |
| LIGHT | SafeProb-0.5 | 89.35 | 18.80 | 46.10 | 89.35 | 0.721 | 89.35 | 0.852 | 10.65 | 100.00 | 1.70 | 0.197 |
| LIGHT | SizeGate-0.2 | 89.35 | 18.80 | 46.10 | 89.35 | 0.721 | 89.35 | 0.852 | 10.65 | 100.00 | 1.70 | 0.197 |
| LIGHT | WorkCap-8 | 89.35 | 18.80 | 46.10 | 89.35 | 0.721 | 89.35 | 0.852 | 10.65 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 89.34 | 18.80 | 46.09 | 89.34 | 0.720 | 89.34 | 0.853 | 10.66 | 100.00 | 1.70 | 0.197 |
| LIGHT | QueueCap-4 | 89.28 | 18.79 | 46.06 | 89.28 | 0.720 | 89.28 | 0.853 | 10.65 | 99.92 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 91.79 | 19.03 | 46.89 | 91.79 | 0.739 | 91.79 | 0.885 | 8.21 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SizeGate-0.2 | 91.78 | 19.03 | 46.89 | 91.78 | 0.739 | 91.78 | 0.885 | 8.21 | 99.99 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 91.72 | 19.02 | 46.87 | 91.72 | 0.739 | 91.72 | 0.887 | 8.25 | 99.97 | 1.70 | 0.197 |
| MEDIUM | WorkCap-8 | 91.57 | 18.99 | 46.79 | 91.57 | 0.737 | 91.57 | 0.885 | 8.22 | 99.77 | 1.70 | 0.197 |
| MEDIUM | QueueCap-4 | 91.24 | 18.92 | 46.61 | 91.24 | 0.735 | 91.24 | 0.884 | 8.20 | 99.38 | 1.70 | 0.197 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 817.5 s (13.63 min).
