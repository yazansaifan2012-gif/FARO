# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    89.34     89.28     0.06     0.01     0.13         yes            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   LIGHT SafeProb-05    89.34     89.35    -0.01    -0.02    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   LIGHT SizeGate-02    89.34     89.35    -0.01    -0.02    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   LIGHT   WorkCap-8    89.34     89.35    -0.01    -0.02    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM  QueueCap-4    91.72     91.24     0.49     0.12     0.95         yes            +0.3%      +0.4%        +0.2%  +0.2%        yes             yes
  MEDIUM SafeProb-05    91.72     91.79    -0.06    -0.08    -0.05  no (worse)            +0.3%      +0.3%        +0.1%  +0.1%        yes             yes
  MEDIUM SizeGate-02    91.72     91.78    -0.06    -0.07    -0.05  no (worse)            +0.3%      +0.3%        +0.1%  +0.1%        yes             yes
  MEDIUM   WorkCap-8    91.72     91.57     0.15     0.02     0.32         yes            +0.3%      +0.3%        +0.1%  +0.1%        yes             yes
   HEAVY  QueueCap-4    68.02     45.58    22.44    20.80    24.03         yes           -19.9%     -16.0%       -12.9%  -9.5%        yes             yes
   HEAVY SafeProb-05    68.02     27.15    40.87    37.73    43.98         yes           -83.6%     -80.9%       -89.9% -86.3%        yes             yes
   HEAVY SizeGate-02    68.02     68.05    -0.02    -0.12     0.07        n.s.           -12.8%     -11.7%       -17.1% -15.6%        yes             yes
   HEAVY   WorkCap-8    68.02     51.56    16.46    15.11    17.70         yes           -45.9%     -42.7%       -35.5% -33.5%        yes             yes
