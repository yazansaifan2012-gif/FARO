# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    89.22     89.22     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT SafeProb-05    89.22     89.22     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT SizeGate-02    89.22     89.22     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT   WorkCap-8    89.22     89.22     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM  QueueCap-4    92.04     92.04     0.00     0.00     0.00        n.s.            -0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM SafeProb-05    92.04     92.04     0.00     0.00     0.00        n.s.            -0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM SizeGate-02    92.04     92.04     0.00     0.00     0.00        n.s.            -0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM   WorkCap-8    92.04     92.04     0.00     0.00     0.00        n.s.            -0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   HEAVY  QueueCap-4    84.53     84.39     0.14     0.12     0.16         yes            +7.3%      +8.7%       +21.9% +23.3%         no              no
   HEAVY SafeProb-05    84.53     80.78     3.75     3.15     4.37         yes           -66.4%     -64.0%       -75.3% -74.8%        yes             yes
   HEAVY SizeGate-02    84.53     84.53     0.00    -0.01     0.01        n.s.           -11.4%     -10.3%       -11.4% -10.9%        yes             yes
   HEAVY   WorkCap-8    84.53     84.33     0.19     0.15     0.23         yes           -21.4%     -19.8%       -18.5% -17.9%        yes             yes
