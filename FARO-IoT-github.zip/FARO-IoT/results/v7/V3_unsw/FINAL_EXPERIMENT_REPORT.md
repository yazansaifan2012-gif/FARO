# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 09:45:31 UTC

## 1. Dataset Audit

- Source: `toniot:<project>/data/UNSW_NB15/unsw_nb15_trace.csv (1 file(s); integer-second ties mode=spread)` (SHA-256 `eaf8978c884b5a43...`)
- Raw rows: 2,540,047 | Valid-timestamp rows: 2,540,047 | Invalid: 0
- Final task count used: 2,000,000
- Trace duration: 2319481.938 s | Mean arrival rate: 0.8623 tasks/s
- Payload (tcp.len) bytes: mean=3882.85, median=1540.00, std=8039.62, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3, 4, 5]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | FARO-IoT | 84.53 | 19.89 | 47.65 | 84.53 | 0.690 | 84.53 | 2.546 | 0.00 | 84.53 | 1.80 | 0.183 |
| HEAVY | SizeGate-0.2 | 84.53 | 16.95 | 42.31 | 84.53 | 0.679 | 84.53 | 2.873 | 0.00 | 84.53 | 1.70 | 0.197 |
| HEAVY | QueueCap-4 | 84.39 | 16.89 | 42.21 | 84.39 | 0.678 | 84.39 | 2.374 | 0.07 | 84.45 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 84.33 | 17.04 | 42.55 | 84.33 | 0.678 | 84.33 | 3.240 | 0.29 | 84.58 | 1.71 | 0.196 |
| HEAVY | SafeProb-0.5 | 80.78 | 18.97 | 45.01 | 80.78 | 0.659 | 80.78 | 7.582 | 4.84 | 84.89 | 1.80 | 0.183 |
| LIGHT | FARO-IoT | 89.22 | 18.77 | 46.01 | 89.22 | 0.719 | 89.22 | 0.855 | 10.78 | 100.00 | 1.70 | 0.197 |
| LIGHT | QueueCap-4 | 89.22 | 18.77 | 46.01 | 89.22 | 0.719 | 89.22 | 0.855 | 10.78 | 100.00 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 89.22 | 18.77 | 46.01 | 89.22 | 0.719 | 89.22 | 0.855 | 10.78 | 100.00 | 1.70 | 0.197 |
| LIGHT | SizeGate-0.2 | 89.22 | 18.77 | 46.01 | 89.22 | 0.719 | 89.22 | 0.855 | 10.78 | 100.00 | 1.70 | 0.197 |
| LIGHT | WorkCap-8 | 89.22 | 18.77 | 46.01 | 89.22 | 0.719 | 89.22 | 0.855 | 10.78 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 92.04 | 19.04 | 46.92 | 92.04 | 0.741 | 92.04 | 0.887 | 7.96 | 100.00 | 1.70 | 0.197 |
| MEDIUM | QueueCap-4 | 92.04 | 19.04 | 46.92 | 92.04 | 0.741 | 92.04 | 0.887 | 7.96 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 92.04 | 19.04 | 46.92 | 92.04 | 0.741 | 92.04 | 0.887 | 7.96 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SizeGate-0.2 | 92.04 | 19.04 | 46.92 | 92.04 | 0.741 | 92.04 | 0.887 | 7.96 | 100.00 | 1.70 | 0.197 |
| MEDIUM | WorkCap-8 | 92.04 | 19.04 | 46.92 | 92.04 | 0.741 | 92.04 | 0.887 | 7.96 | 100.00 | 1.70 | 0.197 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 1154.9 s (19.25 min).
