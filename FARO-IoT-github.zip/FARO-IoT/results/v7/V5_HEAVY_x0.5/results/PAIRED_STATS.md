# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   HEAVY  QueueCap-4    74.39     73.81     0.59     0.49     0.68         yes           +13.2%     +14.6%       +19.7% +21.6%         no              no
   HEAVY SafeProb-05    74.39     71.79     2.60     2.04     3.14         yes           -64.8%     -61.5%       -74.8% -74.5%        yes             yes
   HEAVY SizeGate-02    74.39     74.71    -0.32    -0.40    -0.24  no (worse)           -11.0%     -10.0%        -7.7%  -7.0%        yes             yes
   HEAVY   WorkCap-8    74.39     74.64    -0.25    -0.36    -0.15  no (worse)           -20.9%     -19.2%       -15.5% -14.5%        yes             yes
