# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    89.33     89.28     0.05     0.00     0.12         yes            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT SafeProb-05    89.33     89.36    -0.02    -0.02    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT SizeGate-02    89.33     89.36    -0.02    -0.02    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT   WorkCap-8    89.33     89.36    -0.02    -0.02    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
  MEDIUM  QueueCap-4    92.02     91.43     0.59     0.18     1.11         yes            +0.1%      +0.2%        +0.1%  +0.2%        yes             yes
  MEDIUM SafeProb-05    92.02     92.03    -0.01    -0.01    -0.00  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM SizeGate-02    92.02     92.03    -0.01    -0.01    -0.00  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM   WorkCap-8    92.02     91.79     0.23     0.07     0.44         yes            +0.1%      +0.1%        +0.0%  +0.1%        yes             yes
   HEAVY  QueueCap-4    47.09     46.92     0.17     0.14     0.20         yes           +22.9%     +24.0%        -7.8%  +7.8%         no              no
   HEAVY SafeProb-05    47.09     39.17     7.92     7.06     8.78         yes           -75.5%     -74.4%       -72.2% -71.9%        yes             yes
   HEAVY SizeGate-02    47.09     47.08     0.01    -0.02     0.03        n.s.            -9.8%      -8.9%        -6.3%  -5.9%        yes             yes
   HEAVY   WorkCap-8    47.09     46.50     0.58     0.50     0.66         yes           -25.2%     -23.8%       -28.9% -21.9%        yes             yes
