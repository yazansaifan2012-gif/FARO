# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 11:18:26 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | FARO-IoT | 47.09 | 16.19 | 33.51 | 47.09 | 0.400 | 47.09 | 3.980 | 0.03 | 47.10 | 2.06 | 0.149 |
| HEAVY | SizeGate-0.2 | 47.08 | 9.45 | 23.57 | 47.08 | 0.378 | 47.08 | 4.413 | 0.02 | 47.09 | 1.70 | 0.197 |
| HEAVY | QueueCap-4 | 46.92 | 9.39 | 23.46 | 46.92 | 0.377 | 46.92 | 3.239 | 0.21 | 47.01 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 46.50 | 9.55 | 23.77 | 46.50 | 0.374 | 46.50 | 5.321 | 1.31 | 47.12 | 1.72 | 0.194 |
| HEAVY | SafeProb-0.5 | 39.17 | 14.61 | 28.88 | 39.17 | 0.336 | 39.17 | 16.217 | 17.44 | 47.44 | 2.13 | 0.140 |
| LIGHT | SafeProb-0.5 | 89.36 | 18.80 | 46.10 | 89.36 | 0.721 | 89.36 | 0.852 | 10.64 | 100.00 | 1.70 | 0.197 |
| LIGHT | SizeGate-0.2 | 89.36 | 18.80 | 46.10 | 89.36 | 0.721 | 89.36 | 0.852 | 10.64 | 100.00 | 1.70 | 0.197 |
| LIGHT | WorkCap-8 | 89.36 | 18.80 | 46.10 | 89.36 | 0.721 | 89.36 | 0.853 | 10.64 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 89.33 | 18.80 | 46.09 | 89.33 | 0.720 | 89.33 | 0.854 | 10.67 | 100.00 | 1.70 | 0.197 |
| LIGHT | QueueCap-4 | 89.28 | 18.79 | 46.06 | 89.28 | 0.720 | 89.28 | 0.853 | 10.64 | 99.92 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 92.03 | 19.05 | 46.96 | 92.03 | 0.741 | 92.03 | 0.891 | 7.97 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SizeGate-0.2 | 92.03 | 19.05 | 46.96 | 92.03 | 0.741 | 92.03 | 0.891 | 7.97 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 92.02 | 19.05 | 46.95 | 92.02 | 0.741 | 92.02 | 0.892 | 7.98 | 100.00 | 1.70 | 0.197 |
| MEDIUM | WorkCap-8 | 91.79 | 19.00 | 46.83 | 91.79 | 0.739 | 91.79 | 0.891 | 7.97 | 99.74 | 1.70 | 0.197 |
| MEDIUM | QueueCap-4 | 91.43 | 18.92 | 46.65 | 91.43 | 0.736 | 91.43 | 0.891 | 7.96 | 99.34 | 1.70 | 0.197 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 734.3 s (12.24 min).
