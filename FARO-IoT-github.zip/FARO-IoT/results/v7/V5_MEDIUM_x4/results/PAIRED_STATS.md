# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
  MEDIUM  QueueCap-4    91.74     88.58     3.16     2.31     4.11         yes            -0.1%      +0.1%        -0.0%  +0.3%        yes             yes
  MEDIUM SafeProb-05    91.74     91.81    -0.07    -0.12    -0.03  no (worse)            +0.0%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM SizeGate-02    91.74     91.77    -0.03    -0.05    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.2%        yes             yes
  MEDIUM   WorkCap-8    91.74     91.11     0.63     0.30     1.03         yes            +0.2%      +0.2%        +0.1%  +0.3%        yes             yes
