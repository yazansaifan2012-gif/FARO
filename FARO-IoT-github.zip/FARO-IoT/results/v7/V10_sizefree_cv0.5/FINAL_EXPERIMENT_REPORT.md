# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 07:36:44 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 60.41 | 12.08 | 30.20 | 60.41 | 0.485 | 60.41 | 4.713 | 0.03 | 60.43 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 60.23 | 12.75 | 31.38 | 60.23 | 0.486 | 60.23 | 3.875 | 0.01 | 60.24 | 1.73 | 0.193 |
| HEAVY | FARO-IoT-NoPenalty | 60.23 | 12.75 | 31.38 | 60.23 | 0.486 | 60.23 | 3.875 | 0.01 | 60.24 | 1.73 | 0.193 |
| HEAVY | WorkCap-8 | 50.81 | 10.01 | 25.19 | 50.81 | 0.407 | 50.81 | 5.536 | 0.60 | 51.12 | 1.69 | 0.198 |
| HEAVY | FARO-IoT-NoToll | 50.24 | 6.51 | 20.04 | 50.24 | 0.392 | 50.24 | 15.881 | 1.54 | 51.02 | 1.53 | 0.219 |
| HEAVY | TS-Bandit-masked | 48.66 | 17.63 | 25.91 | 48.66 | 0.404 | 48.66 | 17.732 | 6.86 | 52.24 | 3.64 | 0.168 |
| HEAVY | RTD-adapted | 48.31 | 6.73 | 20.01 | 48.31 | 0.378 | 48.31 | 16.474 | 5.50 | 51.12 | 1.57 | 0.215 |
| HEAVY | SafeProb-0.5 | 47.51 | 6.61 | 19.66 | 47.51 | 0.372 | 47.51 | 16.591 | 7.06 | 51.12 | 1.57 | 0.215 |
| HEAVY | QueueCap-4 | 47.18 | 9.41 | 23.54 | 47.18 | 0.379 | 47.18 | 3.346 | 0.28 | 47.31 | 1.70 | 0.197 |
| HEAVY | FixedDepth-3 | 46.99 | 46.99 | 46.99 | 46.99 | 0.445 | 46.99 | 16.721 | 8.33 | 51.26 | 3.00 | 0.053 |
| HEAVY | SafeSlack | 40.68 | 6.36 | 17.96 | 40.68 | 0.321 | 40.68 | 17.190 | 20.69 | 51.29 | 1.70 | 0.197 |
| LIGHT | SafeSlack | 87.01 | 14.32 | 39.64 | 87.01 | 0.690 | 87.01 | 0.852 | 12.99 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT-NoToll | 87.01 | 14.31 | 39.64 | 87.01 | 0.690 | 87.01 | 0.853 | 12.99 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT-NoPenalty | 87.00 | 14.31 | 39.64 | 87.00 | 0.690 | 87.00 | 0.854 | 13.00 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 87.00 | 14.31 | 39.63 | 87.00 | 0.689 | 87.00 | 0.854 | 13.00 | 100.00 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 84.53 | 12.96 | 37.17 | 84.53 | 0.667 | 84.53 | 0.814 | 8.45 | 92.34 | 1.62 | 0.207 |
| LIGHT | RTD-adapted | 83.27 | 12.46 | 35.90 | 83.27 | 0.656 | 83.27 | 0.805 | 7.51 | 90.04 | 1.60 | 0.210 |
| LIGHT | SizeGate-0.2 | 83.27 | 12.46 | 35.90 | 83.27 | 0.656 | 83.27 | 0.805 | 7.51 | 90.04 | 1.60 | 0.210 |
| LIGHT | WorkCap-8 | 83.27 | 12.46 | 35.90 | 83.27 | 0.656 | 83.27 | 0.805 | 7.52 | 90.04 | 1.60 | 0.210 |
| LIGHT | QueueCap-4 | 83.24 | 12.45 | 35.89 | 83.24 | 0.655 | 83.24 | 0.805 | 7.52 | 90.00 | 1.60 | 0.210 |
| LIGHT | TS-Bandit-masked | 81.02 | 23.99 | 34.05 | 81.02 | 0.646 | 81.02 | 0.956 | 10.03 | 90.05 | 1.86 | 0.196 |
| LIGHT | FixedDepth-3 | 62.27 | 62.27 | 62.27 | 62.27 | 0.590 | 62.27 | 1.499 | 12.94 | 71.52 | 3.00 | 0.053 |
| MEDIUM | SafeSlack | 89.47 | 15.13 | 41.38 | 89.47 | 0.710 | 89.47 | 0.889 | 10.53 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT-NoPenalty | 89.44 | 15.11 | 41.36 | 89.44 | 0.710 | 89.44 | 0.890 | 10.54 | 99.98 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT-NoToll | 89.44 | 15.12 | 41.36 | 89.44 | 0.710 | 89.44 | 0.889 | 10.56 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 89.43 | 15.11 | 41.35 | 89.43 | 0.710 | 89.43 | 0.890 | 10.53 | 99.95 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 87.53 | 13.87 | 39.44 | 87.53 | 0.693 | 87.53 | 0.860 | 7.49 | 94.61 | 1.64 | 0.204 |
| MEDIUM | RTD-adapted | 86.27 | 13.37 | 38.18 | 86.27 | 0.681 | 86.27 | 0.850 | 6.55 | 92.31 | 1.62 | 0.207 |
| MEDIUM | SizeGate-0.2 | 86.27 | 13.37 | 38.18 | 86.27 | 0.681 | 86.27 | 0.850 | 6.55 | 92.31 | 1.62 | 0.207 |
| MEDIUM | WorkCap-8 | 86.10 | 13.34 | 38.11 | 86.10 | 0.680 | 86.10 | 0.851 | 6.55 | 92.14 | 1.62 | 0.207 |
| MEDIUM | QueueCap-4 | 85.77 | 13.29 | 37.96 | 85.77 | 0.677 | 85.77 | 0.850 | 6.54 | 91.77 | 1.62 | 0.207 |
| MEDIUM | TS-Bandit-masked | 83.46 | 19.56 | 36.23 | 83.46 | 0.665 | 83.46 | 1.076 | 9.60 | 92.33 | 1.86 | 0.196 |
| MEDIUM | FixedDepth-3 | 66.81 | 66.81 | 66.81 | 66.81 | 0.633 | 66.81 | 1.535 | 12.20 | 76.09 | 3.00 | 0.053 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 1813.1 s (30.22 min).
