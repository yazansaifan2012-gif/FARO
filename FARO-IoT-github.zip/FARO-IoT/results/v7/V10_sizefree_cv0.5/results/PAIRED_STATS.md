# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload         comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT FARO-IoT-NoPenalty    87.00     87.00    -0.01    -0.01    -0.01  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT    FARO-IoT-NoToll    87.00     87.01    -0.01    -0.01    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   LIGHT       FixedDepth-3    87.00     62.27    24.73    24.65    24.81         yes           -43.1%     -42.9%       -24.8% -24.4%        yes             yes
   LIGHT         QueueCap-4    87.00     83.24     3.76     3.72     3.80         yes            +6.1%      +6.1%        +4.0%  +4.2%        yes             yes
   LIGHT        RTD-adapted    87.00     83.27     3.72     3.69     3.75         yes            +6.1%      +6.2%        +4.0%  +4.2%        yes             yes
   LIGHT        SafeProb-05    87.00     84.53     2.46     2.44     2.49         yes            +4.8%      +4.9%        +3.2%  +3.3%        yes             yes
   LIGHT          SafeSlack    87.00     87.01    -0.02    -0.02    -0.01  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT        SizeGate-02    87.00     83.27     3.72     3.69     3.76         yes            +6.1%      +6.2%        +4.0%  +4.2%        yes             yes
   LIGHT   TS-Bandit-masked    87.00     81.02     5.98     5.91     6.06         yes           -10.7%     -10.3%       -12.0% -11.5%        yes             yes
   LIGHT          WorkCap-8    87.00     83.27     3.73     3.69     3.76         yes            +6.1%      +6.2%        +4.0%  +4.2%        yes             yes
  MEDIUM FARO-IoT-NoPenalty    89.43     89.44    -0.01    -0.02    -0.01  no (worse)            -0.0%      -0.0%        -0.0%  -0.0%        yes             yes
  MEDIUM    FARO-IoT-NoToll    89.43     89.44    -0.01    -0.02     0.00        n.s.            +0.1%      +0.1%        +0.0%  +0.0%        yes             yes
  MEDIUM       FixedDepth-3    89.43     66.81    22.62    22.53    22.70         yes           -42.0%     -41.9%       -24.4% -24.1%        yes             yes
  MEDIUM         QueueCap-4    89.43     85.77     3.66     3.31     4.09         yes            +4.7%      +4.8%        +3.2%  +3.3%        yes             yes
  MEDIUM        RTD-adapted    89.43     86.27     3.16     3.13     3.19         yes            +4.7%      +4.7%        +3.2%  +3.3%        yes             yes
  MEDIUM        SafeProb-05    89.43     87.53     1.90     1.88     1.92         yes            +3.5%      +3.6%        +2.5%  +2.6%        yes             yes
  MEDIUM          SafeSlack    89.43     89.47    -0.04    -0.05    -0.02  no (worse)            +0.2%      +0.2%        +0.0%  +0.1%        yes             yes
  MEDIUM        SizeGate-02    89.43     86.27     3.16     3.13     3.19         yes            +4.7%      +4.7%        +3.2%  +3.3%        yes             yes
  MEDIUM   TS-Bandit-masked    89.43     83.46     5.97     5.80     6.15         yes           -17.3%     -15.8%       -17.1% -16.0%        yes             yes
  MEDIUM          WorkCap-8    89.43     86.10     3.33     3.22     3.46         yes            +4.7%      +4.7%        +3.2%  +3.3%        yes             yes
   HEAVY FARO-IoT-NoPenalty    60.23     60.23     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   HEAVY    FARO-IoT-NoToll    60.23     50.24    10.00     9.19    10.78         yes           -75.6%     -74.1%       -70.9% -70.4%        yes             yes
   HEAVY       FixedDepth-3    60.23     46.99    13.24    12.20    14.27         yes           -76.8%     -75.5%       -72.4% -71.8%        yes             yes
   HEAVY         QueueCap-4    60.23     47.18    13.05    12.19    13.90         yes           +15.8%     +19.0%       -24.9%  -6.0%         no              no
   HEAVY        RTD-adapted    60.23     48.31    11.93    10.97    12.81         yes           -76.5%     -75.0%       -72.2% -71.6%        yes             yes
   HEAVY        SafeProb-05    60.23     47.51    12.72    11.66    13.72         yes           -76.6%     -75.2%       -72.3% -71.7%        yes             yes
   HEAVY          SafeSlack    60.23     40.68    19.56    17.96    20.98         yes           -77.5%     -76.0%       -73.4% -73.0%        yes             yes
   HEAVY        SizeGate-02    60.23     60.41    -0.18    -0.22    -0.14  no (worse)           -17.8%     -16.9%       -19.1% -18.5%        yes             yes
   HEAVY   TS-Bandit-masked    60.23     48.66    11.57    10.66    12.44         yes           -78.1%     -77.4%       -72.3% -71.7%        yes             yes
   HEAVY          WorkCap-8    60.23     50.81     9.42     8.70    10.09         yes           -30.0%     -27.4%       -65.8% -64.9%        yes             yes
