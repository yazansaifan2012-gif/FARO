# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   HEAVY  QueueCap-4    28.00     27.86     0.15     0.12     0.17         yes           +26.8%     +28.1%       -34.4% -33.9%         no              no
   HEAVY SafeProb-05    28.00     22.24     5.77     5.36     6.16         yes           -77.5%     -77.2%       -71.4% -71.3%        yes             yes
   HEAVY SizeGate-02    28.00     28.02    -0.01    -0.02    -0.00  no (worse)           -10.4%      -9.4%        -4.9%  -4.3%        yes             yes
   HEAVY   WorkCap-8    28.00     27.72     0.29     0.25     0.32         yes           -27.0%     -26.1%       -65.1% -64.8%        yes             yes
