# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    90.83     69.47    21.37    18.69    24.28         yes            -0.7%      +0.4%        -0.4%  +1.0%        yes             yes
   LIGHT SafeProb-05    90.83     90.86    -0.03    -0.04    -0.01  no (worse)            +0.4%      +0.5%        +0.4%  +0.5%        yes             yes
   LIGHT SizeGate-02    90.83     90.86    -0.03    -0.05    -0.01  no (worse)            +0.4%      +0.5%        +0.4%  +0.5%        yes             yes
   LIGHT   WorkCap-8    90.83     79.56    11.28     9.22    13.42         yes            -0.2%      +0.7%        +0.2%  +1.2%        yes             yes
