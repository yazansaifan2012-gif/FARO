# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    89.33     89.28     0.06     0.00     0.13         yes            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT SafeProb-05    89.33     89.36    -0.02    -0.02    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT SizeGate-02    89.33     89.36    -0.02    -0.02    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT   WorkCap-8    89.33     89.36    -0.02    -0.02    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
  MEDIUM  QueueCap-4    92.02     91.44     0.57     0.17     1.08         yes            +0.1%      +0.2%        +0.1%  +0.2%        yes             yes
  MEDIUM SafeProb-05    92.02     92.03    -0.01    -0.01    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM SizeGate-02    92.02     92.03    -0.01    -0.01    -0.01  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM   WorkCap-8    92.02     91.81     0.21     0.06     0.40         yes            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   HEAVY  QueueCap-4    47.04     46.87     0.17     0.12     0.22         yes           +23.0%     +24.1%        -3.6%  +2.5%         no              no
   HEAVY SafeProb-05    47.04     36.61    10.43     9.31    11.52         yes           -75.5%     -74.4%       -71.8% -71.5%        yes             yes
   HEAVY SizeGate-02    47.04     47.02     0.02    -0.03     0.06        n.s.            -9.9%      -8.9%        -6.4%  -6.0%        yes             yes
   HEAVY   WorkCap-8    47.04     46.37     0.66     0.56     0.76         yes           -25.2%     -23.8%       -34.9% -26.3%        yes             yes
