# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 09:58:26 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3, 4, 5]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.01, 0.5), ('STANDARD', 0.3, 0.001, 1.0), ('STRICT', 0.2, 0.0001, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | FARO-IoT | 47.13 | 47.13 | 47.13 | 47.13 | 0.470 | 47.13 | 8.141 | 0.00 | 47.13 | 7.43 | 0.004 |
| HEAVY | SizeGate-0.2 | 47.11 | 47.11 | 47.11 | 47.11 | 0.470 | 47.11 | 8.379 | 0.03 | 47.13 | 8.10 | 0.003 |
| HEAVY | QueueCap-4 | 46.94 | 46.94 | 46.94 | 46.94 | 0.468 | 46.94 | 6.468 | 0.17 | 47.02 | 8.10 | 0.003 |
| HEAVY | WorkCap-8 | 46.94 | 46.94 | 46.94 | 46.94 | 0.468 | 46.94 | 8.529 | 0.42 | 47.13 | 8.08 | 0.003 |
| HEAVY | SafeProb-0.5 | 43.92 | 43.92 | 43.92 | 43.92 | 0.438 | 43.92 | 20.572 | 7.52 | 47.50 | 7.64 | 0.003 |
| MEDIUM | FARO-IoT | 80.46 | 80.46 | 80.46 | 80.46 | 0.802 | 80.46 | 4.084 | 19.40 | 99.83 | 8.10 | 0.003 |
| MEDIUM | SafeProb-0.5 | 76.47 | 76.47 | 76.47 | 76.47 | 0.762 | 76.47 | 3.921 | 7.60 | 82.76 | 7.77 | 0.003 |
| MEDIUM | SizeGate-0.2 | 75.61 | 75.61 | 75.61 | 75.61 | 0.754 | 75.61 | 3.918 | 6.79 | 81.12 | 7.76 | 0.003 |
| MEDIUM | WorkCap-8 | 75.52 | 75.52 | 75.52 | 75.52 | 0.753 | 75.52 | 3.918 | 6.79 | 81.02 | 7.76 | 0.003 |
| MEDIUM | QueueCap-4 | 75.21 | 75.21 | 75.21 | 75.21 | 0.750 | 75.21 | 3.917 | 6.79 | 80.69 | 7.76 | 0.003 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 768.4 s (12.81 min).
