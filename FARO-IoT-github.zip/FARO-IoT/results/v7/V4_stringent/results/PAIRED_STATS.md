# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
  MEDIUM  QueueCap-4    80.46     75.21     5.25     5.02     5.54         yes            +4.3%      +4.3%        +3.3%  +3.4%        yes             yes
  MEDIUM SafeProb-05    80.46     76.47     3.99     3.94     4.04         yes            +4.2%      +4.2%        +3.2%  +3.3%        yes             yes
  MEDIUM SizeGate-02    80.46     75.61     4.86     4.79     4.92         yes            +4.3%      +4.3%        +3.3%  +3.4%        yes             yes
  MEDIUM   WorkCap-8    80.46     75.52     4.94     4.86     5.02         yes            +4.3%      +4.3%        +3.3%  +3.4%        yes             yes
   HEAVY  QueueCap-4    47.13     46.94     0.19     0.15     0.23         yes           +25.9%     +27.6%        +1.8%  +4.0%         no              no
   HEAVY SafeProb-05    47.13     43.92     3.21     2.89     3.50         yes           -60.4%     -59.0%       -59.9% -59.5%        yes             yes
   HEAVY SizeGate-02    47.13     47.11     0.02     0.01     0.02         yes            -2.8%      -2.6%        -5.4%  -5.1%        yes             yes
   HEAVY   WorkCap-8    47.13     46.94     0.19     0.17     0.21         yes            -4.6%      -4.2%       -21.4% -14.9%        yes             yes
