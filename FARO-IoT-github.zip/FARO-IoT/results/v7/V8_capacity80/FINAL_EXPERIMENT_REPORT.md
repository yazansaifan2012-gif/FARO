# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 12:56:38 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 47.10 | 9.45 | 23.58 | 47.10 | 0.378 | 47.10 | 4.415 | 0.00 | 47.10 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 47.09 | 16.21 | 33.57 | 47.09 | 0.401 | 47.09 | 3.972 | 0.00 | 47.09 | 2.06 | 0.149 |
| HEAVY | QueueCap-4 | 46.93 | 9.39 | 23.46 | 46.93 | 0.377 | 46.93 | 3.242 | 0.19 | 47.02 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 46.73 | 9.62 | 23.96 | 46.73 | 0.376 | 46.73 | 5.322 | 0.84 | 47.13 | 1.72 | 0.194 |
| HEAVY | SafeProb-0.5 | 40.54 | 15.09 | 30.01 | 40.54 | 0.348 | 40.54 | 16.219 | 14.53 | 47.44 | 2.13 | 0.140 |
| LIGHT | QueueCap-4 | 63.42 | 13.76 | 33.32 | 63.42 | 0.513 | 63.42 | 17.561 | 36.52 | 99.92 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 63.42 | 13.76 | 33.32 | 63.42 | 0.513 | 63.42 | 17.674 | 36.58 | 100.00 | 1.70 | 0.197 |
| LIGHT | SizeGate-0.2 | 63.42 | 13.76 | 33.32 | 63.42 | 0.513 | 63.42 | 17.674 | 36.58 | 100.00 | 1.70 | 0.197 |
| LIGHT | WorkCap-8 | 63.41 | 13.76 | 33.32 | 63.41 | 0.513 | 63.41 | 17.674 | 36.59 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 63.40 | 13.75 | 33.30 | 63.40 | 0.513 | 63.40 | 17.675 | 36.60 | 100.00 | 1.70 | 0.197 |
| MEDIUM | QueueCap-4 | 66.06 | 14.08 | 34.29 | 66.06 | 0.533 | 66.06 | 16.972 | 33.49 | 99.33 | 1.70 | 0.197 |
| MEDIUM | WorkCap-8 | 65.88 | 14.03 | 34.19 | 65.88 | 0.532 | 65.88 | 17.358 | 33.95 | 99.73 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 65.82 | 14.01 | 34.14 | 65.82 | 0.531 | 65.82 | 17.713 | 34.18 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 65.82 | 14.01 | 34.15 | 65.82 | 0.531 | 65.82 | 17.713 | 34.18 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SizeGate-0.2 | 65.82 | 14.01 | 34.15 | 65.82 | 0.531 | 65.82 | 17.713 | 34.18 | 100.00 | 1.70 | 0.197 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 760.9 s (12.68 min).
