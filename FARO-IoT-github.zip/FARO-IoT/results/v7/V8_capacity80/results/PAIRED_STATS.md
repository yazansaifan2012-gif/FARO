# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    63.40     63.42    -0.02    -0.04    -0.01  no (worse)            +0.7%      +1.5%        -0.0%  +5.0%        yes             yes
   LIGHT SafeProb-05    63.40     63.42    -0.01    -0.02    -0.01  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT SizeGate-02    63.40     63.42    -0.01    -0.02    -0.01  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT   WorkCap-8    63.40     63.41    -0.01    -0.02    -0.01  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM  QueueCap-4    65.82     66.06    -0.25    -0.56    -0.03  no (worse)            +4.4%      +9.9%        +0.2% +16.7%         no             yes
  MEDIUM SafeProb-05    65.82     65.82     0.00    -0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM SizeGate-02    65.82     65.82     0.00    -0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM   WorkCap-8    65.82     65.88    -0.06    -0.18     0.00        n.s.            +2.0%      +4.7%        -0.1% +13.2%         no             yes
   HEAVY  QueueCap-4    47.09     46.93     0.16     0.13     0.18         yes           +22.5%     +23.8%       -10.5%  +7.5%         no              no
   HEAVY SafeProb-05    47.09     40.54     6.55     5.83     7.25         yes           -75.5%     -74.4%       -72.4% -72.1%        yes             yes
   HEAVY SizeGate-02    47.09     47.10    -0.01    -0.02     0.01        n.s.           -10.0%      -9.2%        -6.3%  -5.9%        yes             yes
   HEAVY   WorkCap-8    47.09     46.73     0.36     0.29     0.41         yes           -25.4%     -24.1%       -29.1% -22.1%        yes             yes
