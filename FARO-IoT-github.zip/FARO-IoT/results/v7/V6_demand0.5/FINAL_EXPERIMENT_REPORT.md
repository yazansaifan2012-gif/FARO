# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 11:44:22 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 60.14 | 12.05 | 30.09 | 60.14 | 0.483 | 60.14 | 4.061 | 0.08 | 60.18 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 59.86 | 13.01 | 31.72 | 59.86 | 0.485 | 59.86 | 3.423 | 0.01 | 59.86 | 1.75 | 0.191 |
| HEAVY | WorkCap-8 | 49.32 | 9.91 | 24.72 | 49.32 | 0.396 | 49.32 | 5.095 | 0.20 | 49.42 | 1.70 | 0.197 |
| HEAVY | QueueCap-4 | 46.67 | 9.35 | 23.34 | 46.67 | 0.375 | 46.67 | 3.244 | 0.08 | 46.70 | 1.70 | 0.197 |
| HEAVY | SafeProb-0.5 | 34.64 | 7.21 | 17.70 | 34.64 | 0.279 | 34.64 | 15.651 | 1.34 | 35.11 | 1.72 | 0.194 |
| LIGHT | SafeProb-0.5 | 89.36 | 18.80 | 46.10 | 89.36 | 0.721 | 89.36 | 0.852 | 10.64 | 100.00 | 1.70 | 0.197 |
| LIGHT | SizeGate-0.2 | 89.36 | 18.80 | 46.10 | 89.36 | 0.721 | 89.36 | 0.852 | 10.64 | 100.00 | 1.70 | 0.197 |
| LIGHT | WorkCap-8 | 89.36 | 18.80 | 46.10 | 89.36 | 0.721 | 89.36 | 0.852 | 10.64 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 89.34 | 18.80 | 46.09 | 89.34 | 0.720 | 89.34 | 0.854 | 10.66 | 100.00 | 1.70 | 0.197 |
| LIGHT | QueueCap-4 | 89.28 | 18.79 | 46.06 | 89.28 | 0.720 | 89.28 | 0.853 | 10.64 | 99.92 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 91.95 | 19.04 | 46.93 | 91.95 | 0.740 | 91.95 | 0.889 | 8.05 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SizeGate-0.2 | 91.95 | 19.04 | 46.93 | 91.95 | 0.740 | 91.95 | 0.889 | 8.05 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 91.92 | 19.04 | 46.92 | 91.92 | 0.740 | 91.92 | 0.890 | 8.07 | 99.99 | 1.70 | 0.197 |
| MEDIUM | WorkCap-8 | 91.72 | 19.00 | 46.82 | 91.72 | 0.739 | 91.72 | 0.889 | 8.05 | 99.75 | 1.70 | 0.197 |
| MEDIUM | QueueCap-4 | 91.38 | 18.92 | 46.63 | 91.38 | 0.736 | 91.38 | 0.888 | 8.03 | 99.36 | 1.70 | 0.197 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 808.7 s (13.48 min).
