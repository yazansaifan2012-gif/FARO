# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    89.34     89.28     0.06     0.00     0.12         yes            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   LIGHT SafeProb-05    89.34     89.36    -0.02    -0.02    -0.02  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   LIGHT SizeGate-02    89.34     89.36    -0.02    -0.02    -0.02  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
   LIGHT   WorkCap-8    89.34     89.36    -0.02    -0.02    -0.02  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM  QueueCap-4    91.92     91.38     0.55     0.15     1.05         yes            +0.2%      +0.3%        +0.1%  +0.2%        yes             yes
  MEDIUM SafeProb-05    91.92     91.95    -0.03    -0.04    -0.03  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
  MEDIUM SizeGate-02    91.92     91.95    -0.03    -0.04    -0.03  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
  MEDIUM   WorkCap-8    91.92     91.72     0.20     0.05     0.40         yes            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   HEAVY  QueueCap-4    59.86     46.67    13.19    12.27    14.08         yes            +5.5%      +8.0%        -4.5%  +1.3%        yes             yes
   HEAVY SafeProb-05    59.86     34.64    25.21    23.23    27.20         yes           -78.1%     -75.9%       -82.9% -82.4%        yes             yes
   HEAVY SizeGate-02    59.86     60.14    -0.28    -0.33    -0.23  no (worse)           -15.7%     -14.7%       -17.8% -16.6%        yes             yes
   HEAVY   WorkCap-8    59.86     49.32    10.53     9.69    11.31         yes           -32.8%     -30.1%       -26.6% -24.5%        yes             yes
