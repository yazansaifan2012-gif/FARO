# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
  MEDIUM  QueueCap-4    86.44     74.05    12.39    10.80    14.08         yes            +3.3%      +4.2%        +2.0%  +2.9%        yes             yes
  MEDIUM SafeProb-05    86.44     85.97     0.48    -0.11     1.13        n.s.            -7.5%      -5.8%        -5.6%  -4.2%        yes             yes
  MEDIUM SizeGate-02    86.44     86.85    -0.41    -0.68    -0.16  no (worse)            -0.9%      -0.6%        +0.1%  +0.5%        yes             yes
  MEDIUM   WorkCap-8    86.44     83.88     2.57     2.04     3.10         yes            +3.0%      +3.8%        +1.7%  +2.3%        yes             yes
