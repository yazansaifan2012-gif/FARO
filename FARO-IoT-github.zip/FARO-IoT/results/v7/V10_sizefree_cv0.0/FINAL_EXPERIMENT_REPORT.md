# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 07:06:20 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 47.10 | 9.42 | 23.54 | 47.10 | 0.378 | 47.10 | 4.512 | 0.00 | 47.10 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 47.09 | 15.76 | 32.91 | 47.09 | 0.399 | 47.09 | 4.033 | 0.00 | 47.09 | 2.03 | 0.152 |
| HEAVY | FARO-IoT-NoPenalty | 47.09 | 15.76 | 32.91 | 47.09 | 0.399 | 47.09 | 4.033 | 0.00 | 47.09 | 2.03 | 0.152 |
| HEAVY | QueueCap-4 | 46.95 | 9.38 | 23.45 | 46.95 | 0.377 | 46.95 | 3.240 | 0.15 | 47.02 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 46.89 | 9.27 | 23.29 | 46.89 | 0.376 | 46.89 | 5.308 | 0.52 | 47.13 | 1.69 | 0.198 |
| HEAVY | FARO-IoT-NoToll | 46.58 | 5.85 | 18.21 | 46.58 | 0.363 | 46.58 | 15.716 | 1.79 | 47.43 | 1.52 | 0.221 |
| HEAVY | RTD-adapted | 44.48 | 6.02 | 18.09 | 44.48 | 0.348 | 44.48 | 16.285 | 6.24 | 47.44 | 1.55 | 0.216 |
| HEAVY | TS-Bandit-masked | 43.84 | 17.29 | 24.07 | 43.84 | 0.368 | 43.84 | 17.677 | 7.60 | 47.45 | 4.05 | 0.162 |
| HEAVY | SafeProb-0.5 | 43.65 | 5.91 | 17.75 | 43.65 | 0.341 | 43.65 | 16.399 | 8.00 | 47.45 | 1.56 | 0.216 |
| HEAVY | FixedDepth-3 | 42.99 | 42.99 | 42.99 | 42.99 | 0.407 | 42.99 | 16.532 | 9.36 | 47.43 | 3.00 | 0.053 |
| HEAVY | SafeSlack | 36.51 | 5.60 | 15.91 | 36.51 | 0.288 | 36.51 | 16.967 | 23.07 | 47.46 | 1.70 | 0.197 |
| LIGHT | SafeSlack | 87.01 | 14.32 | 39.64 | 87.01 | 0.690 | 87.01 | 0.852 | 12.99 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT-NoToll | 87.01 | 14.31 | 39.64 | 87.01 | 0.690 | 87.01 | 0.853 | 12.99 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT-NoPenalty | 87.00 | 14.31 | 39.64 | 87.00 | 0.690 | 87.00 | 0.854 | 13.00 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 87.00 | 14.31 | 39.63 | 87.00 | 0.689 | 87.00 | 0.854 | 13.00 | 100.00 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 84.53 | 12.96 | 37.17 | 84.53 | 0.667 | 84.53 | 0.814 | 8.45 | 92.34 | 1.62 | 0.207 |
| LIGHT | RTD-adapted | 83.27 | 12.46 | 35.90 | 83.27 | 0.656 | 83.27 | 0.805 | 7.51 | 90.04 | 1.60 | 0.210 |
| LIGHT | SizeGate-0.2 | 83.27 | 12.46 | 35.90 | 83.27 | 0.656 | 83.27 | 0.805 | 7.51 | 90.04 | 1.60 | 0.210 |
| LIGHT | WorkCap-8 | 83.27 | 12.46 | 35.90 | 83.27 | 0.656 | 83.27 | 0.805 | 7.52 | 90.04 | 1.60 | 0.210 |
| LIGHT | QueueCap-4 | 83.24 | 12.45 | 35.89 | 83.24 | 0.655 | 83.24 | 0.805 | 7.52 | 90.00 | 1.60 | 0.210 |
| LIGHT | TS-Bandit-masked | 81.05 | 24.11 | 34.10 | 81.05 | 0.647 | 81.05 | 0.954 | 9.99 | 90.05 | 1.86 | 0.196 |
| LIGHT | FixedDepth-3 | 62.27 | 62.27 | 62.27 | 62.27 | 0.590 | 62.27 | 1.499 | 12.94 | 71.52 | 3.00 | 0.053 |
| MEDIUM | SafeSlack | 89.43 | 15.11 | 41.35 | 89.43 | 0.710 | 89.43 | 0.891 | 10.57 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT-NoPenalty | 89.43 | 15.11 | 41.35 | 89.43 | 0.710 | 89.43 | 0.892 | 10.55 | 99.98 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT-NoToll | 89.43 | 15.11 | 41.35 | 89.43 | 0.710 | 89.43 | 0.891 | 10.57 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 89.42 | 15.11 | 41.34 | 89.42 | 0.710 | 89.42 | 0.892 | 10.54 | 99.96 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 87.49 | 13.86 | 39.41 | 87.49 | 0.692 | 87.49 | 0.862 | 7.51 | 94.59 | 1.64 | 0.204 |
| MEDIUM | RTD-adapted | 86.23 | 13.36 | 38.15 | 86.23 | 0.681 | 86.23 | 0.853 | 6.56 | 92.29 | 1.62 | 0.207 |
| MEDIUM | SizeGate-0.2 | 86.23 | 13.36 | 38.15 | 86.23 | 0.681 | 86.23 | 0.853 | 6.56 | 92.29 | 1.62 | 0.207 |
| MEDIUM | WorkCap-8 | 86.06 | 13.33 | 38.08 | 86.06 | 0.680 | 86.06 | 0.853 | 6.57 | 92.11 | 1.62 | 0.207 |
| MEDIUM | QueueCap-4 | 85.71 | 13.28 | 37.92 | 85.71 | 0.677 | 85.71 | 0.853 | 6.56 | 91.73 | 1.62 | 0.207 |
| MEDIUM | TS-Bandit-masked | 83.95 | 22.42 | 36.26 | 83.95 | 0.669 | 83.95 | 1.031 | 9.05 | 92.30 | 1.81 | 0.196 |
| MEDIUM | FixedDepth-3 | 66.75 | 66.75 | 66.75 | 66.75 | 0.632 | 66.75 | 1.538 | 12.23 | 76.05 | 3.00 | 0.053 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 1666.5 s (27.78 min).
