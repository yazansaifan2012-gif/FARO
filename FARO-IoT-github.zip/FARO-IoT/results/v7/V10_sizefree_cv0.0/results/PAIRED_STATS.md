# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload         comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT FARO-IoT-NoPenalty    87.00     87.00    -0.01    -0.01    -0.01  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT    FARO-IoT-NoToll    87.00     87.01    -0.01    -0.01    -0.01  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT       FixedDepth-3    87.00     62.27    24.73    24.65    24.81         yes           -43.0%     -42.9%       -24.8% -24.4%        yes             yes
   LIGHT         QueueCap-4    87.00     83.24     3.76     3.72     3.80         yes            +6.1%      +6.2%        +4.1%  +4.2%        yes             yes
   LIGHT        RTD-adapted    87.00     83.27     3.72     3.69     3.75         yes            +6.1%      +6.2%        +4.1%  +4.2%        yes             yes
   LIGHT        SafeProb-05    87.00     84.53     2.46     2.44     2.49         yes            +4.9%      +4.9%        +3.2%  +3.3%        yes             yes
   LIGHT          SafeSlack    87.00     87.01    -0.02    -0.02    -0.01  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT        SizeGate-02    87.00     83.27     3.72     3.69     3.75         yes            +6.1%      +6.2%        +4.1%  +4.2%        yes             yes
   LIGHT   TS-Bandit-masked    87.00     81.05     5.94     5.88     6.03         yes           -10.5%     -10.1%       -11.8% -11.3%        yes             yes
   LIGHT          WorkCap-8    87.00     83.27     3.72     3.69     3.76         yes            +6.1%      +6.2%        +4.1%  +4.2%        yes             yes
  MEDIUM FARO-IoT-NoPenalty    89.42     89.43    -0.01    -0.02    -0.00  no (worse)            -0.0%      -0.0%        -0.0%  +0.0%        yes             yes
  MEDIUM    FARO-IoT-NoToll    89.42     89.43    -0.01    -0.02    -0.00  no (worse)            +0.0%      +0.1%        -0.0%  +0.0%        yes             yes
  MEDIUM       FixedDepth-3    89.42     66.75    22.67    22.58    22.75         yes           -42.0%     -41.9%       -24.4% -24.1%        yes             yes
  MEDIUM         QueueCap-4    89.42     85.71     3.71     3.34     4.16         yes            +4.6%      +4.6%        +3.2%  +3.3%        yes             yes
  MEDIUM        RTD-adapted    89.42     86.23     3.19     3.16     3.22         yes            +4.5%      +4.6%        +3.2%  +3.2%        yes             yes
  MEDIUM        SafeProb-05    89.42     87.49     1.93     1.90     1.95         yes            +3.4%      +3.4%        +2.5%  +2.5%        yes             yes
  MEDIUM          SafeSlack    89.42     89.43    -0.01    -0.03    -0.00  no (worse)            +0.0%      +0.1%        +0.0%  +0.0%        yes             yes
  MEDIUM        SizeGate-02    89.42     86.23     3.19     3.16     3.22         yes            +4.5%      +4.6%        +3.2%  +3.2%        yes             yes
  MEDIUM   TS-Bandit-masked    89.42     83.95     5.47     5.29     5.65         yes           -13.5%     -12.2%       -15.2% -13.7%        yes             yes
  MEDIUM          WorkCap-8    89.42     86.06     3.36     3.24     3.50         yes            +4.5%      +4.6%        +3.1%  +3.2%        yes             yes
   HEAVY FARO-IoT-NoPenalty    47.09     47.09     0.00     0.00     0.00        n.s.            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   HEAVY    FARO-IoT-NoToll    47.09     46.58     0.51     0.22     0.74         yes           -74.3%     -73.2%       -71.3% -71.0%        yes             yes
   HEAVY       FixedDepth-3    47.09     42.99     4.10     3.61     4.56         yes           -75.6%     -74.6%       -72.5% -72.2%        yes             yes
   HEAVY         QueueCap-4    47.09     46.95     0.14     0.12     0.17         yes           +24.5%     +25.9%        -9.9%  +8.1%         no              no
   HEAVY        RTD-adapted    47.09     44.48     2.61     2.19     2.98         yes           -75.2%     -74.1%       -72.3% -72.0%        yes             yes
   HEAVY        SafeProb-05    47.09     43.65     3.44     2.95     3.90         yes           -75.4%     -74.3%       -72.4% -72.1%        yes             yes
   HEAVY          SafeSlack    47.09     36.51    10.58     9.56    11.54         yes           -76.2%     -75.1%       -73.6% -73.3%        yes             yes
   HEAVY        SizeGate-02    47.09     47.10    -0.01    -0.03     0.01        n.s.           -10.6%      -9.8%        -8.3%  -7.9%        yes             yes
   HEAVY   TS-Bandit-masked    47.09     43.84     3.25     2.82     3.66         yes           -77.2%     -76.9%       -72.4% -72.1%        yes             yes
   HEAVY          WorkCap-8    47.09     46.89     0.20     0.15     0.24         yes           -24.0%     -22.8%       -28.7% -21.4%        yes             yes
