# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 13:35:23 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=1.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 47.11 | 9.43 | 23.55 | 47.11 | 0.378 | 47.11 | 5.654 | 0.00 | 47.11 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 47.10 | 14.16 | 31.77 | 47.10 | 0.396 | 47.10 | 5.166 | 0.00 | 47.10 | 1.98 | 0.159 |
| HEAVY | QueueCap-4 | 46.93 | 9.35 | 23.41 | 46.93 | 0.377 | 46.93 | 4.116 | 0.21 | 47.02 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 46.90 | 9.26 | 23.26 | 46.90 | 0.376 | 46.90 | 6.180 | 0.48 | 47.13 | 1.69 | 0.198 |
| HEAVY | SafeProb-0.5 | 42.93 | 5.73 | 17.32 | 42.93 | 0.335 | 42.93 | 18.310 | 9.59 | 47.49 | 1.55 | 0.216 |
| LIGHT | FARO-IoT | 86.87 | 14.29 | 39.56 | 86.87 | 0.688 | 86.87 | 1.711 | 13.13 | 100.00 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 84.39 | 12.92 | 37.07 | 84.39 | 0.666 | 84.39 | 1.633 | 8.60 | 92.32 | 1.62 | 0.207 |
| LIGHT | SizeGate-0.2 | 83.14 | 12.43 | 35.82 | 83.14 | 0.654 | 83.14 | 1.613 | 7.65 | 90.02 | 1.60 | 0.210 |
| LIGHT | WorkCap-8 | 83.14 | 12.43 | 35.82 | 83.14 | 0.654 | 83.14 | 1.613 | 7.65 | 90.02 | 1.60 | 0.210 |
| LIGHT | QueueCap-4 | 83.11 | 12.42 | 35.81 | 83.11 | 0.654 | 83.11 | 1.614 | 7.65 | 89.99 | 1.60 | 0.210 |
| MEDIUM | FARO-IoT | 88.14 | 14.69 | 40.44 | 88.14 | 0.699 | 88.14 | 1.749 | 11.84 | 99.99 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 85.90 | 13.37 | 38.20 | 85.90 | 0.679 | 85.90 | 1.681 | 8.08 | 93.45 | 1.63 | 0.206 |
| MEDIUM | SizeGate-0.2 | 84.65 | 12.87 | 36.95 | 84.65 | 0.667 | 84.65 | 1.662 | 7.13 | 91.15 | 1.61 | 0.208 |
| MEDIUM | WorkCap-8 | 84.49 | 12.85 | 36.88 | 84.49 | 0.666 | 84.49 | 1.662 | 7.13 | 90.98 | 1.61 | 0.208 |
| MEDIUM | QueueCap-4 | 84.14 | 12.79 | 36.72 | 84.14 | 0.663 | 84.14 | 1.662 | 7.14 | 90.60 | 1.61 | 0.208 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 729.5 s (12.16 min).
