# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    86.87     83.11     3.77     3.72     3.82         yes            +6.0%      +6.1%        +3.9%  +4.1%        yes             yes
   LIGHT SafeProb-05    86.87     84.39     2.48     2.45     2.52         yes            +4.7%      +4.8%        +3.1%  +3.3%        yes             yes
   LIGHT SizeGate-02    86.87     83.14     3.73     3.69     3.78         yes            +6.0%      +6.1%        +3.9%  +4.1%        yes             yes
   LIGHT   WorkCap-8    86.87     83.14     3.73     3.69     3.78         yes            +6.0%      +6.1%        +3.9%  +4.1%        yes             yes
  MEDIUM  QueueCap-4    88.14     84.14     4.01     3.64     4.47         yes            +5.2%      +5.3%        +3.5%  +3.6%        yes             yes
  MEDIUM SafeProb-05    88.14     85.90     2.24     2.21     2.27         yes            +4.0%      +4.0%        +2.8%  +2.9%        yes             yes
  MEDIUM SizeGate-02    88.14     84.65     3.49     3.45     3.53         yes            +5.2%      +5.3%        +3.5%  +3.6%        yes             yes
  MEDIUM   WorkCap-8    88.14     84.49     3.66     3.53     3.80         yes            +5.2%      +5.2%        +3.5%  +3.6%        yes             yes
   HEAVY  QueueCap-4    47.10     46.93     0.17     0.15     0.20         yes           +25.5%     +27.2%        -7.2%  -2.3%         no              no
   HEAVY SafeProb-05    47.10     42.93     4.16     3.63     4.66         yes           -71.8%     -70.5%       -66.8% -66.4%        yes             yes
   HEAVY SizeGate-02    47.10     47.11    -0.01    -0.03     0.00        n.s.            -8.6%      -7.8%        -4.9%  -4.5%        yes             yes
   HEAVY   WorkCap-8    47.10     46.90     0.19     0.15     0.23         yes           -16.4%     -15.3%       -30.6% -21.5%        yes             yes
