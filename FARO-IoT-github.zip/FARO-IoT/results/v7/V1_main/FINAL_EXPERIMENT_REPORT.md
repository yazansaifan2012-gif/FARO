# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 09:08:21 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3, 4, 5]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 47.10 | 9.47 | 23.58 | 47.10 | 0.378 | 47.10 | 4.414 | 0.00 | 47.10 | 1.70 | 0.197 |
| HEAVY | FARO-IoT | 47.09 | 16.22 | 33.57 | 47.09 | 0.401 | 47.09 | 3.971 | 0.00 | 47.09 | 2.06 | 0.149 |
| HEAVY | QueueCap-4 | 46.93 | 9.40 | 23.47 | 46.93 | 0.377 | 46.93 | 3.240 | 0.19 | 47.02 | 1.70 | 0.197 |
| HEAVY | WorkCap-8 | 46.74 | 9.63 | 23.98 | 46.74 | 0.377 | 46.74 | 5.321 | 0.84 | 47.13 | 1.72 | 0.194 |
| HEAVY | SafeProb-0.5 | 40.55 | 15.11 | 30.02 | 40.55 | 0.348 | 40.55 | 16.218 | 14.51 | 47.43 | 2.13 | 0.140 |
| LIGHT | SafeProb-0.5 | 89.36 | 18.81 | 46.10 | 89.36 | 0.721 | 89.36 | 0.852 | 10.64 | 100.00 | 1.70 | 0.197 |
| LIGHT | SizeGate-0.2 | 89.36 | 18.81 | 46.10 | 89.36 | 0.721 | 89.36 | 0.852 | 10.64 | 100.00 | 1.70 | 0.197 |
| LIGHT | WorkCap-8 | 89.36 | 18.81 | 46.10 | 89.36 | 0.721 | 89.36 | 0.852 | 10.64 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 89.34 | 18.81 | 46.09 | 89.34 | 0.720 | 89.34 | 0.854 | 10.66 | 100.00 | 1.70 | 0.197 |
| LIGHT | QueueCap-4 | 89.29 | 18.80 | 46.06 | 89.29 | 0.720 | 89.29 | 0.852 | 10.64 | 99.92 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 92.05 | 19.06 | 46.95 | 92.05 | 0.741 | 92.05 | 0.891 | 7.95 | 100.00 | 1.70 | 0.197 |
| MEDIUM | SizeGate-0.2 | 92.05 | 19.06 | 46.95 | 92.05 | 0.741 | 92.05 | 0.891 | 7.95 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 92.04 | 19.06 | 46.95 | 92.04 | 0.741 | 92.04 | 0.892 | 7.96 | 100.00 | 1.70 | 0.197 |
| MEDIUM | WorkCap-8 | 91.79 | 19.01 | 46.83 | 91.79 | 0.739 | 91.79 | 0.892 | 7.96 | 99.73 | 1.70 | 0.197 |
| MEDIUM | QueueCap-4 | 91.43 | 18.93 | 46.64 | 91.43 | 0.736 | 91.43 | 0.891 | 7.96 | 99.33 | 1.70 | 0.197 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 1099.4 s (18.32 min).
