# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload  comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT  QueueCap-4    89.34     89.29     0.05     0.01     0.10         yes            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT SafeProb-05    89.34     89.36    -0.02    -0.02    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT SizeGate-02    89.34     89.36    -0.02    -0.02    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
   LIGHT   WorkCap-8    89.34     89.36    -0.02    -0.02    -0.02  no (worse)            +0.2%      +0.2%        +0.1%  +0.1%        yes             yes
  MEDIUM  QueueCap-4    92.04     91.43     0.61     0.27     1.02         yes            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM SafeProb-05    92.04     92.05    -0.01    -0.01    -0.00  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM SizeGate-02    92.04     92.05    -0.01    -0.01    -0.00  no (worse)            +0.1%      +0.1%        +0.1%  +0.1%        yes             yes
  MEDIUM   WorkCap-8    92.04     91.79     0.25     0.11     0.41         yes            +0.0%      +0.1%        +0.0%  +0.1%        yes             yes
   HEAVY  QueueCap-4    47.09     46.93     0.16     0.14     0.18         yes           +22.6%     +23.6%        -9.7%  +5.1%         no              no
   HEAVY SafeProb-05    47.09     40.55     6.53     5.97     7.08         yes           -75.5%     -74.7%       -72.5% -72.2%        yes             yes
   HEAVY SizeGate-02    47.09     47.10    -0.01    -0.03    -0.00  no (worse)           -10.0%      -9.4%        -6.3%  -6.0%        yes             yes
   HEAVY   WorkCap-8    47.09     46.74     0.35     0.30     0.39         yes           -25.4%     -24.4%       -28.8% -23.1%        yes             yes
