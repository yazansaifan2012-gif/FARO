# Paired statistics: FARO-IoT vs comparators

Stratified block bootstrap (B=2000, strata = seeds, blocks = contiguous trace segments). Latency non-inferiority margin = 10% on mean and p95 (upper 95% bound of ratio-1 must be below the margin).

workload         comparator SOCR_ref SOCR_comp dSOCR_pp dSOCR_lo dSOCR_hi SOCR_better meanlat_ratio_m1 meanlat_hi p95_ratio_m1 p95_hi latency_NI safe_latency_NI
   LIGHT FARO-IoT-NoPenalty    87.00     87.00    -0.01    -0.01    -0.00  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
   LIGHT    FARO-IoT-NoToll    87.00     87.01    -0.01    -0.01    -0.01  no (worse)            +0.1%      +0.1%        +0.0%  +0.0%        yes             yes
   LIGHT       FixedDepth-3    87.00     62.27    24.73    24.65    24.81         yes           -43.1%     -42.9%       -24.8% -24.4%        yes             yes
   LIGHT         QueueCap-4    87.00     83.24     3.76     3.72     3.80         yes            +6.1%      +6.1%        +4.0%  +4.2%        yes             yes
   LIGHT        RTD-adapted    87.00     83.27     3.73     3.70     3.76         yes            +6.1%      +6.1%        +4.0%  +4.2%        yes             yes
   LIGHT        SafeProb-05    87.00     84.53     2.47     2.44     2.49         yes            +4.8%      +4.8%        +3.2%  +3.3%        yes             yes
   LIGHT          SafeSlack    87.00     87.01    -0.01    -0.02    -0.01  no (worse)            +0.1%      +0.1%        +0.0%  +0.1%        yes             yes
   LIGHT        SizeGate-02    87.00     83.27     3.73     3.70     3.76         yes            +6.1%      +6.1%        +4.0%  +4.2%        yes             yes
   LIGHT   TS-Bandit-masked    87.00     81.12     5.88     5.81     5.97         yes           -10.0%      -9.6%       -11.6% -11.2%        yes             yes
   LIGHT          WorkCap-8    87.00     83.27     3.73     3.70     3.76         yes            +6.1%      +6.1%        +4.0%  +4.2%        yes             yes
  MEDIUM FARO-IoT-NoPenalty    89.46     89.48    -0.02    -0.02    -0.01  no (worse)            +0.0%      +0.0%        +0.0%  +0.0%        yes             yes
  MEDIUM    FARO-IoT-NoToll    89.46     89.48    -0.02    -0.05    -0.01  no (worse)            +0.2%      +0.2%        +0.0%  +0.0%        yes             yes
  MEDIUM       FixedDepth-3    89.46     66.92    22.54    22.45    22.62         yes           -42.0%     -41.9%       -24.4% -24.1%        yes             yes
  MEDIUM         QueueCap-4    89.46     85.86     3.60     3.27     4.01         yes            +4.8%      +4.9%        +3.3%  +3.4%        yes             yes
  MEDIUM        RTD-adapted    89.46     86.34     3.12     3.09     3.16         yes            +4.8%      +4.8%        +3.2%  +3.3%        yes             yes
  MEDIUM        SafeProb-05    89.46     87.60     1.86     1.83     1.89         yes            +3.6%      +3.7%        +2.5%  +2.6%        yes             yes
  MEDIUM          SafeSlack    89.46     89.52    -0.06    -0.08    -0.04  no (worse)            +0.3%      +0.3%        +0.1%  +0.1%        yes             yes
  MEDIUM        SizeGate-02    89.46     86.33     3.13     3.09     3.16         yes            +4.8%      +4.8%        +3.2%  +3.3%        yes             yes
  MEDIUM   TS-Bandit-masked    89.46     83.52     5.94     5.81     6.08         yes           -17.0%     -15.9%       -16.0% -15.1%        yes             yes
  MEDIUM          WorkCap-8    89.46     86.18     3.28     3.18     3.39         yes            +4.8%      +4.8%        +3.2%  +3.3%        yes             yes
   HEAVY FARO-IoT-NoPenalty    70.25     70.25    -0.00    -0.00    -0.00  no (worse)            +0.0%      +0.0%        -0.0%  +0.0%        yes             yes
   HEAVY    FARO-IoT-NoToll    70.25     57.51    12.73    11.74    13.72         yes           -77.4%     -75.7%       -68.3% -66.9%        yes             yes
   HEAVY       FixedDepth-3    70.25     54.66    15.59    14.38    16.75         yes           -78.6%     -77.1%       -69.8% -68.6%        yes             yes
   HEAVY         QueueCap-4    70.25     47.47    22.78    21.31    24.21         yes            +9.3%     +15.3%       -14.6%  -4.0%         no              no
   HEAVY        RTD-adapted    70.25     55.78    14.47    13.34    15.54         yes           -78.3%     -76.6%       -69.6% -68.4%        yes             yes
   HEAVY        SafeProb-05    70.25     55.03    15.22    14.07    16.40         yes           -78.4%     -76.8%       -69.8% -68.5%        yes             yes
   HEAVY          SafeSlack    70.25     48.42    21.82    20.25    23.35         yes           -79.2%     -77.6%       -70.8% -69.7%        yes             yes
   HEAVY        SizeGate-02    70.25     70.46    -0.22    -0.28    -0.16  no (worse)           -18.8%     -17.9%       -23.5% -22.8%        yes             yes
   HEAVY   TS-Bandit-masked    70.25     57.63    12.61    11.64    13.51         yes           -79.7%     -78.6%       -69.7% -68.4%        yes             yes
   HEAVY          WorkCap-8    70.25     57.82    12.43    11.52    13.31         yes           -35.9%     -32.5%       -64.0% -62.4%        yes             yes
