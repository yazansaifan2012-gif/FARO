# FARO-IoT — Final Experiment Report

Generated: 2026-09-28 08:06:51 UTC

## 1. Dataset Audit

- Source: `<project>/data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv` (SHA-256 `1d3ef6c7cc22784a...`)
- Raw rows: 2,219,201 | Valid-timestamp rows: 2,096,419 | Invalid: 122,782
- Final task count used: 2,096,419
- Trace duration: 86398.195 s | Mean arrival rate: 24.2646 tasks/s
- Payload (tcp.len) bytes: mean=125.72, median=0.00, std=373.22, missing=0

## 2. Experimental Configuration (FROZEN)

- Algorithms: ['FARO-IoT', 'FARO-IoT+Cal', 'FARO-IoT-FixedPenalty', 'FARO-IoT-NoPenalty', 'FARO-IoT-D', 'FARO-v2', 'FARO-NoRisk', 'RTD-adapted', 'FixedDepth-1', 'FixedDepth-2', 'FixedDepth-3', 'FixedDepth-4', 'FixedDepth-6', 'TS-Bandit-adapted', 'TS-Bandit-masked', 'Fang et al.-adapted', 'SharpEdge-adapted']
- Workloads: ['LIGHT', 'MEDIUM', 'HEAVY'] (compute_demand_cycles = {'LIGHT': 1000000, 'MEDIUM': 100000000, 'HEAVY': 10000000000})
- Seeds: [1, 2, 3]
- q=0.15, lambda_b=2.0, C_rev=2.0, rho_D=2.0, Z range=[1,20]
- v3: beta_miss=2.0, risk classes=[('RELAXED', 0.5, 0.3, 0.5), ('STANDARD', 0.3, 0.2, 1.0), ('STRICT', 0.2, 0.1, 2.0)], calibration window=512, quantile levels=[0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]

## 3. Parameter Provenance

See `results/provenance_table_final.csv`.

## 4. Validation Tests

40/40 tests passed.

## 5. Fairness Audit

7/7 fairness checks passed.

## 6-9. FARO / Baseline / Ablation / Sensitivity Results

Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.

### Headline (v3 study-proposed metrics, mean over seeds)

| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | mean lat. s | viol. % | adm. % | mean z | mean P_rev |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| HEAVY | SizeGate-0.2 | 70.46 | 14.09 | 35.22 | 70.46 | 0.566 | 70.46 | 4.479 | 0.03 | 70.48 | 1.70 | 0.197 |
| HEAVY | FARO-IoT-NoPenalty | 70.25 | 14.43 | 35.80 | 70.25 | 0.565 | 70.25 | 3.636 | 0.01 | 70.26 | 1.72 | 0.195 |
| HEAVY | FARO-IoT | 70.25 | 14.43 | 35.80 | 70.25 | 0.565 | 70.25 | 3.637 | 0.01 | 70.25 | 1.72 | 0.195 |
| HEAVY | WorkCap-8 | 57.82 | 11.36 | 28.62 | 57.82 | 0.464 | 57.82 | 5.677 | 0.63 | 58.19 | 1.69 | 0.198 |
| HEAVY | TS-Bandit-masked | 57.63 | 18.85 | 31.57 | 57.63 | 0.478 | 57.63 | 17.885 | 5.80 | 61.18 | 3.37 | 0.169 |
| HEAVY | FARO-IoT-NoToll | 57.51 | 8.01 | 23.88 | 57.51 | 0.451 | 57.51 | 16.118 | 1.26 | 58.25 | 1.56 | 0.216 |
| HEAVY | RTD-adapted | 55.78 | 8.24 | 23.85 | 55.78 | 0.439 | 55.78 | 16.739 | 4.57 | 58.45 | 1.59 | 0.212 |
| HEAVY | SafeProb-0.5 | 55.03 | 8.11 | 23.50 | 55.03 | 0.433 | 55.03 | 16.863 | 5.88 | 58.46 | 1.59 | 0.212 |
| HEAVY | FixedDepth-3 | 54.66 | 54.66 | 54.66 | 54.66 | 0.518 | 54.66 | 16.969 | 7.02 | 58.79 | 3.00 | 0.053 |
| HEAVY | SafeSlack | 48.42 | 7.82 | 21.77 | 48.42 | 0.383 | 48.42 | 17.486 | 17.65 | 58.80 | 1.70 | 0.197 |
| HEAVY | QueueCap-4 | 47.47 | 9.48 | 23.71 | 47.47 | 0.381 | 47.47 | 3.329 | 0.17 | 47.55 | 1.70 | 0.197 |
| LIGHT | SafeSlack | 87.01 | 14.32 | 39.64 | 87.01 | 0.690 | 87.01 | 0.852 | 12.99 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT-NoToll | 87.01 | 14.31 | 39.64 | 87.01 | 0.690 | 87.01 | 0.853 | 12.99 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT-NoPenalty | 87.00 | 14.31 | 39.64 | 87.00 | 0.690 | 87.00 | 0.853 | 13.00 | 100.00 | 1.70 | 0.197 |
| LIGHT | FARO-IoT | 87.00 | 14.31 | 39.63 | 87.00 | 0.690 | 87.00 | 0.853 | 13.00 | 100.00 | 1.70 | 0.197 |
| LIGHT | SafeProb-0.5 | 84.53 | 12.96 | 37.17 | 84.53 | 0.667 | 84.53 | 0.814 | 8.45 | 92.34 | 1.62 | 0.207 |
| LIGHT | RTD-adapted | 83.27 | 12.46 | 35.90 | 83.27 | 0.656 | 83.27 | 0.805 | 7.51 | 90.04 | 1.60 | 0.210 |
| LIGHT | SizeGate-0.2 | 83.27 | 12.46 | 35.90 | 83.27 | 0.656 | 83.27 | 0.805 | 7.51 | 90.04 | 1.60 | 0.210 |
| LIGHT | WorkCap-8 | 83.27 | 12.46 | 35.90 | 83.27 | 0.656 | 83.27 | 0.805 | 7.51 | 90.04 | 1.60 | 0.210 |
| LIGHT | QueueCap-4 | 83.24 | 12.45 | 35.89 | 83.24 | 0.655 | 83.24 | 0.805 | 7.51 | 90.00 | 1.60 | 0.210 |
| LIGHT | TS-Bandit-masked | 81.12 | 24.16 | 34.16 | 81.12 | 0.647 | 81.12 | 0.948 | 9.92 | 90.05 | 1.86 | 0.196 |
| LIGHT | FixedDepth-3 | 62.27 | 62.27 | 62.27 | 62.27 | 0.590 | 62.27 | 1.499 | 12.94 | 71.52 | 3.00 | 0.053 |
| MEDIUM | SafeSlack | 89.52 | 15.15 | 41.42 | 89.52 | 0.711 | 89.52 | 0.885 | 10.48 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT-NoToll | 89.48 | 15.13 | 41.39 | 89.48 | 0.711 | 89.48 | 0.886 | 10.51 | 100.00 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT-NoPenalty | 89.48 | 15.13 | 41.39 | 89.48 | 0.711 | 89.48 | 0.887 | 10.49 | 99.96 | 1.70 | 0.197 |
| MEDIUM | FARO-IoT | 89.46 | 15.12 | 41.37 | 89.46 | 0.710 | 89.46 | 0.887 | 10.49 | 99.94 | 1.70 | 0.197 |
| MEDIUM | SafeProb-0.5 | 87.60 | 13.89 | 39.50 | 87.60 | 0.693 | 87.60 | 0.856 | 7.46 | 94.66 | 1.64 | 0.204 |
| MEDIUM | RTD-adapted | 86.34 | 13.39 | 38.23 | 86.34 | 0.682 | 86.34 | 0.847 | 6.53 | 92.36 | 1.62 | 0.207 |
| MEDIUM | SizeGate-0.2 | 86.33 | 13.39 | 38.23 | 86.33 | 0.682 | 86.33 | 0.847 | 6.53 | 92.36 | 1.62 | 0.207 |
| MEDIUM | WorkCap-8 | 86.18 | 13.36 | 38.16 | 86.18 | 0.681 | 86.18 | 0.847 | 6.53 | 92.20 | 1.62 | 0.207 |
| MEDIUM | QueueCap-4 | 85.86 | 13.31 | 38.02 | 85.86 | 0.678 | 85.86 | 0.846 | 6.52 | 91.85 | 1.62 | 0.207 |
| MEDIUM | TS-Bandit-masked | 83.52 | 25.78 | 36.06 | 83.52 | 0.669 | 83.52 | 1.069 | 9.55 | 92.34 | 1.89 | 0.192 |
| MEDIUM | FixedDepth-3 | 66.92 | 66.92 | 66.92 | 66.92 | 0.634 | 66.92 | 1.531 | 12.18 | 76.20 | 3.00 | 0.053 |

## 10. Statistical Analysis

CIs computed across the seed-level metric values, NOT across individual tasks.

## 11. Runtime

Total pipeline runtime: 1796.0 s (29.93 min).
