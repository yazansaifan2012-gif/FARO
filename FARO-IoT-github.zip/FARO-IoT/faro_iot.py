"""
FARO-IoT v3 — Finality-Risk-Aware Orchestration for blockchain-integrated
Edge–Fog–Cloud IoT (trace-driven DES over Edge-IIoTset).

WHAT IS NEW IN v3 (relative to the frozen v2 single-file pipeline, which is
kept verbatim inside this file as the FARO-v2 / FARO-NoRisk / FARO-FixedZ /
Fang / SharpEdge code paths):

  1. Task profile  T_i = (a_i, L_i, C_i, D_i, chi_i, tau_i)
     - tau_i : per-task REQUIRED finality-risk level (max acceptable P_rev)
     - chi_i : per-task reversal consequence weight
     Both come from a seeded risk-class mixture (RISK_CLASSES) keyed only by
     (seed, task order) => identical for every algorithm under a seed (CRN).
     D_i = rho_D * T_base_i where T_base_i includes E[T_fin(z_req(tau_i))]:
     a task that requires deeper finality carries a proportionally longer
     service-level deadline. D_i is algorithm-independent.

  2. FARO-IoT (proposed) decision layer = "calibrated expected-safe-utility
     act-or-wait":
       P_on(r,z)  = P[T_comm+T_queue+T_compute+T_fin(z) <= D_i]
                    with T_fin(z) ~ Erlang(z, lambda_b) (exact CDF table) and
                    the queue-wait prediction error modelled by an ONLINE,
                    per-tier empirical residual distribution (rolling window
                    of realized-minus-predicted queue waits, summarised by
                    CAL_QUANTILE_LEVELS quantile points) — a distribution-free
                    calibration in the spirit of conformal prediction.
       U(r,z)     = P_on * (1 - gamma*E[T_total]/D_i - C_rev*chi_i*P_rev(z,q)) - beta * (1 - P_on)
       feasible   : P_rev(z,q) <= tau_i  (hard, per-task risk requirement)
       decision   : argmax U over feasible (r,z); ADMIT iff max U > 0.
     beta = BETA_MISS is the deadline-miss penalty (in units of task value).

  3. New study-proposed metrics (streaming, per task, same formula for every
     algorithm): SOCR(tau) at tau in SOCR_TAUS and as a full curve,
     SOCR-req (uses each task's own tau_i), ESU, risk-level satisfaction,
     predicted-vs-realized on-time calibration gap, per-class breakdowns.

  4. Ablations that isolate each v3 ingredient: FARO-NoCal (no residual
     calibration), FARO-Expected (expected-value feasibility + J objective,
     with tau_i), FARO-NoTau (v3 utility without the tau_i constraint).

Everything below the "v3" markers is additive; legacy functions are unchanged.
"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import multiprocessing as mp
import os
import re
import signal
import sys
import tempfile
import time
import traceback
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed, CancelledError
from typing import Any, Callable, Dict, List, Optional

import numpy as np
import pandas as pd
import simpy
from scipy.special import betainc

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# =============================================================================
# SECTION 1: CONFIGURATION — single source of truth + provenance registry
# =============================================================================
PROVENANCE_REGISTRY: List[Dict[str, Any]] = []


def register(parameter: str, value: Any, unit: str, provenance: str,
             source: str, notes: str = "") -> Any:
    assert provenance in ("D", "L", "C", "S"), f"bad provenance tag {provenance!r}"
    PROVENANCE_REGISTRY.append(dict(parameter=parameter, value=value, unit=unit,
                                     provenance=provenance, source=source, notes=notes))
    return value


# --- A. Dataset column mapping ----------------------------------------------
TIMESTAMP_COL = register("dataset.timestamp_col", "frame.time", "column name", "D",
                          "Edge-IIoTset (Ferrag et al., IEEE Access 2022), DNN-EdgeIIoT-dataset.csv",
                          "Real Wireshark capture timestamp; arrival_time = timestamp - min(timestamp).")
PAYLOAD_COL = register("dataset.payload_col", "tcp.len", "column name", "D",
                        "Edge-IIoTset, DNN-EdgeIIoT-dataset.csv",
                        "network_payload_bytes; NEVER treated as compute_demand_cycles.")
LABEL_COL = register("dataset.label_col", "Attack_label", "column name", "D",
                      "Edge-IIoTset, DNN-EdgeIIoT-dataset.csv",
                      "Audit/provenance ONLY. Must not influence workload/deadline/C_rev/placement/z.")
ATTACK_TYPE_COL = register("dataset.attack_type_col", "Attack_type", "column name", "D",
                            "Edge-IIoTset, DNN-EdgeIIoT-dataset.csv",
                            "Audit/provenance ONLY. Must not influence workload/deadline/C_rev/placement/z.")
FALLBACK_PAYLOAD_BYTES = register("dataset.fallback_payload_bytes", 512.0, "bytes", "S",
                                   "this project", "Used only if payload column is missing for a row.")
REQUIRED_COLS = [TIMESTAMP_COL, PAYLOAD_COL, LABEL_COL, ATTACK_TYPE_COL]

# --- B. Computational-intensity workload scenarios --------------------------
WORKLOADS: Dict[str, int] = {
    "LIGHT":  register("workload.LIGHT.compute_demand_cycles", int(1e6), "cycles/task", "S",
                        "FINAL FREEZE PASS request (Section 1)",
                        "Fixed regardless of tier; NOT derived from tcp.len."),
    "MEDIUM": register("workload.MEDIUM.compute_demand_cycles", int(1e8), "cycles/task", "S",
                        "FINAL FREEZE PASS request (Section 1)",
                        "Fixed regardless of tier; NOT derived from tcp.len."),
    "HEAVY":  register("workload.HEAVY.compute_demand_cycles", int(1e10), "cycles/task", "S",
                        "FINAL FREEZE PASS request (Section 1)",
                        "Fixed regardless of tier; NOT derived from tcp.len."),
}
WORKLOAD_NAMES = list(WORKLOADS.keys())
WORKLOAD_CODE = {name: i for i, name in enumerate(WORKLOAD_NAMES)}

# --- C. Edge / Fog / Cloud resource tiers — FROZEN, per freeze-pass Section 1
RESOURCE_TIERS: Dict[str, Dict[str, float]] = {
    "Edge": dict(
        bandwidth_Bps=register("resource.Edge.bandwidth_Bps", 5_000_000.0, "bytes/s", "S",
                                "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
        prop_delay_s=register("resource.Edge.prop_delay_s", 0.002, "s", "S",
                               "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
        compute_capacity_cycles_per_s=register("resource.Edge.compute_capacity_cycles_per_s", 1.0e9,
                                                 "cycles/s", "S", "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
        num_servers=register("resource.Edge.num_servers", 2, "servers", "S",
                              "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
    ),
    "Fog": dict(
        bandwidth_Bps=register("resource.Fog.bandwidth_Bps", 20_000_000.0, "bytes/s", "S",
                                "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
        prop_delay_s=register("resource.Fog.prop_delay_s", 0.010, "s", "S",
                               "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
        compute_capacity_cycles_per_s=register("resource.Fog.compute_capacity_cycles_per_s", 4.0e9,
                                                 "cycles/s", "S", "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
        num_servers=register("resource.Fog.num_servers", 4, "servers", "S",
                              "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
    ),
    "Cloud": dict(
        bandwidth_Bps=register("resource.Cloud.bandwidth_Bps", 100_000_000.0, "bytes/s", "S",
                                "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
        prop_delay_s=register("resource.Cloud.prop_delay_s", 0.040, "s", "S",
                               "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
        compute_capacity_cycles_per_s=register("resource.Cloud.compute_capacity_cycles_per_s", 1.6e10,
                                                 "cycles/s", "S", "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
        num_servers=register("resource.Cloud.num_servers", 16, "servers", "S",
                              "FINAL FREEZE PASS request (Section 1)", "FROZEN."),
    ),
}
TIER_NAMES = ["Edge", "Fog", "Cloud"]
TIER_CODE = {name: i for i, name in enumerate(TIER_NAMES)}
REFERENCE_TIER_FOR_DEADLINE = "Edge"

# --- D. Blockchain finality model — FROZEN equation and parameters ----------
Z_MIN = register("blockchain.z_min", 1, "confirmations", "S", "FINAL FREEZE PASS request (Section 1)", "FROZEN.")
Z_MAX = register("blockchain.z_max", 20, "confirmations", "S", "FINAL FREEZE PASS request (Section 1)", "FROZEN.")
DEFAULT_Q = register("blockchain.q", 0.15, "fraction", "S", "FINAL FREEZE PASS request (Section 1)",
                      "Adversarial hashpower fraction, 0<q<0.5. FROZEN.")
DEFAULT_LAMBDA_B = register(
    "blockchain.lambda_b", 2.0, "blocks/s", "S", "FINAL FREEZE PASS request (Section 1)",
    "FROZEN. Restored to 2.0 (superseding the intermediate 'corrected' "
    "project's 30.0, which had been cross-checked only against an earlier, "
    "superseded prior-notebook source). Paired with the blockchain-aware "
    "T_base (Section E below) and rho_D=2.0, this does NOT reproduce the "
    "prior all-infeasible degenerate scenario, because T_base itself now "
    "scales with 1/lambda_b via the z_min/lambda_b finality term.")
DEFAULT_C_REV = register("reversal.c_rev", 2.0, "dimensionless (Loss_reversal/Loss_reference)", "S",
                          "FINAL FREEZE PASS request (Section 1)",
                          "FROZEN. NOT clipped to [0,1]; NOT derived from Attack_type/Attack_label/protocol.")

# --- E. Deadline model — FROZEN, blockchain-aware T_base --------------------
RHO_D = register(
    "deadline.rho_D", 2.0, "dimensionless multiplier", "S",
    "RECOVERED from FINAL FREEZE PASS request Section 2's own data point "
    "(LIGHT mean D_task ~= 1.004 s at lambda_b=2, z_min=1) applied to this "
    "project's real 500-row Edge-IIoTset sample (mean tcp.len=132.13 B): "
    "T_base(LIGHT) ~= 0.503 s => rho_D = 1.004/0.503 ~= 1.996 ~= 2.0. "
    "NOT calibrated against this file's own downstream results — fixed by "
    "this arithmetic alone, before any regression run below.",
    "See FARO_IoT_COMPLETE_FINAL.py module docstring 'FINAL FREEZE PASS' section for "
    "the full derivation. D_task = rho_D * T_base is computed ONCE per task "
    "and is IDENTICAL across Edge/Fog/Cloud (never recomputed per tier)."
)

# --- F. Ablation / baseline fixed-z settings --------------------------------
FARO_FIXEDZ_VALUE = register("ablation.FARO_FixedZ.z", 6, "confirmations", "S",
                              "this project (established in prior FARO-IoT notebook work)",
                              "Chosen before looking at final results; not results-dependent.")
FANG_FIXED_Z = register(
    "baseline.Fang.z", 6, "confirmations", "S",
    "this project (adaptation parameter) — NOT from Fang et al. 2024",
    "The QUALITATIVE behavior ('a fixed, conservative, network-predetermined "
    "confirmation depth, not adaptively searched') is supported by the "
    "user-supplied paraphrase of the paper. The NUMERIC value 6 is an "
    "explicitly [S] adaptation parameter, NOT attributed to the paper.")
SHARPEDGE_FIXED_Z = register(
    "baseline.SharpEdge.z", 1, "confirmations", "S",
    "this project (adaptation parameter) — NOT from Gu et al. 2024",
    "The QUALITATIVE behavior ('the minimum possible confirmation depth') is "
    "supported by the user-supplied paraphrase; still marked [S] since the "
    "paper's own reputation/peer-selection formulas were never obtained.")

ENERGY_TX_WATT = {"Edge": 0.5, "Fog": 0.8, "Cloud": 1.2}
ENERGY_COMPUTE_WATT_PER_GHZ = {"Edge": 0.4, "Fog": 1.0, "Cloud": 2.5}
for _t in TIER_NAMES:
    register(f"baseline.Fang.energy_tx_watt.{_t}", ENERGY_TX_WATT[_t], "W", "S",
              "this project (Fang et al. exact power model not independently verified)", "")
    register(f"baseline.Fang.energy_compute_watt_per_ghz.{_t}", ENERGY_COMPUTE_WATT_PER_GHZ[_t], "W/GHz", "S",
              "this project (Fang et al. exact power model not independently verified)", "")

REPUTATION_EWMA_ALPHA = register("baseline.SharpEdge.reputation_ewma_alpha", 0.2, "dimensionless", "S",
                                  "this project — NOT from Gu et al. 2024",
                                  "Simulation-controlled approximation of historical-performance "
                                  "reputation; not claimed to be the original SharpEdge reputation equation.")
REPUTATION_INITIAL = register("baseline.SharpEdge.reputation_initial", 0.5, "dimensionless [0,1]", "S",
                               "this project", "Neutral prior.")

# --- G. Sensitivity grids — literal, recovered verbatim, never re-derived ---
CREV_SWEEP_VALUES = register("sensitivity.C_rev.grid", [0.1, 0.5, 1.0, 2.0, 5.0, 10.0], "dimensionless", "S",
                              "prior FARO-IoT notebook, Section 19", "Unchanged from the frozen project.")
Q_SWEEP_VALUES = register("sensitivity.q.grid", [0.05, 0.15, 0.25, 0.35, 0.45], "fraction", "S",
                           "prior FARO-IoT notebook, Section 19", "Unchanged from the frozen project.")
RHOD_SWEEP_VALUES = register("sensitivity.rho_D.grid", [1.2, 2.0, 4.0, 8.0, 16.0], "dimensionless multiplier", "S",
                              "prior FARO-IoT notebook, Section 19",
                              "Literal frozen grid, recovered verbatim; NOT rescaled relative to RHO_D=2.0.")
LAMBDA_SWEEP_VALUES = register("sensitivity.lambda_b.grid", [0.5, 1.0, 2.0, 5.0, 10.0], "blocks/s", "S",
                                "prior FARO-IoT notebook, Section 19",
                                "Literal frozen grid, recovered verbatim; NOT rescaled relative to DEFAULT_LAMBDA_B.")

# --- H0. v3 additions: risk classes, utility parameters, calibration, metrics
# Per-task required finality-risk level tau_i and reversal-consequence weight
# chi_i come from a seeded class mixture. Shares/values are [S] study
# parameters fixed BEFORE any v3 result was produced. tau values coincide
# with the SOCR reporting thresholds recommended in the metric definition
# sheet (0.10 / 0.20 / 0.30). At q=0.15 the minimum depths are z_req=3/2/1.
RISK_CLASSES: List[Dict[str, Any]] = [
    dict(name="RELAXED",  share=0.50, tau=0.30, chi=0.5),
    dict(name="STANDARD", share=0.30, tau=0.20, chi=1.0),
    dict(name="STRICT",   share=0.20, tau=0.10, chi=2.0),
]
for _rc in RISK_CLASSES:
    register(f"task.risk_class.{_rc['name']}.share", _rc["share"], "fraction", "S", "this project (v3)",
             "Seeded mixture; class drawn per task from (seed, task order) only — never from labels.")
    register(f"task.risk_class.{_rc['name']}.tau", _rc["tau"], "max P_rev", "S", "this project (v3)",
             "Required finality-risk level; hard constraint for FARO-IoT; reporting threshold for all.")
    register(f"task.risk_class.{_rc['name']}.chi", _rc["chi"], "dimensionless", "S", "this project (v3)",
             "Reversal-consequence weight; enters FARO-IoT utility as C_rev*chi_i*P_rev.")
RISK_CLASS_NAMES = [rc["name"] for rc in RISK_CLASSES]
RISK_CLASS_CODE = {name: i for i, name in enumerate(RISK_CLASS_NAMES)}
assert abs(sum(rc["share"] for rc in RISK_CLASSES) - 1.0) < 1e-12

BETA_MISS = register("faro3.beta_miss", 2.0, "task-value units", "S", "this project (v3.2)",
                     "Deadline-miss penalty in the expected-safe-utility objective (a missed deadline wastes a "
                     "service slot AND delays the tasks queued behind it). SELECTED ON THE REPORTED beta SWEEP "
                     "(grid 0..4, MEDIUM and HEAVY, 5 seeds): SOCR-req is flat on MEDIUM up to beta=2 and rises "
                     "monotonically on HEAVY (admission is capacity-capped there, so a stricter rule only removes "
                     "late admits); beta=4 starts to cost MEDIUM. v3.0 used 0.5, v3.1 used 1.0.")
GAMMA_LAT = register("faro3.gamma_latency", 0.5, "dimensionless", "S", "this project (v3)",
                     "Linear time-discount of the value of an on-time completion: value = 1 - gamma*E[T]/D_i. "
                     "gamma=0.5 => a task delivered exactly at its deadline is worth half of an instant one. "
                     "Fixed a priori; prevents needless confirmation-depth inflation when deadline slack is large.")
BETA_SWEEP_VALUES = register("sensitivity.beta_miss.grid", [0.0, 0.25, 0.5, 1.0, 2.0, 4.0],
                             "task-value units", "S", "this project (v3)", "New v3 sensitivity axis.")

CAL_WINDOW = register("faro3.calibration.window", 512, "tasks", "S", "this project (v3)",
                      "Rolling window of realized-minus-predicted queue-wait residuals per tier.")
CAL_QUANTILE_LEVELS = register("faro3.calibration.quantile_levels",
                               [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9], "probability", "S",
                               "this project (v3)",
                               "Equal-weight quantile points summarising the residual distribution; "
                               "P_on is the average Erlang CDF over these points (9-point quadrature).")
CAL_REFRESH_EVERY = register("faro3.calibration.refresh_every", 32, "updates", "S", "this project (v3)",
                             "Quantile points are recomputed every this many residual updates.")
CAL_MIN_SAMPLES = register("faro3.calibration.min_samples", 16, "updates", "S", "this project (v3)",
                           "Below this many residuals a tier uses the uncalibrated (zero-residual) model.")

COMPUTE_JITTER_SIGMA = register(
    "environment.compute_jitter_sigma", 0.25, "log-scale sd", "S", "this project (v3)",
    "Realized compute time = predicted * exp(sigma*Z - sigma^2/2), Z~N(0,1) keyed by (seed, task_id) "
    "(CRN stream 2). Mean-one multiplicative execution-time uncertainty (CPU contention); the "
    "decision-time estimate uses the mean. Applied identically to every algorithm. 0 disables.")

SOCR_TAUS = register("metric.SOCR.tau_grid", [0.10, 0.20, 0.30], "max P_rev", "S",
                     "metric definition sheet (SOCR)", "Report SOCR at these thresholds + full curve.")
ERLANG_TABLE_XMAX = 120.0   # table covers lambda_b * t in [0, 120]; P(z<=20 | x=120) == 1.0
ERLANG_TABLE_DX = 0.002

# --- H1. v4 environment / experiment switches (all CLI-overridable, all registered) ----------
CHAIN_MODE = register("v4.chain_mode", "shared", "enum", "S", "this project (v4)",
                      "shared: one seeded Poisson block sequence per seed; a transaction submitted at time t "
                      "is included in the first block after t and final after z blocks counted from that block "
                      "(z includes the inclusion block). independent: legacy per-task i.i.d. exponential draws.")
BLOCK_CAPACITY = register("v4.block_capacity", 0, "tx per block", "S", "this project (v4)",
                          "0 = unlimited. >0: a transaction that finds its block full is included in the next one.")
DEADLINE_MODE = register("v4.deadline_mode", "risk", "enum", "S", "this project (v4)",
                         "risk: D_i = rho_D*(T_comm^Edge + T_comp^Edge + z_req(tau_i)/lambda_b) (v3). "
                         "independent: D_i = rho_D*(T_comm^Edge + T_comp^Edge) + b_i, b_i ~ U[b_min, b_max] from a "
                         "seeded stream independent of the risk class.")
INDEP_BUDGET_RANGE = register("v4.independent_deadline.finality_budget_s", [0.5, 4.0], "s", "S", "this project (v4)",
                              "Uniform finality budget for the independent deadline mode; mean 2.25 s matches the "
                              "mean risk-derived budget rho_D*E[z_req]/lambda_b = 1.7 s to within a factor 1.3.")
TIE_MODE = register("v5.tie_mode", "spread", "enum", "S", "this project (v5)",
                    "Integer-second timestamps: 'spread' evenly inside the second (default), 'none' (keep ties), "
                    "'random' (seeded uniform offset inside the second).")
DEMAND_CV = register("v5.demand_cv", 0.0, "coefficient of variation", "S", "this project (v5)",
                     "Per-task computational demand c_i = c_w * exp(s Z - s^2/2), s = sqrt(ln(1+cv^2)), Z keyed by "
                     "(seed, task_id); 0 = homogeneous demand within a workload (v4 default).")
TS_MASKED_FULL_DEPTHS = register("v5.ts_masked_full_depths", True, "bool", "S", "this project (v5)",
                                 "TS-Bandit-masked uses every depth 1..z_max (so every risk class has feasible arms).")
PENALTY_MODE = register("v4.penalty_mode", "congestion", "enum", "S", "this project (v4)",
                        "Deadline-miss penalty. 'congestion' (default): beta * (P_on^0 - P_on), the miss "
                        "probability ATTRIBUTABLE TO QUEUEING (P_on^0 = on-time probability with the predicted "
                        "queue wait removed). Rejecting a task only helps others when its miss would come from "
                        "contention; finality-driven misses free no capacity anybody needs. Zero on an idle tier, "
                        "equal to the fixed rule when queueing causes the miss (the v3.3 HEAVY control). "
                        "'fixed': beta * (1 - P_on) (v3). 'load': beta * min(1, inflight/c) * (1 - P_on).")
LOAD_SCALE = register("v4.load_scale", 1.0, "x", "S", "this project (v4)",
                      "Arrival times are divided by this factor (2 = twice the arrival intensity, same tasks).")
RISK_PROFILE = register("v4.risk_profile", "standard", "enum", "S", "this project (v4)",
                        "standard: tau = 0.30/0.20/0.10; stringent: tau = 1e-2/1e-3/1e-4 (same class names, "
                        "shares and chi). Tasks whose tau needs z > Z_MAX are rejected and logged as risk_infeasible.")
STRINGENT_TAUS = {"RELAXED": 1e-2, "STANDARD": 1e-3, "STRICT": 1e-4}
Q_TRUE = register("v4.q_true", None, "fraction", "S", "this project (v4)",
                  "True adversarial share used ONLY for evaluation (compliance under risk-model mismatch). "
                  "None = equal to the decision q.")
LATENCY_NI_MARGIN = register("v4.latency_noninferiority_margin", 0.10, "relative", "S",
                             "pre-specified before the v4 campaign",
                             "Latency non-inferiority vs the risk-compliant comparator RTD-adapted: the upper 95% "
                             "bound of (FARO/RTD - 1) must lie below this margin, for mean and p95 separately.")
N_SEGMENTS = register("v4.n_segments", 48, "segments", "S", "this project (v4)",
                      "Contiguous equal-count trace segments for paired block-bootstrap confidence intervals.")
LAT_HIST_EDGES = np.logspace(-3, 3, 241)
FIXED_DEPTHS = register("baseline.FixedDepth.grid", [1, 2, 3, 4, 6], "confirmations", "S", "this project (v4)",
                        "Static-depth family: fastest expected-feasible tier at a constant depth.")
TONIOT_PAYLOAD_CAP = register("dataset.toniot.payload_cap_bytes", 65535, "bytes", "S", "this project (v4)",
                              "TON_IoT flow records: task payload = src_bytes clipped to one 64 KiB message.")
PER_TASK_SEEDS: Optional[set] = None     # None = write per-task logs for every run; set() = none
NO_PER_TASK = False
EXT_ETA = register("v6.ext_eta", 0.0, "dimensionless", "S", "this project (v6)",
                   "Weight of the Naor-type admission toll eta*rho_r*T_queue_hat/D_i in FARO-IoT's utility; "
                   "tuned on development seeds 101-102 only (stage T of the v6 campaign), then frozen.")
ADMIT_RULE = register("v6.admit_rule", "utility", "enum", "S", "this project (v6)",
                      "'utility': admit iff U* > 0 (v5). 'nolat': the latency term guides tier/depth selection "
                      "but is excluded from the admission test. 'nolatrisk': latency and risk-loss terms both "
                      "excluded from the admission test (P_on - penalty - toll > 0).")
TOLL_FORM = register("v6.toll_form", "work", "enum", "S", "this project (v6)",
                     "'own': eta*rho_r*T_q/D_i. 'work': eta*rho_r*(s_ir/S_r)*T_q*mean(1/D) -- the delay the "
                     "task's service s_ir adds for the ~n_r-m_r tasks that will queue behind it, each valued at "
                     "the running mean inverse deadline of arriving tasks.")
FORCE_DECISION = None  # v7 counterfactual hook (toll_validation.py); never set in the campaign runs
QUEUE_EST = register("v6.queue_est", "work", "enum", "S", "this project (v6)",
                     "'count': (n-m)/m*S + S/2 with the nominal mean service S. 'work': (W/m)(1-m/(2n)) with W the "
                     "committed nominal work (s); identical to 'count' when demand is homogeneous (DEMAND_CV = 0).")

# --- H. Experiment matrix ----------------------------------------------------
# Legacy names keep their legacy semantics (v2 objective family). New v3 names:
#   FARO-IoT      : proposed (calibrated expected-safe-utility, tau_i hard)
#   FARO-NoCal    : FARO-IoT without online residual calibration
#   FARO-Expected : tau_i hard + expected-value feasibility + legacy J objective
#   FARO-NoTau    : FARO-IoT utility/calibration without the tau_i constraint
#   FARO-v2       : the frozen v2 FARO-IoT objective (J = T/D + C_rev*P_rev)
#   RTD-adapted        : risk-thresholded depth z=z_req(tau_i) + fastest feasible tier (Hicks 2025 / Kovalchuk 2026)
#   TS-Bandit-adapted  : Thompson-sampling (tier, z) selection, TSAPO-style (Xu et al. 2024, IEEE TMC)
#   FARO-MinDepth      : probabilistic admission (beta) + z fixed at z_req(tau_i)  [= RTD + FARO admission]
# v4 (after the minimum-depth control showed the overload gain comes from admission):
#   FARO-IoT            : fastest tier, minimum safe depth z_req(tau_i), probabilistic admission with a
#                         congestion-attributable miss penalty beta*(P_on^0 - P_on)
#   FARO-IoT+Cal        : FARO-IoT with the empirical residual calibrator
#   FARO-IoT-FixedPenalty: FARO-IoT with a constant penalty beta (= the v3.3 FARO-MinDepth control)
#   FARO-IoT-NoPenalty  : FARO-IoT with beta = 0
#   FARO-IoT-D          : FARO-IoT with utility-optimised depth z >= z_req (depth extension)
#   FixedDepth-k        : fastest expected-feasible tier at constant depth k (static family)
#   TS-Bandit-masked    : Thompson sampling restricted to risk-compliant arms
ALGORITHMS = ["FARO-IoT", "FARO-IoT+Cal", "FARO-IoT-FixedPenalty", "FARO-IoT-NoPenalty", "FARO-IoT-D", "FARO-v2", "FARO-NoRisk",
              "RTD-adapted", "FixedDepth-1", "FixedDepth-2", "FixedDepth-3", "FixedDepth-4", "FixedDepth-6",
              "TS-Bandit-adapted", "TS-Bandit-masked", "Fang et al.-adapted", "SharpEdge-adapted"]
LEGACY_ALGORITHMS = ["FARO-NoCal", "FARO-NoTau", "FARO-MinDepth", "FARO-Expected", "FARO-FixedZ"]
ALGORITHM_CODE = {name: i for i, name in enumerate(ALGORITHMS)}
SEEDS = [1, 2, 3, 4, 5]

RESULTS_DIR = "results"
FIGURES_DIR = "figures"
MANIFEST_PATH = "experiment_manifest.json"
SENSITIVITY_MANIFEST_PATH = "sensitivity_manifest.json"  # separate checkpoint file for
                                                          # sensitivity points (Section 12c);
                                                          # never mixed with MANIFEST_PATH, which
                                                          # is reserved for the main 75-run matrix.


@dataclasses.dataclass
class RunConfig:
    algorithm: str
    workload: str
    seed: int

    @property
    def key(self) -> str:
        return f"{self.algorithm}__{self.workload}__seed{self.seed}"


def full_experiment_matrix() -> List[RunConfig]:
    return [RunConfig(a, w, s) for a in ALGORITHMS for w in WORKLOAD_NAMES for s in SEEDS]


def export_provenance_table(out_path: str = "results/provenance_table_final.csv") -> pd.DataFrame:
    df = pd.DataFrame(PROVENANCE_REGISTRY)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    df.to_csv(out_path, index=False)
    return df


# =============================================================================
# SECTION 2: DATASET — Edge-IIoTset loading, audit, genuine trace construction
# =============================================================================
def sha256_of_file(path: str, chunk_size: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


@dataclasses.dataclass
class DatasetAudit:
    path: str
    sha256: str
    file_size_bytes: int
    raw_rows: int
    valid_timestamp_rows: int
    invalid_timestamp_rows: int
    final_task_count: int
    trace_duration_s: float
    payload_mean: float
    payload_median: float
    payload_std: float
    payload_min: float
    payload_max: float
    payload_missing: int
    mean_arrival_rate_tasks_per_s: float
    duplicate_timestamps: int
    zero_inter_arrival: int

    def to_row(self) -> dict:
        return dict(self.__dict__)


_FRAME_TIME_RE = re.compile(r"^\s*(\d{4})\s+(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))?\s*$")
TIMESTAMP_MIN_VALID_FRACTION = register(
    "dataset.timestamp_min_valid_fraction", 0.90, "fraction", "S", "this project (v3.1)",
    "v3.1 data fix: Edge-IIoTset's frame.time carries 'YYYY HH:MM:SS.ns' (month/day absent) and ~5.5% of rows hold a "
    "shifted field (an IP address). Rows that do not match the strict pattern are DROPPED (previously dateutil "
    "'parsed' them into random dates, inflating the trace duration to 1.26e10 s). Arrival time = time-of-day in "
    "seconds; a multi-day capture therefore folds onto one 24 h axis. Hard stop below this valid fraction.")


def _parse_timestamp_column(raw: pd.Series) -> pd.Series:
    """Strict parser. (1) numeric epoch seconds/ms; (2) 'YYYY HH:MM:SS.frac' ->
    seconds since midnight; anything else -> NaN (row dropped by the audit)."""
    numeric = pd.to_numeric(raw, errors="coerce")
    frac_numeric = numeric.notna().mean() if len(raw) else 0.0
    if frac_numeric > 0.99:
        ts = numeric.astype(float)
        median_ts = ts.dropna().median() if ts.notna().any() else 0.0
        if median_ts > 1e12:
            ts = ts / 1000.0
        return ts
    ext = raw.astype(str).str.extract(_FRAME_TIME_RE)
    h = pd.to_numeric(ext[1], errors="coerce")
    m = pd.to_numeric(ext[2], errors="coerce")
    s = pd.to_numeric(ext[3], errors="coerce")
    frac = ext[4].fillna("0").str.slice(0, 9).str.ljust(9, "0")
    f = pd.to_numeric(frac, errors="coerce") / 1e9
    return (h * 3600.0 + m * 60.0 + s + f).astype(float)


def _dataset_files(path: str) -> List[str]:
    import glob as _glob
    if os.path.isdir(path):
        files = sorted(_glob.glob(os.path.join(path, "*.csv")))
    elif any(ch in path for ch in "*?["):
        files = sorted(_glob.glob(path))
    else:
        files = [path]
    return files


def detect_dataset_kind(path: str) -> str:
    files = _dataset_files(path)
    if not files or not os.path.exists(files[0]):
        raise FileNotFoundError(f"Dataset not found at {path!r}")
    cols = pd.read_csv(files[0], nrows=0).columns.tolist()
    if TIMESTAMP_COL in cols:
        return "edgeiiot"
    if "ts" in cols and "src_bytes" in cols:
        return "toniot"
    raise ValueError(f"Cannot detect dataset kind for {path!r}; columns: {cols[:30]}. "
                     f"Use --dataset-kind generic --ts-col <col> --payload-col <col>.")


def build_trace_generic(path: str, ts_col: str, payload_col: str, kind: str,
                        payload_cap: Optional[float] = None, chunksize: int = 1_000_000,
                        max_tasks: Optional[int] = None):
    """Chronological trace from epoch-timestamped records (TON_IoT network flows or any
    CSV with a numeric timestamp column). One record = one task. Records sharing an
    integer-second timestamp are spread deterministically and evenly inside that second
    (documented; no randomness). Day boundaries are preserved (no folding)."""
    files = _dataset_files(path)
    if not files:
        raise FileNotFoundError(f"No CSV files found for {path!r}")
    h = hashlib.sha256()
    size = 0
    frames = []
    raw_rows = 0
    for fp in files:
        h.update(sha256_of_file(fp).encode()); size += os.path.getsize(fp)
        cols = pd.read_csv(fp, nrows=0).columns.tolist()
        use = [c for c in [ts_col, payload_col, "label", "type"] if c in cols]
        if ts_col not in use or payload_col not in use:
            raise ValueError(f"{fp}: required columns {ts_col!r}/{payload_col!r} missing; columns: {cols[:30]}")
        for chunk in pd.read_csv(fp, usecols=use, chunksize=chunksize, low_memory=False):
            raw_rows += len(chunk)
            ts = pd.to_numeric(chunk[ts_col], errors="coerce")
            chunk = chunk.assign(_ts=ts)
            frames.append(chunk.loc[chunk["_ts"].notna()])
    df = pd.concat(frames, ignore_index=True)
    valid = len(df)
    if valid == 0 or valid / max(raw_rows, 1) < TIMESTAMP_MIN_VALID_FRACTION:
        raise ValueError(f"Timestamp parsing failed: {valid}/{raw_rows} valid rows.")
    if df["_ts"].median() > 1e12:
        df["_ts"] = df["_ts"] / 1000.0
    df = df.sort_values("_ts", kind="mergesort").reset_index(drop=True)
    if max_tasks:
        df = df.iloc[:int(max_tasks)].reset_index(drop=True)
    frac_integer = float((df["_ts"] == np.floor(df["_ts"])).mean())
    if frac_integer > 0.99 and TIE_MODE != "none":
        sec = df["_ts"].astype(np.int64)
        if TIE_MODE == "random":
            off = np.random.default_rng(np.random.SeedSequence([20260926, 7_004])).random(len(df))
            df["_ts"] = sec.to_numpy() + off
            df = df.sort_values("_ts", kind="mergesort").reset_index(drop=True)
        else:
            k = sec.groupby(sec).cumcount().to_numpy()
            n = sec.map(sec.value_counts()).to_numpy()
            df["_ts"] = sec.to_numpy() + k / n
    df["arrival_time"] = (df["_ts"] - df["_ts"].min()).astype(float)
    df["task_id"] = np.arange(len(df), dtype=np.int64)
    payload = pd.to_numeric(df[payload_col], errors="coerce")
    missing = int(payload.isna().sum())
    payload = payload.fillna(FALLBACK_PAYLOAD_BYTES)
    if payload_cap:
        payload = payload.clip(upper=payload_cap)
    df["network_payload_bytes"] = payload.astype(np.float32)
    df["native_label"] = df["label"] if "label" in df.columns else -1
    df["native_attack_type"] = (df["type"] if "type" in df.columns else "n/a")
    df["native_attack_type"] = df["native_attack_type"].astype("category")
    inter = df["arrival_time"].diff().dropna()
    dur = float(df["arrival_time"].max()) if len(df) else 0.0
    audit = DatasetAudit(
        path=f"{kind}:{path} ({len(files)} file(s); integer-second ties mode={TIE_MODE if frac_integer > 0.99 else 'n/a'})",
        sha256=h.hexdigest(), file_size_bytes=size, raw_rows=raw_rows, valid_timestamp_rows=valid,
        invalid_timestamp_rows=raw_rows - valid, final_task_count=len(df), trace_duration_s=dur,
        payload_mean=float(payload.mean()), payload_median=float(payload.median()),
        payload_std=float(payload.std()), payload_min=float(payload.min()), payload_max=float(payload.max()),
        payload_missing=missing, mean_arrival_rate_tasks_per_s=(len(df) / dur if dur > 0 else float("nan")),
        duplicate_timestamps=int((inter == 0).sum()), zero_inter_arrival=int((inter == 0).sum()))
    trace = df[["task_id", "arrival_time", "network_payload_bytes", "native_label",
                "native_attack_type"]].reset_index(drop=True)
    return trace, audit


def load_trace(path: str, kind: str = "auto", ts_col: Optional[str] = None,
               payload_col: Optional[str] = None, max_tasks: Optional[int] = None):
    kind = detect_dataset_kind(path) if kind == "auto" else kind
    if kind == "edgeiiot":
        trace, audit = audit_and_build_trace(path)
        if max_tasks:
            trace = trace.iloc[:int(max_tasks)].reset_index(drop=True)
        return trace, audit
    if kind == "toniot":
        return build_trace_generic(path, "ts", "src_bytes", "toniot", payload_cap=TONIOT_PAYLOAD_CAP,
                                   max_tasks=max_tasks)
    if kind == "generic":
        if not ts_col or not payload_col:
            raise ValueError("--dataset-kind generic needs --ts-col and --payload-col")
        return build_trace_generic(path, ts_col, payload_col, "generic", max_tasks=max_tasks)
    raise ValueError(f"unknown dataset kind {kind!r}")


def audit_and_build_trace(csv_path: str, chunksize: int = 500_000,
                           usecols: Optional[list] = None):
    if not os.path.exists(csv_path):
        raise FileNotFoundError(
            f"Dataset not found at {csv_path!r}. This project does not "
            f"auto-download an unofficial copy of Edge-IIoTset; point "
            f"--dataset at a real DNN-EdgeIIoT-dataset.csv.")
    usecols = usecols or REQUIRED_COLS
    file_size_bytes = os.path.getsize(csv_path)
    sha256 = sha256_of_file(csv_path)

    raw_rows = 0
    frames = []
    header_cols = pd.read_csv(csv_path, nrows=0).columns.tolist()
    missing = [c for c in usecols if c not in header_cols]
    if missing:
        raise ValueError(f"Required column(s) {missing} not found in {csv_path!r}. "
                          f"Available columns: {header_cols}")
    for chunk in pd.read_csv(csv_path, usecols=usecols, chunksize=chunksize, low_memory=False):
        raw_rows += len(chunk)
        ts = _parse_timestamp_column(chunk[TIMESTAMP_COL])
        chunk = chunk.assign(_ts=ts)
        chunk = chunk.loc[chunk["_ts"].notna()].copy()
        frames.append(chunk)

    valid_timestamp_rows = sum(len(f) for f in frames)
    invalid_timestamp_rows = raw_rows - valid_timestamp_rows
    success_rate = valid_timestamp_rows / max(raw_rows, 1)
    if valid_timestamp_rows == 0 or success_rate < TIMESTAMP_MIN_VALID_FRACTION:
        raise ValueError(f"Timestamp parsing failed for {TIMESTAMP_COL!r}: only "
                          f"{success_rate:.1%} of {raw_rows} rows parsed. Hard stop — "
                          f"no row-index fallback is used for arrival_time.")

    df = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=usecols + ["_ts"])
    df = df.sort_values("_ts", kind="mergesort").reset_index(drop=True)
    t_min = df["_ts"].min()
    df["arrival_time"] = (df["_ts"] - t_min).astype(float)
    df["task_id"] = np.arange(len(df), dtype=np.int64)

    payload = pd.to_numeric(df[PAYLOAD_COL], errors="coerce")
    payload_missing = int(payload.isna().sum())
    payload_filled = payload.fillna(FALLBACK_PAYLOAD_BYTES)
    df["network_payload_bytes"] = payload_filled.astype(np.float32)

    df["native_label"] = df[LABEL_COL]
    df["native_attack_type"] = df[ATTACK_TYPE_COL].astype("category")

    inter = df["arrival_time"].diff().dropna()
    duplicate_timestamps = int((inter == 0).sum())
    trace_duration_s = float(df["arrival_time"].max()) if len(df) else 0.0
    mean_rate = (len(df) / trace_duration_s) if trace_duration_s > 0 else float("nan")

    audit = DatasetAudit(
        path=csv_path, sha256=sha256, file_size_bytes=file_size_bytes,
        raw_rows=raw_rows, valid_timestamp_rows=valid_timestamp_rows,
        invalid_timestamp_rows=invalid_timestamp_rows, final_task_count=len(df),
        trace_duration_s=trace_duration_s,
        payload_mean=float(payload.mean()) if payload.notna().any() else float("nan"),
        payload_median=float(payload.median()) if payload.notna().any() else float("nan"),
        payload_std=float(payload.std()) if payload.notna().any() else float("nan"),
        payload_min=float(payload.min()) if payload.notna().any() else float("nan"),
        payload_max=float(payload.max()) if payload.notna().any() else float("nan"),
        payload_missing=payload_missing, mean_arrival_rate_tasks_per_s=mean_rate,
        duplicate_timestamps=duplicate_timestamps, zero_inter_arrival=duplicate_timestamps,
    )
    trace = df[["task_id", "arrival_time", "network_payload_bytes",
                "native_label", "native_attack_type"]].reset_index(drop=True)
    return trace, audit


def export_audit_csv(audit: DatasetAudit, out_path: str = "results/dataset_audit_final.csv") -> None:
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    pd.DataFrame([audit.to_row()]).to_csv(out_path, index=False)


# =============================================================================
# SECTION 3: BLOCKCHAIN FINALITY MODEL — FROZEN EQUATION
#   P_rev(z,q) = I_s(z, 1/2), s = 4pq, p = 1-q  (scipy.special.betainc)
#   Predicted: E[T_finality(z)] = z/lambda_b
#   Realized:  sum of z i.i.d. Exponential(lambda_b) draws
# =============================================================================
def p_rev(z, q: float):
    if not (0.0 < q < 0.5):
        raise ValueError(f"q must satisfy 0 < q < 0.5, got {q}")
    p = 1.0 - q
    s = 4.0 * p * q
    z_arr = np.asarray(z, dtype=float)
    out = betainc(z_arr, 0.5, s)
    return float(out) if np.isscalar(z) or np.ndim(z_arr) == 0 else out


def expected_t_finality(z, lambda_b: float):
    if lambda_b <= 0:
        raise ValueError("lambda_b must be > 0")
    return np.asarray(z, dtype=float) / lambda_b


def sample_realized_t_finality(z: int, lambda_b: float, rng: np.random.Generator) -> float:
    if z <= 0:
        return 0.0
    return float(rng.exponential(scale=1.0 / lambda_b, size=int(z)).sum())


def p_rev_combinatorial_reference(z: int, q: float) -> float:
    """Independent cross-check via the gambler's-ruin combinatorial series
    (Nakamoto/Grunspan-Perez-Marco), used only in validation, never hot path."""
    from math import comb
    p = 1.0 - q
    honest_stays_ahead = 0.0
    for k in range(0, z):
        honest_stays_ahead += comb(z - 1 + k, k) * ((p ** z) * (q ** k) - (p ** k) * (q ** z))
    return float(1.0 - honest_stays_ahead)


# --- v3: vectorised finality primitives ---------------------------------------
_PREV_TABLE_CACHE: Dict[float, np.ndarray] = {}


def p_rev_table(q: float, z_min: int = None, z_max: int = None) -> np.ndarray:
    """P_rev for z = z_min..z_max as a float array (same betainc as p_rev)."""
    z_min = Z_MIN if z_min is None else z_min
    z_max = Z_MAX if z_max is None else z_max
    key = (round(float(q), 12), z_min, z_max)
    tab = _PREV_TABLE_CACHE.get(key)
    if tab is None:
        tab = np.array([p_rev(z, q) for z in range(z_min, z_max + 1)], dtype=float)
        _PREV_TABLE_CACHE[key] = tab
    return tab


def z_required(tau: float, q: float, z_min: int = None, z_max: int = None) -> Optional[int]:
    """Smallest confirmation depth whose reversal probability satisfies
    P_rev(z,q) <= tau (1e-12 tolerance for boundary cases such as
    P_rev(1,0.15) == 0.30 exactly). None if no depth in range satisfies it."""
    z_min = Z_MIN if z_min is None else z_min
    z_max = Z_MAX if z_max is None else z_max
    tab = p_rev_table(q, z_min, z_max)
    ok = np.nonzero(tab <= tau + 1e-12)[0]
    return int(z_min + ok[0]) if len(ok) else None


class ErlangCDFTable:
    """Exact finality-time CDF F_z(t) = P[Erlang(z, lambda_b) <= t]
    = P(z, lambda_b*t) (regularised lower incomplete gamma), tabulated once on
    a fine grid of x = lambda_b*t so the hot path is a pure array lookup.
    Values are scipy.stats.gamma.cdf — validated in test 26."""

    def __init__(self, z_min: int = None, z_max: int = None,
                 x_max: float = ERLANG_TABLE_XMAX, dx: float = ERLANG_TABLE_DX):
        from scipy.stats import gamma as _gamma
        self.z_min = Z_MIN if z_min is None else z_min
        self.z_max = Z_MAX if z_max is None else z_max
        self.dx = float(dx)
        self.x = np.arange(0.0, x_max + dx, dx)
        zs = np.arange(self.z_min, self.z_max + 1)
        self.table = np.stack([_gamma.cdf(self.x, a=float(z), scale=1.0) for z in zs]).astype(np.float64)
        self.n = len(self.x)

    def cdf(self, lambda_b: float, t) -> np.ndarray:
        """t: scalar or 1-D array of times (s). Returns array shape
        (n_z, len(t)) of P[T_fin(z) <= t]; t<0 -> 0, t beyond table -> 1."""
        t_arr = np.atleast_1d(np.asarray(t, dtype=float))
        x = lambda_b * t_arr
        idx = np.floor(x / self.dx + 0.5).astype(np.int64)
        out = np.empty((self.table.shape[0], len(t_arr)), dtype=float)
        neg = x < 0.0
        over = idx >= self.n
        mid = ~(neg | over)
        out[:, neg] = 0.0
        out[:, over] = 1.0
        if mid.any():
            out[:, mid] = self.table[:, idx[mid]]
        return out


_ERLANG_TABLE: Optional[ErlangCDFTable] = None


def erlang_table() -> ErlangCDFTable:
    """Rows z = Z_MIN .. Z_MAX+1 (the extra row gives F_{z+1}, used by the on-time
    truncated expectation E[T_fin 1(T_fin <= s)] = (z/lambda_b) F_{z+1}(s))."""
    global _ERLANG_TABLE
    if _ERLANG_TABLE is None:
        _ERLANG_TABLE = ErlangCDFTable(z_max=Z_MAX + 1)
    return _ERLANG_TABLE


# =============================================================================
# SECTION 4: EDGE/FOG/CLOUD RESOURCE TIMING PRIMITIVES
#   T_total(r,z) = T_comm(r) + T_queue(r) + T_compute(r) + T_finality_wait(z)
# =============================================================================
def t_comm(tier: str, payload_bytes: float) -> float:
    cfg = RESOURCE_TIERS[tier]
    return payload_bytes / cfg["bandwidth_Bps"] + cfg["prop_delay_s"]


def t_compute(tier: str, compute_demand_cycles: float) -> float:
    cfg = RESOURCE_TIERS[tier]
    return compute_demand_cycles / cfg["compute_capacity_cycles_per_s"]


def t_queue_snapshot(tier: str, sim_state: dict) -> float:
    """PREDICTED (decision-time) queueing estimate. v3: the orchestrator keeps
    a ledger of tasks it has COMMITTED to the tier that have not finished
    computing (in transit + waiting + in service) — `inflight` — which a real
    dispatcher always knows. Expected FCFS wait behind n = inflight tasks on
    c servers with mean service S:  0 if n < c, else (n-c)/c*S + S/2 (mean
    residual service of the task being replaced). Falls back to the legacy
    live-resource backlog (in-service + waiting) when no ledger exists.
    NOT a substitute for the actual applied wait, which always comes from the
    SimPy resource itself in the DES below."""
    st = sim_state[tier]
    num_servers = RESOURCE_TIERS[tier]["num_servers"]
    if num_servers <= 0:
        return float("inf")
    mean_service_time = st.get("mean_service_time", 0.0)
    if "inflight" in st:
        n_ahead = st["inflight"]
        if n_ahead < num_servers:
            return 0.0
        if QUEUE_EST == "work" and (DEMAND_CV or 0.0) > 0.0 and st.get("work_cycles", 0.0) > 0.0 and n_ahead > 0:
            # v6 work-weighted estimate: committed nominal work W on m servers, minus the mean residual
            # correction; reduces to the count formula when every committed task has the same demand.
            w = st["work_cycles"] / RESOURCE_TIERS[tier]["compute_capacity_cycles_per_s"]
            return max(0.0, (w / num_servers) * (1.0 - num_servers / (2.0 * n_ahead)))
        return ((n_ahead - num_servers) / num_servers) * mean_service_time + 0.5 * mean_service_time
    res = st["resource"]
    backlog = res.count + len(res.queue)
    return (backlog / num_servers) * mean_service_time


def tier_load_factor(tier: str, sim_state: dict) -> float:
    """Server contention on a tier at decision time: min(1, n_inflight / c).
    0 = every server idle (a deadline miss costs no other task anything),
    1 = all servers committed (a miss wastes a slot another task could use)."""
    st = sim_state[tier]
    c = RESOURCE_TIERS[tier]["num_servers"]
    if c <= 0:
        return 1.0
    if "inflight" in st:
        n = st["inflight"]
    else:
        res = st["resource"]
        n = res.count + len(res.queue)
    return float(min(1.0, n / c))


# =============================================================================
# SECTION 5: DEADLINE MODEL — FROZEN, blockchain-aware T_base
#   T_base = T_comm(Edge) + T_compute(Edge) + E[T_finality(z_min)]
#   D_task = rho_D * T_base   — computed ONCE per task, IDENTICAL across tiers
# =============================================================================
def t_base(payload_bytes: float, compute_demand_cycles: float, lambda_b: float,
           z_min: int = None, reference_tier: str = REFERENCE_TIER_FOR_DEADLINE) -> float:
    z_min = Z_MIN if z_min is None else z_min
    return (t_comm(reference_tier, payload_bytes)
            + t_compute(reference_tier, compute_demand_cycles)
            + float(expected_t_finality(z_min, lambda_b)))


def d_task(payload_bytes: float, compute_demand_cycles: float, rho_D: float, lambda_b: float,
           z_min: int = None, reference_tier: str = REFERENCE_TIER_FOR_DEADLINE) -> float:
    if rho_D <= 0:
        raise ValueError("rho_D must be > 0")
    return rho_D * t_base(payload_bytes, compute_demand_cycles, lambda_b, z_min, reference_tier)


# --- v3: per-task profile (a_i, L_i, C_i, D_i, chi_i, tau_i) -----------------
@dataclasses.dataclass
class TaskCtx:
    """Algorithm-independent task profile handed to every decide() function.
    D_task is computed ONCE here (never per tier, never per algorithm)."""
    D_task: float
    tau: float
    chi: float
    z_req: Optional[int]
    risk_class: int


def assign_risk_classes(n_tasks: int, seed: int) -> np.ndarray:
    """Risk-class code per task (in trace order) from a generator keyed by
    (seed, 'risk-class' stream id) only. Same for every algorithm under a
    seed (CRN); independent of the block-interval stream (_task_block_rng)."""
    rng = np.random.default_rng(np.random.SeedSequence([int(seed), 7_001]))
    u = rng.random(n_tasks)
    edges = np.cumsum([rc["share"] for rc in RISK_CLASSES])
    return np.searchsorted(edges, u, side="right").clip(0, len(RISK_CLASSES) - 1).astype(np.int8)


def assign_deadline_budgets(n_tasks: int, seed: int) -> np.ndarray:
    """Finality budget b_i (s) for the independent deadline mode: seeded stream 7_002,
    independent of the risk-class stream (7_001) and of every policy."""
    rng = np.random.default_rng(np.random.SeedSequence([int(seed), 7_002]))
    lo, hi = INDEP_BUDGET_RANGE
    return rng.uniform(lo, hi, n_tasks)


def make_task_ctx(payload_bytes: float, compute_cycles: float, risk_class: int,
                  rho_D: float, lambda_b: float, q: float, fin_budget: Optional[float] = None,
                  nominal_cycles: Optional[float] = None) -> TaskCtx:
    rc = RISK_CLASSES[int(risk_class)]
    z_req = z_required(rc["tau"], q)
    if DEADLINE_MODE == "sizefree":
        # v7: deadline independent of the task's own demand -- the edge reference time uses the
        # workload's nominal demand, plus the class-independent finality budget b_i
        b = fin_budget if fin_budget is not None else 0.5 * sum(INDEP_BUDGET_RANGE)
        c_nom = compute_cycles if nominal_cycles is None else nominal_cycles
        dt = rho_D * (t_comm(REFERENCE_TIER_FOR_DEADLINE, payload_bytes)
                      + t_compute(REFERENCE_TIER_FOR_DEADLINE, c_nom)) + float(b)
    elif DEADLINE_MODE == "independent":
        b = fin_budget if fin_budget is not None else 0.5 * sum(INDEP_BUDGET_RANGE)
        dt = rho_D * (t_comm(REFERENCE_TIER_FOR_DEADLINE, payload_bytes)
                      + t_compute(REFERENCE_TIER_FOR_DEADLINE, compute_cycles)) + float(b)
    else:
        z_ref = z_req if z_req is not None else Z_MAX
        dt = d_task(payload_bytes, compute_cycles, rho_D, lambda_b, z_min=z_ref)
    return TaskCtx(D_task=dt, tau=rc["tau"], chi=rc["chi"], z_req=z_req, risk_class=int(risk_class))


def _dt_from_ctx(task_ctx: Optional[TaskCtx], payload_bytes, compute_cycles, rho_D, lambda_b) -> float:
    """Every algorithm (legacy included) reads D_i from the shared task
    profile when one is supplied; the legacy z_min-referenced deadline is
    used only when no profile is given (unit tests / direct calls)."""
    if task_ctx is not None:
        return task_ctx.D_task
    return d_task(payload_bytes, compute_cycles, rho_D, lambda_b)


# =============================================================================
# SECTION 6: DECISION CORE — the frozen FARO-IoT objective + exhaustive search
#   J(r,z) = T_total(r,z)/D_task + C_rev*P_rev(z,q)
#   (r*,z*) = argmin over ALL feasible (r,z); no feasible -> admitted=False
# =============================================================================
@dataclasses.dataclass
class Decision:
    tier: Optional[str]
    z: Optional[int]
    T_comm: Optional[float] = None
    T_queue: Optional[float] = None
    T_compute: Optional[float] = None
    T_finality_wait: Optional[float] = None
    T_total: Optional[float] = None
    D_task: Optional[float] = None
    P_rev: Optional[float] = None
    J: Optional[float] = None
    feasible: bool = False
    admitted: bool = False
    infeasible_task: bool = False
    diagnostic_best_effort: Optional[Dict[str, Any]] = None
    decision_time_ms: float = 0.0
    # v3 fields (None for legacy algorithms)
    P_on_time: Optional[float] = None   # predicted probability of meeting D_i
    U: Optional[float] = None           # expected safe utility of the chosen candidate
    reject_reason: Optional[str] = None # risk_infeasible | deadline_infeasible | admission_test


def _evaluate_candidate(tier, payload_bytes, compute_demand_cycles, dtask_value, q, lambda_b,
                         c_rev, z, sim_state, no_risk) -> Dict[str, Any]:
    tc = t_comm(tier, payload_bytes)
    tq = t_queue_snapshot(tier, sim_state)
    tcomp = t_compute(tier, compute_demand_cycles)
    tfin = float(expected_t_finality(z, lambda_b))
    total = tc + tq + tcomp + tfin
    pr = p_rev(z, q)
    risk_term = 0.0 if no_risk else c_rev * pr
    j = total / dtask_value + risk_term
    feasible = total <= dtask_value
    return dict(tier=tier, z=z, T_comm=tc, T_queue=tq, T_compute=tcomp, T_finality_wait=tfin,
                T_total=total, D_task=dtask_value, P_rev=pr, J=j, feasible=feasible)


def joint_optimize(payload_bytes, compute_demand_cycles, dtask_value, q, lambda_b, c_rev,
                    sim_state, no_risk: bool = False, z_min: int = None, z_max: int = None,
                    tiers=None) -> Decision:
    z_min = Z_MIN if z_min is None else z_min
    z_max = Z_MAX if z_max is None else z_max
    tiers = TIER_NAMES if tiers is None else tiers

    all_candidates = []
    for tier in tiers:
        for z in range(z_min, z_max + 1):
            all_candidates.append(_evaluate_candidate(
                tier, payload_bytes, compute_demand_cycles, dtask_value, q, lambda_b, c_rev,
                z, sim_state, no_risk))

    feasible = [c for c in all_candidates if c["feasible"]]
    if feasible:
        best = min(feasible, key=lambda c: c["J"])
        return Decision(tier=best["tier"], z=best["z"], T_comm=best["T_comm"], T_queue=best["T_queue"],
                         T_compute=best["T_compute"], T_finality_wait=best["T_finality_wait"],
                         T_total=best["T_total"], D_task=dtask_value, P_rev=best["P_rev"], J=best["J"],
                         feasible=True, admitted=True, infeasible_task=False)
    best_effort = min(all_candidates, key=lambda c: c["J"]) if all_candidates else None
    return Decision(tier=None, z=None, D_task=dtask_value, feasible=False, admitted=False,
                     infeasible_task=True, diagnostic_best_effort=best_effort)


def act_wait_select_z(tier, payload_bytes, compute_demand_cycles, dtask_value, q, lambda_b,
                       c_rev, sim_state, z_min: int = None, z_max: int = None) -> Optional[int]:
    """Local ACT/WAIT rule (checked only for equivalence against the global
    argmin — never used to produce the admitted decision itself)."""
    z_min = Z_MIN if z_min is None else z_min
    z_max = Z_MAX if z_max is None else z_max
    z = z_min
    while z < z_max:
        cand_z = _evaluate_candidate(tier, payload_bytes, compute_demand_cycles, dtask_value,
                                      q, lambda_b, c_rev, z, sim_state, no_risk=False)
        cand_z1 = _evaluate_candidate(tier, payload_bytes, compute_demand_cycles, dtask_value,
                                       q, lambda_b, c_rev, z + 1, sim_state, no_risk=False)
        if not cand_z1["feasible"]:
            break
        delta_t_wait = cand_z1["T_total"] - cand_z["T_total"]
        wait_cost = delta_t_wait / dtask_value
        wait_benefit = c_rev * (cand_z["P_rev"] - cand_z1["P_rev"])
        if wait_cost < wait_benefit:
            z += 1
        else:
            break
    final = _evaluate_candidate(tier, payload_bytes, compute_demand_cycles, dtask_value,
                                 q, lambda_b, c_rev, z, sim_state, no_risk=False)
    return z if final["feasible"] else None


def direct_minimize_z(tier, payload_bytes, compute_demand_cycles, dtask_value, q, lambda_b,
                       c_rev, sim_state, z_min: int = None, z_max: int = None) -> Optional[int]:
    z_min = Z_MIN if z_min is None else z_min
    z_max = Z_MAX if z_max is None else z_max
    candidates = [_evaluate_candidate(tier, payload_bytes, compute_demand_cycles, dtask_value,
                                       q, lambda_b, c_rev, z, sim_state, no_risk=False)
                  for z in range(z_min, z_max + 1)]
    feasible = [c for c in candidates if c["feasible"]]
    if not feasible:
        return None
    return min(feasible, key=lambda c: c["J"])["z"]


# =============================================================================
# SECTION 6b (v3): CALIBRATED EXPECTED-SAFE-UTILITY DECISION CORE
#   P_on(r,z) = (1/K) sum_k F_z( D_i - T_comm - T_compute - T_queue_hat - e_k )
#               e_k : per-tier residual quantile points (online), F_z: Erlang CDF
#   U(r,z)    = P_on * (1 - gamma*E[T]/D_i - C_rev*chi_i*P_rev(z,q)) - beta*(1 - P_on)
#   feasible  : P_rev(z,q) <= tau_i          (unless the NoTau ablation)
#   (r*,z*)   = argmax U over feasible;  ADMIT iff U* > 0
# =============================================================================
class OnlineResidualCalibrator:
    """Per-tier rolling empirical distribution of the queue-wait prediction
    residual e = realized_T_queue - predicted_T_queue. Exposes equal-weight
    quantile points used as quadrature nodes in P_on. Distribution-free;
    warm-starts as the zero-residual (uncalibrated) model. Never sees labels."""

    def __init__(self, window: int = None, levels=None, refresh_every: int = None,
                 min_samples: int = None, enabled: bool = True):
        from collections import deque
        self.enabled = enabled
        self.window = CAL_WINDOW if window is None else int(window)
        self.levels = np.asarray(CAL_QUANTILE_LEVELS if levels is None else levels, dtype=float)
        self.refresh_every = CAL_REFRESH_EVERY if refresh_every is None else int(refresh_every)
        self.min_samples = CAL_MIN_SAMPLES if min_samples is None else int(min_samples)
        self._buf = {t: deque(maxlen=self.window) for t in TIER_NAMES}
        self._n_since = {t: 0 for t in TIER_NAMES}
        self._zero = np.zeros(1, dtype=float)
        self._points = {t: self._zero for t in TIER_NAMES}
        self.n_updates = 0

    def points(self, tier: str) -> np.ndarray:
        return self._points[tier]

    def update(self, tier: Optional[str], success: bool, info: Optional[dict] = None) -> None:
        if not self.enabled or tier is None or info is None:
            return
        rq, pq = info.get("realized_T_queue"), info.get("predicted_T_queue")
        if rq is None or pq is None:
            return
        self._buf[tier].append(float(rq) - float(pq))
        self.n_updates += 1
        self._n_since[tier] += 1
        buf = self._buf[tier]
        if len(buf) >= self.min_samples and self._n_since[tier] >= self.refresh_every:
            self._points[tier] = np.quantile(np.fromiter(buf, dtype=float, count=len(buf)), self.levels)
            self._n_since[tier] = 0

    def snapshot(self) -> Dict[str, Any]:
        return {t: dict(n=len(self._buf[t]), points=self._points[t].tolist()) for t in TIER_NAMES}


def esu_optimize(payload_bytes, compute_demand_cycles, task_ctx: TaskCtx, q, lambda_b, c_rev,
                 beta, sim_state, calibrator: Optional[OnlineResidualCalibrator] = None,
                 enforce_tau: bool = True, z_min: int = None, z_max: int = None,
                 tiers=None, penalty_mode: str = "fixed", ext_eta: float = 0.0,
                 inv_d_mean: Optional[float] = None) -> Decision:
    """v3 decision: vectorised over z per tier. Returns the admitted
    Decision (with P_on_time and U filled) or a rejection with diagnostics."""
    z_min = Z_MIN if z_min is None else z_min
    z_max = Z_MAX if z_max is None else z_max
    tiers = TIER_NAMES if tiers is None else tiers
    zs = np.arange(z_min, z_max + 1)
    pr = p_rev_table(q, z_min, z_max)
    tab = erlang_table()
    dt = task_ctx.D_task
    risk_ok = (pr <= task_ctx.tau + 1e-12) if enforce_tau else np.ones_like(pr, dtype=bool)
    if not risk_ok.any():
        return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False, infeasible_task=True,
                        reject_reason="risk_infeasible")
    risk_loss = c_rev * task_ctx.chi * pr
    t_fin_exp = zs / float(lambda_b)
    r0 = z_min - tab.z_min            # row of F_{z_min}
    r1 = z_max - tab.z_min + 1        # one past row of F_{z_max}

    best = None
    best_u = -np.inf
    diag = None
    diag_u = -np.inf
    for tier in tiers:
        tc = t_comm(tier, payload_bytes)
        tq = t_queue_snapshot(tier, sim_state)
        tcomp = t_compute(tier, compute_demand_cycles)
        slack = dt - (tc + tq + tcomp)
        pts = calibrator.points(tier) if calibrator is not None else np.zeros(1)
        full = tab.cdf(lambda_b, slack - pts)                 # (n_rows, K): F_z(slack - e_k)
        Fz = full[r0:r1]                                      # z = z_min..z_max
        Fz1 = full[r0 + 1:r1 + 1]                             # z + 1
        p_on = Fz.mean(axis=1)
        # E[T_total * 1(T_total <= D)] averaged over the K residual nodes (exact Erlang identity)
        t_pre_k = (tc + tq + tcomp) + pts                     # (K,)
        e_ontime_T = (Fz * t_pre_k[None, :]).mean(axis=1) + t_fin_exp * Fz1.mean(axis=1)
        if penalty_mode == "congestion":
            p_on0 = tab.cdf(lambda_b, (dt - (tc + tcomp)) - pts)[r0:r1].mean(axis=1)   # queue wait removed
            miss_pen = beta * np.maximum(p_on0 - p_on, 0.0)
        elif penalty_mode == "load":
            miss_pen = beta * tier_load_factor(tier, sim_state) * (1.0 - p_on)
        else:
            miss_pen = beta * (1.0 - p_on)
        u = p_on * (1.0 - risk_loss) - GAMMA_LAT * e_ontime_T / dt - miss_pen
        # v6 externality toll (Naor-type): the delay an admission adds for later tasks on a busy tier
        if ext_eta <= 0.0 or tq <= 0.0:
            toll = 0.0
        elif TOLL_FORM == "work" and inv_d_mean is not None:
            s_bar = sim_state[tier].get("mean_service_time", 0.0) or tcomp
            toll = ext_eta * tier_load_factor(tier, sim_state) * (tcomp / s_bar) * tq * inv_d_mean
        else:
            toll = ext_eta * tier_load_factor(tier, sim_state) * tq / dt
        u = u - toll
        if ADMIT_RULE == "nolat":
            u_adm = u + GAMMA_LAT * e_ontime_T / dt
        elif ADMIT_RULE == "nolatrisk":
            u_adm = p_on - miss_pen - toll
        else:
            u_adm = u
        u_masked = np.where(risk_ok, u, -np.inf)
        j = int(np.argmax(u_masked))
        if u_masked[j] > best_u:
            best_u = float(u_masked[j])
            tfin = float(expected_t_finality(zs[j], lambda_b))
            best = dict(tier=tier, z=int(zs[j]), T_comm=tc, T_queue=tq, T_compute=tcomp,
                        T_finality_wait=tfin, T_total=tc + tq + tcomp + tfin, P_rev=float(pr[j]),
                        P_on=float(p_on[j]), U=float(u_masked[j]), U_adm=float(u_adm[j]))
        jd = int(np.argmax(u))
        if u[jd] > diag_u:
            diag_u = float(u[jd])
            diag = dict(tier=tier, z=int(zs[jd]), P_rev=float(pr[jd]), P_on=float(p_on[jd]), U=float(u[jd]))

    if best is not None and np.isfinite(best_u) and best["U_adm"] > 0.0:
        return Decision(tier=best["tier"], z=best["z"], T_comm=best["T_comm"], T_queue=best["T_queue"],
                        T_compute=best["T_compute"], T_finality_wait=best["T_finality_wait"],
                        T_total=best["T_total"], D_task=dt, P_rev=best["P_rev"],
                        J=-best["U"], feasible=True, admitted=True, infeasible_task=False,
                        P_on_time=best["P_on"], U=best["U"])
    return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False, infeasible_task=True,
                    diagnostic_best_effort=diag,
                    P_on_time=(best["P_on"] if best is not None else None),
                    U=(best_u if np.isfinite(best_u) else None), reject_reason="admission_test")


def joint_optimize_tau(payload_bytes, compute_demand_cycles, task_ctx: TaskCtx, q, lambda_b, c_rev,
                       sim_state, no_risk: bool = False) -> Decision:
    """FARO-Expected ablation: the frozen v2 objective J and expected-value
    feasibility, plus the per-task tau_i constraint (z >= z_req)."""
    if task_ctx.z_req is None:
        return Decision(tier=None, z=None, D_task=task_ctx.D_task, feasible=False, admitted=False,
                        infeasible_task=True)
    return joint_optimize(payload_bytes, compute_demand_cycles, task_ctx.D_task, q, lambda_b,
                          c_rev * task_ctx.chi, sim_state, no_risk=no_risk,
                          z_min=max(Z_MIN, task_ctx.z_req), z_max=Z_MAX)


# =============================================================================
# SECTION 7: ALGORITHMS — FARO-IoT, FARO-NoRisk, FARO-FixedZ,
#            Fang et al.-adapted, SharpEdge-adapted
# =============================================================================
def faro3_decide_factory(q: float, lambda_b: float, c_rev: float, rho_D: float,
                         beta: float = None, calibrate: bool = True, enforce_tau: bool = True,
                         min_depth_only: bool = False, penalty_mode: str = "fixed", ext_eta: float = 0.0):
    """v3 FARO-IoT (and its NoCal / NoTau / MinDepth ablations). Returns (decide, post_update).
    min_depth_only: restrict the depth to z_req(tau_i) (RTD's depth rule) while keeping the
    probabilistic utility/admission -- the control that isolates admission from depth choice."""
    beta = BETA_MISS if beta is None else beta
    cal = OnlineResidualCalibrator(enabled=calibrate)
    invd = dict(n=0, m=0.0)   # running mean of 1/D over arriving tasks (policy-internal, causal)

    def decide(payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        if task_ctx is None:  # direct/unit-test call: STANDARD class profile
            task_ctx = make_task_ctx(payload_bytes, compute_cycles, RISK_CLASS_CODE["STANDARD"],
                                     rho_D, lambda_b, q)
        invd["n"] += 1
        invd["m"] += (1.0 / task_ctx.D_task - invd["m"]) / min(invd["n"], 10_000)
        if min_depth_only:
            if task_ctx.z_req is None:
                return Decision(tier=None, z=None, D_task=task_ctx.D_task, feasible=False, admitted=False,
                                infeasible_task=True, reject_reason="risk_infeasible")
            return esu_optimize(payload_bytes, compute_cycles, task_ctx, q, lambda_b, c_rev, beta,
                                sim_state, calibrator=cal, enforce_tau=enforce_tau,
                                z_min=task_ctx.z_req, z_max=task_ctx.z_req, penalty_mode=penalty_mode,
                                ext_eta=ext_eta, inv_d_mean=invd["m"])
        return esu_optimize(payload_bytes, compute_cycles, task_ctx, q, lambda_b, c_rev, beta,
                            sim_state, calibrator=cal, enforce_tau=enforce_tau, penalty_mode=penalty_mode,
                            ext_eta=ext_eta, inv_d_mean=invd["m"])
    decide.calibrator = cal
    decide.invd = invd
    return decide, cal.update


def faro_expected_decide_factory(q: float, lambda_b: float, c_rev: float, rho_D: float):
    def decide(payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        if task_ctx is None:
            task_ctx = make_task_ctx(payload_bytes, compute_cycles, RISK_CLASS_CODE["STANDARD"],
                                     rho_D, lambda_b, q)
        return joint_optimize_tau(payload_bytes, compute_cycles, task_ctx, q, lambda_b, c_rev, sim_state)
    return decide


def faro_decide_factory(q: float, lambda_b: float, c_rev: float, rho_D: float):
    def decide(payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        dt = _dt_from_ctx(task_ctx, payload_bytes, compute_cycles, rho_D, lambda_b)
        return joint_optimize(payload_bytes, compute_cycles, dt, q, lambda_b, c_rev, sim_state, no_risk=False)
    return decide


def faro_norisk_decide_factory(q: float, lambda_b: float, c_rev: float, rho_D: float):
    """FARO-NoRisk: J = T_total/D_task, drops C_rev*P_rev."""
    def decide(payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        dt = _dt_from_ctx(task_ctx, payload_bytes, compute_cycles, rho_D, lambda_b)
        return joint_optimize(payload_bytes, compute_cycles, dt, q, lambda_b, c_rev, sim_state, no_risk=True)
    return decide


def faro_fixedz_decide_factory(q: float, lambda_b: float, c_rev: float, rho_D: float, fixed_z: int = None):
    """FARO-FixedZ: same risk-aware objective and tier search, z fixed at
    FARO_FIXEDZ_VALUE (chosen before looking at results) instead of searched."""
    fz = FARO_FIXEDZ_VALUE if fixed_z is None else fixed_z

    def decide(payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        dt = _dt_from_ctx(task_ctx, payload_bytes, compute_cycles, rho_D, lambda_b)
        return joint_optimize(payload_bytes, compute_cycles, dt, q, lambda_b, c_rev, sim_state,
                               no_risk=False, z_min=fz, z_max=fz)
    return decide


def _fang_energy(tier: str, t_comm_s: float, t_compute_s: float) -> float:
    ghz = RESOURCE_TIERS[tier]["compute_capacity_cycles_per_s"] / 1e9
    return ENERGY_TX_WATT[tier] * t_comm_s + ENERGY_COMPUTE_WATT_PER_GHZ[tier] * ghz * t_compute_s


def fang_adapted_decide_factory(q: float, lambda_b: float, rho_D: float, fixed_z: int = None):
    """Fang et al.-adapted (Fang, Lin, Liu, Liu, IET Communications 2024,
    DOI 10.1049/cmu2.12703). Environment-normalized adaptation of the
    blockchain-enabled delay-constrained task-offloading and
    resource-allocation principles of Fang et al.; it is not a reproduction
    of their CRL implementation. Preserves: blockchain-aware offloading,
    delay-constrained feasibility, resource-aware placement, communication
    cost, compute cost. Does NOT use FARO's C_rev*P_rev risk objective.
    FANG_FIXED_Z=6 is an [S] adaptation parameter — NOT claimed as Fang's own."""
    fz = FANG_FIXED_Z if fixed_z is None else fixed_z

    def decide(payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        dt = _dt_from_ctx(task_ctx, payload_bytes, compute_cycles, rho_D, lambda_b)
        candidates = []
        for tier in TIER_NAMES:
            tc = t_comm(tier, payload_bytes)
            tq = t_queue_snapshot(tier, sim_state)
            tcomp = t_compute(tier, compute_cycles)
            tfin = float(expected_t_finality(fz, lambda_b))
            total = tc + tq + tcomp + tfin
            energy = _fang_energy(tier, tc, tcomp)
            candidates.append(dict(tier=tier, T_comm=tc, T_queue=tq, T_compute=tcomp,
                                    T_finality_wait=tfin, T_total=total, energy=energy,
                                    feasible=(total <= dt)))
        feasible = [c for c in candidates if c["feasible"]]
        pr = p_rev(fz, q)
        if feasible:
            best = min(feasible, key=lambda c: c["energy"])
            return Decision(tier=best["tier"], z=fz, T_comm=best["T_comm"], T_queue=best["T_queue"],
                             T_compute=best["T_compute"], T_finality_wait=best["T_finality_wait"],
                             T_total=best["T_total"], D_task=dt, P_rev=pr, J=best["energy"],
                             feasible=True, admitted=True, infeasible_task=False)
        diag = min(candidates, key=lambda c: c["energy"]) if candidates else None
        return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False,
                         infeasible_task=True, diagnostic_best_effort=diag)
    return decide


def sharpedge_new_reputation_state() -> Dict[str, float]:
    return {t: REPUTATION_INITIAL for t in TIER_NAMES}


def sharpedge_make_reputation_updater(reputation_state: Dict[str, float]):
    """Simulation-controlled approximation of historical-performance
    reputation; NOT claimed to be the original SharpEdge reputation equation."""
    def update(tier: Optional[str], success: bool, info: Optional[dict] = None) -> None:
        if tier is None:
            return
        reputation_state[tier] = ((1 - REPUTATION_EWMA_ALPHA) * reputation_state[tier]
                                   + REPUTATION_EWMA_ALPHA * (1.0 if success else 0.0))
    return update


def sharpedge_adapted_decide_factory(q: float, lambda_b: float, rho_D: float,
                                      reputation_state: Dict[str, float], fixed_z: int = None):
    """SharpEdge-adapted (Gu, Liu, Xu, Concurrency and Computation 2024,
    DOI 10.1002/cpe.8161). Preserves the QoS-aware peer-offloading and
    historical-performance executor-selection principles of SharpEdge within
    the common Edge-Fog-Cloud simulation environment; not claimed as an exact
    reproduction of the original implementation. SHARPEDGE_FIXED_Z=1 and the
    reputation EWMA are [S] adaptation parameters. Does NOT use FARO's
    C_rev*P_rev risk objective."""
    fz = SHARPEDGE_FIXED_Z if fixed_z is None else fixed_z

    def decide(payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        dt = _dt_from_ctx(task_ctx, payload_bytes, compute_cycles, rho_D, lambda_b)
        candidates = []
        for tier in TIER_NAMES:
            tc = t_comm(tier, payload_bytes)
            tq = t_queue_snapshot(tier, sim_state)
            tcomp = t_compute(tier, compute_cycles)
            tfin = float(expected_t_finality(fz, lambda_b))
            total = tc + tq + tcomp + tfin
            candidates.append(dict(tier=tier, T_comm=tc, T_queue=tq, T_compute=tcomp,
                                    T_finality_wait=tfin, T_total=total,
                                    reputation=reputation_state[tier], feasible=(total <= dt)))
        feasible = [c for c in candidates if c["feasible"]]
        pr = p_rev(fz, q)
        if feasible:
            best = max(feasible, key=lambda c: (c["reputation"], -c["T_total"]))
            return Decision(tier=best["tier"], z=fz, T_comm=best["T_comm"], T_queue=best["T_queue"],
                             T_compute=best["T_compute"], T_finality_wait=best["T_finality_wait"],
                             T_total=best["T_total"], D_task=dt, P_rev=pr, J=best["reputation"],
                             feasible=True, admitted=True, infeasible_task=False)
        diag = min(candidates, key=lambda c: c["T_total"]) if candidates else None
        return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False,
                         infeasible_task=True, diagnostic_best_effort=diag)
    return decide


def rtd_adapted_decide_factory(q: float, lambda_b: float, rho_D: float, fixed_depth: Optional[int] = None):
    """RTD-adapted — Risk-Thresholded Depth (Hicks et al. 2025, arXiv:2511.15421;
    Kovalchuk et al. 2026, Sustainability 18(3):1673): the confirmation depth is
    the smallest z whose reversal probability meets the task's risk tolerance,
    z = z_req(tau_i); execution then goes to the fastest tier that is
    expected-feasible (min E[T_total], T_total <= D_i). Environment-normalised
    adaptation: those works have no execution tier or deadline; the tier rule
    is this project's [S] addition. No utility, no probabilistic on-time model."""
    def decide(payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        if task_ctx is None:
            task_ctx = make_task_ctx(payload_bytes, compute_cycles, RISK_CLASS_CODE["STANDARD"], rho_D, lambda_b, q)
        dt = task_ctx.D_task
        z = task_ctx.z_req if fixed_depth is None else int(fixed_depth)
        if z is None:
            return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False, infeasible_task=True,
                            reject_reason="risk_infeasible")
        pr = p_rev(z, q)
        tfin = float(expected_t_finality(z, lambda_b))
        best = None
        for tier in TIER_NAMES:
            tc, tq, tcomp = t_comm(tier, payload_bytes), t_queue_snapshot(tier, sim_state), t_compute(tier, compute_cycles)
            total = tc + tq + tcomp + tfin
            if total <= dt and (best is None or total < best["T_total"]):
                best = dict(tier=tier, T_comm=tc, T_queue=tq, T_compute=tcomp, T_total=total)
        if best is None:
            return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False, infeasible_task=True,
                            reject_reason="deadline_infeasible")
        return Decision(tier=best["tier"], z=z, T_comm=best["T_comm"], T_queue=best["T_queue"], T_compute=best["T_compute"],
                        T_finality_wait=tfin, T_total=best["T_total"], D_task=dt, P_rev=pr, J=best["T_total"],
                        feasible=True, admitted=True, infeasible_task=False)
    return decide


def safe_admission_decide_factory(q: float, lambda_b: float, rho_D: float, rule: str, param: float = 0.0):
    """v5 simple risk-feasible admission baselines (same state information as FARO-IoT):
    depth z_req(tau_i); tier = smallest predicted pre-confirmation time among the allowed tiers;
      rule 'slack'   : admit iff slack D_i - T_pre > 0 (P_on > 0)
      rule 'prob'    : admit iff P_on = F_z(D_i - T_pre) >= param (threshold tuned on development seeds)
      rule 'queuecap': tiers with committed load n_r/m_r > param are excluded; then RTD's expected-value
                       feasibility test (T_pre + z/lambda_b <= D_i) on the fastest remaining tier."""
    tab = erlang_table()
    invd = dict(n=0, m=0.0)   # sizegate: running mean of 1/D over arrivals, same estimator as FARO-IoT

    def decide(payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        if task_ctx is None:
            task_ctx = make_task_ctx(payload_bytes, compute_cycles, RISK_CLASS_CODE["STANDARD"], rho_D, lambda_b, q)
        dt = task_ctx.D_task
        invd["n"] += 1
        invd["m"] += (1.0 / dt - invd["m"]) / min(invd["n"], 10_000)
        z = task_ctx.z_req
        if z is None:
            return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False, infeasible_task=True,
                            reject_reason="risk_infeasible")
        tfin = float(expected_t_finality(z, lambda_b))
        best = None
        for tier in TIER_NAMES:
            if rule == "queuecap":
                load = sim_state[tier]["inflight"] / max(1, RESOURCE_TIERS[tier]["num_servers"])
                if load > param:
                    continue
            if rule == "workcap":
                # v7 size-aware cap: committed nominal work plus this task's service, in units of the
                # tier's mean service time per server; equals (n_r + 1)/m_r when demands are equal
                st = sim_state[tier]; m_ = max(1, RESOURCE_TIERS[tier]["num_servers"])
                f_ = RESOURCE_TIERS[tier]["compute_capacity_cycles_per_s"]
                s_bar = st.get("mean_service_time", 0.0) or t_compute(tier, compute_cycles)
                w_load = (st.get("work_cycles", 0.0) / f_ + t_compute(tier, compute_cycles)) / (m_ * s_bar)
                if w_load > param:
                    continue
            tc, tq, tcomp = t_comm(tier, payload_bytes), t_queue_snapshot(tier, sim_state), t_compute(tier, compute_cycles)
            if rule == "sizegate":
                # v7 size-sensitive gate: the work-scaled wait of FARO-IoT's toll, used as a hard threshold
                s_bar = sim_state[tier].get("mean_service_time", 0.0) or tcomp
                if (tcomp / s_bar) * tq * invd["m"] > param:
                    continue
            pre = tc + tq + tcomp
            if best is None or pre < best["pre"]:
                best = dict(tier=tier, T_comm=tc, T_queue=tq, T_compute=tcomp, pre=pre)
        if best is None:
            return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False, infeasible_task=True,
                            reject_reason="admission_test")
        slack = dt - best["pre"]
        p_on = float(tab.cdf(lambda_b, np.array([slack]))[z - tab.z_min, 0]) if slack > 0 else 0.0
        if rule == "slack":
            ok = slack > 0
        elif rule == "prob":
            ok = p_on >= param
        else:  # queuecap, workcap and sizegate: RTD's expected-value feasibility on the fastest allowed tier
            ok = best["pre"] + tfin <= dt
        if not ok:
            return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False, infeasible_task=True,
                            P_on_time=p_on, reject_reason=("deadline_infeasible" if rule in ("queuecap", "workcap", "sizegate") else "admission_test"))
        return Decision(tier=best["tier"], z=z, T_comm=best["T_comm"], T_queue=best["T_queue"], T_compute=best["T_compute"],
                        T_finality_wait=tfin, T_total=best["pre"] + tfin, D_task=dt, P_rev=p_rev(z, q), J=-p_on,
                        feasible=True, admitted=True, infeasible_task=False, P_on_time=p_on)
    return decide


TS_BANDIT_Z_ARMS = register("baseline.TSBandit.z_arms", [1, 2, 3, 4, 6], "confirmations", "S", "this project (v3.1)",
                            "Discrete confirmation-depth arms for the Thompson-sampling baseline.")
TS_BANDIT_LOAD_BUCKETS = register("baseline.TSBandit.load_buckets", [0.5, 1.0, 2.0], "inflight/servers", "S",
                                  "this project (v3.1)", "Context = (risk class, load bucket of the least-loaded tier).")


class TSBanditPolicy:
    """TS-Bandit-adapted — Thompson-sampling selection in the spirit of TSAPO
    (Xu et al. 2024, IEEE TMC, DOI 10.1109/TMC.2024.3507153: Thompson sampling
    for adaptive server selection under a blockchain-enabled MEC) and of the
    learning-based offloaders surveyed (Fan 2024; Heidari 2025). Arms are
    (tier, z) pairs; the reward is the study's own success event
    1[on time AND P_rev <= tau_i] observed at completion (delayed feedback);
    context = (risk class, load bucket). Beta(1,1) priors; a deterministic
    per-(seed) generator makes it reproducible. Expected-value feasibility
    (T_total <= D_i) gates the candidate arms like every other baseline."""

    def __init__(self, q, lambda_b, rho_D, seed, risk_mask: bool = False, arm_depths=None):
        self.q, self.lambda_b, self.rho_D = q, lambda_b, rho_D
        self.risk_mask = risk_mask
        self.rng = np.random.default_rng(np.random.SeedSequence([int(seed), 9_001]))
        depths = TS_BANDIT_Z_ARMS if arm_depths is None else list(arm_depths)
        self.arms = [(t, z) for t in TIER_NAMES for z in depths]
        n_ctx = len(RISK_CLASSES) * (len(TS_BANDIT_LOAD_BUCKETS) + 1)
        self.alpha = np.ones((n_ctx, len(self.arms)))
        self.beta = np.ones((n_ctx, len(self.arms)))
        self.pending: Dict[int, tuple] = {}

    def _ctx(self, risk_class: int, sim_state) -> int:
        load = min(sim_state[t]["inflight"] / max(1, RESOURCE_TIERS[t]["num_servers"]) for t in TIER_NAMES)
        b = int(np.searchsorted(np.asarray(TS_BANDIT_LOAD_BUCKETS), load, side="right"))
        return int(risk_class) * (len(TS_BANDIT_LOAD_BUCKETS) + 1) + b

    def decide(self, payload_bytes, compute_cycles, sim_state, task_ctx: Optional[TaskCtx] = None) -> Decision:
        if task_ctx is None:
            task_ctx = make_task_ctx(payload_bytes, compute_cycles, RISK_CLASS_CODE["STANDARD"],
                                     self.rho_D, self.lambda_b, self.q)
        dt = task_ctx.D_task
        ctx = self._ctx(task_ctx.risk_class, sim_state)
        theta = self.rng.beta(self.alpha[ctx], self.beta[ctx])
        best, best_theta = None, -1.0
        any_safe = False
        pre_cache = {}
        for k, (tier, z) in enumerate(self.arms):
            if self.risk_mask and p_rev(z, self.q) > task_ctx.tau + 1e-12:
                continue
            any_safe = True
            if tier not in pre_cache:
                pre_cache[tier] = (t_comm(tier, payload_bytes), t_queue_snapshot(tier, sim_state), t_compute(tier, compute_cycles))
            tc, tq, tcomp = pre_cache[tier]
            tfin = float(expected_t_finality(z, self.lambda_b))
            total = tc + tq + tcomp + tfin
            if total <= dt and theta[k] > best_theta:
                best_theta = theta[k]
                best = dict(k=k, tier=tier, z=z, T_comm=tc, T_queue=tq, T_compute=tcomp, T_finality_wait=tfin, T_total=total)
        if best is None:
            return Decision(tier=None, z=None, D_task=dt, feasible=False, admitted=False, infeasible_task=True,
                            reject_reason=("deadline_infeasible" if any_safe else "risk_infeasible"))
        d = Decision(tier=best["tier"], z=best["z"], T_comm=best["T_comm"], T_queue=best["T_queue"], T_compute=best["T_compute"],
                     T_finality_wait=best["T_finality_wait"], T_total=best["T_total"], D_task=dt,
                     P_rev=p_rev(best["z"], self.q), J=-best_theta, feasible=True, admitted=True, infeasible_task=False)
        d.diagnostic_best_effort = dict(ctx=ctx, arm=best["k"])
        return d

    def update(self, tier: Optional[str], success: bool, info: Optional[dict] = None) -> None:
        if tier is None or info is None or "ts_ctx" not in info:
            return
        ctx, arm = info["ts_ctx"], info["ts_arm"]
        reward = 1.0 if (success and info.get("safe_req", False)) else 0.0
        self.alpha[ctx, arm] += reward
        self.beta[ctx, arm] += 1.0 - reward


def ts_bandit_decide_factory(q: float, lambda_b: float, rho_D: float, seed: int = 0, risk_mask: bool = False,
                             arm_depths=None):
    pol = TSBanditPolicy(q, lambda_b, rho_D, seed, risk_mask=risk_mask, arm_depths=arm_depths)
    return pol.decide, pol.update


def _algo_name(name: str) -> str:
    import argparse as _ap
    ok = (name in ALGORITHMS or name in LEGACY_ALGORITHMS
          or name in ("SafeSlack", "TS-Bandit-masked-5arms", "FARO-IoT-NoToll")
          or name.startswith(("SafeProb-", "QueueCap-", "WorkCap-", "SizeGate-", "FARO-IoT-X")))
    if not ok:
        raise _ap.ArgumentTypeError(f"unknown algorithm {name!r}")
    if name.startswith(("SafeProb-", "QueueCap-", "WorkCap-", "SizeGate-")):
        float(name.split("-", 1)[1])
    if name.startswith("FARO-IoT-X"):
        float(name[len("FARO-IoT-X"):])
    return name


def _decide_fn_for(algorithm: str, q, lambda_b, c_rev, rho_D, beta: float = None, seed: int = 0):
    # ---- v4 proposed method and its ablations ----
    pm = PENALTY_MODE
    if algorithm == "FARO-IoT":
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=beta, calibrate=False, enforce_tau=True,
                                    min_depth_only=True, penalty_mode=pm, ext_eta=EXT_ETA)
    if algorithm == "FARO-IoT-NoToll":   # v5 FARO-IoT (no externality toll)
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=beta, calibrate=False, enforce_tau=True,
                                    min_depth_only=True, penalty_mode=pm, ext_eta=0.0)
    if algorithm.startswith("FARO-IoT-X"):  # v6 tuning grid: toll weight in the name
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=beta, calibrate=False, enforce_tau=True,
                                    min_depth_only=True, penalty_mode=pm,
                                    ext_eta=float(algorithm[len("FARO-IoT-X"):]))
    # v6: every ablation keeps the externality toll (EXT_ETA) so that each isolates one component;
    # FARO-IoT-NoToll isolates the toll itself.
    if algorithm == "FARO-IoT+Cal":
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=beta, calibrate=True, enforce_tau=True,
                                    min_depth_only=True, penalty_mode=pm, ext_eta=EXT_ETA)
    if algorithm == "FARO-IoT-FixedPenalty":
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=beta, calibrate=False, enforce_tau=True,
                                    min_depth_only=True, penalty_mode="fixed", ext_eta=EXT_ETA)
    if algorithm == "FARO-IoT-NoPenalty":
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=0.0, calibrate=False, enforce_tau=True,
                                    min_depth_only=True, ext_eta=EXT_ETA)
    if algorithm == "FARO-IoT-D":
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=beta, calibrate=False, enforce_tau=True,
                                    penalty_mode=pm, ext_eta=EXT_ETA)
    if algorithm.startswith("FixedDepth-"):
        return rtd_adapted_decide_factory(q, lambda_b, rho_D, fixed_depth=int(algorithm.split("-")[1])), None
    if algorithm == "TS-Bandit-masked":
        depths = list(range(Z_MIN, Z_MAX + 1)) if TS_MASKED_FULL_DEPTHS else None
        return ts_bandit_decide_factory(q, lambda_b, rho_D, seed, risk_mask=True, arm_depths=depths)
    if algorithm == "TS-Bandit-masked-5arms":
        return ts_bandit_decide_factory(q, lambda_b, rho_D, seed, risk_mask=True)
    if algorithm == "SafeSlack":
        return safe_admission_decide_factory(q, lambda_b, rho_D, "slack"), None
    if algorithm.startswith("SafeProb-"):
        return safe_admission_decide_factory(q, lambda_b, rho_D, "prob", float(algorithm.split("-", 1)[1])), None
    if algorithm.startswith("QueueCap-"):
        return safe_admission_decide_factory(q, lambda_b, rho_D, "queuecap", float(algorithm.split("-", 1)[1])), None
    if algorithm.startswith("SizeGate-"):
        return safe_admission_decide_factory(q, lambda_b, rho_D, "sizegate", float(algorithm.split("-", 1)[1])), None
    if algorithm.startswith("WorkCap-"):
        return safe_admission_decide_factory(q, lambda_b, rho_D, "workcap", float(algorithm.split("-", 1)[1])), None
    if algorithm == "RTD-adapted":
        return rtd_adapted_decide_factory(q, lambda_b, rho_D), None
    if algorithm == "TS-Bandit-adapted":
        return ts_bandit_decide_factory(q, lambda_b, rho_D, seed)
    # ---- legacy (v3) names, kept for reproducibility of earlier tables ----
    if algorithm == "FARO-NoCal":
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=beta, calibrate=False, enforce_tau=True)
    if algorithm == "FARO-NoTau":
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=beta, calibrate=True, enforce_tau=False)
    if algorithm == "FARO-MinDepth":
        return faro3_decide_factory(q, lambda_b, c_rev, rho_D, beta=beta, calibrate=False, enforce_tau=True,
                                    min_depth_only=True)
    if algorithm == "FARO-Expected":
        return faro_expected_decide_factory(q, lambda_b, c_rev, rho_D), None
    if algorithm == "FARO-v2":
        return faro_decide_factory(q, lambda_b, c_rev, rho_D), None
    if algorithm == "FARO-NoRisk":
        return faro_norisk_decide_factory(q, lambda_b, c_rev, rho_D), None
    if algorithm == "FARO-FixedZ":
        return faro_fixedz_decide_factory(q, lambda_b, c_rev, rho_D), None
    if algorithm == "Fang et al.-adapted":
        return fang_adapted_decide_factory(q, lambda_b, rho_D), None
    if algorithm == "SharpEdge-adapted":
        rep_state = sharpedge_new_reputation_state()
        decide = sharpedge_adapted_decide_factory(q, lambda_b, rho_D, rep_state)
        return decide, sharpedge_make_reputation_updater(rep_state)
    raise ValueError(f"Unknown algorithm {algorithm!r}")


# =============================================================================
# SECTION 8: ONLINE STREAMING AGGREGATOR — sufficient statistics, exact P95
#            via a memory-mapped float32 array; NEVER reload a per-task file.
# =============================================================================
def socr_curve_from_counts(ontime_by_prev: Dict[float, int], n: int, taus) -> Dict[float, float]:
    """SOCR(tau) = 100/N * #{admitted & on time & P_rev <= tau}. Because P_rev
    takes at most Z_MAX distinct values per q, the whole continuous curve is
    exactly recoverable from on-time counts keyed by P_rev value."""
    out = {}
    items = sorted(ontime_by_prev.items())
    for tau in taus:
        cnt = sum(c for p, c in items if p <= float(tau) + 1e-12)
        out[float(tau)] = (100.0 * cnt / n) if n else float("nan")
    return out


def socr_col(tau: float) -> str:
    return f"M15_SOCR_tau{tau:.2f}_pct" if tau >= 0.095 else f"M15_SOCR_tau{tau:.0e}_pct"


def v3_metrics_from_stats(n, n_adm, ontime_by_prev, sum_esu, n_safe_req_ontime, n_admitted_safe_req,
                          n_deadline_violation, sum_p_on_pred, n_p_on_pred,
                          class_n, class_admitted, class_ontime, class_safe_ontime) -> dict:
    """Study-proposed metrics (identical formula for every algorithm):
      M15 SOCR(tau)    = 100/N sum 1[A_i=1 & T_i<=D_i & P_rev,i <= tau]
      M16 SOCR-req     = same with each task's own required tau_i  (HEADLINE)
      M17 ESU          = 1/N sum A_i 1[T_i<=D_i] (1 - P_rev,i)
      M18 risk-level satisfaction = 100 * #{admitted & P_rev<=tau_i} / #admitted
      M19 mean predicted P_on (v3 algorithms only), M20 calibration gap
          = realized on-time rate among admitted - mean predicted P_on
      M21 per-class SOCR-req (%), M22 per-class admission (%)"""
    def safe_div(a, b):
        return (a / b) if b else float("nan")
    m = {}
    taus = list(SOCR_TAUS) + (list(STRINGENT_TAUS.values()) if RISK_PROFILE == "stringent" else [])
    curve = socr_curve_from_counts(ontime_by_prev, n, taus)
    for tau in taus:
        m[socr_col(tau)] = curve[float(tau)]
    m["M15_SOCR_curve_ontime_counts_by_Prev"] = {f"{p:.10g}": int(c) for p, c in sorted(ontime_by_prev.items())}
    m["M16_SOCR_req_pct"] = safe_div(100.0 * n_safe_req_ontime, n)
    m["M17_ESU"] = safe_div(sum_esu, n)
    m["M18_risk_level_satisfaction_pct"] = safe_div(100.0 * n_admitted_safe_req, n_adm)
    m["M19_mean_predicted_P_on_time"] = safe_div(sum_p_on_pred, n_p_on_pred)
    realized_ontime_rate = safe_div(n_adm - n_deadline_violation, n_adm)
    m["M20_calibration_gap"] = (realized_ontime_rate - m["M19_mean_predicted_P_on_time"]
                                if n_p_on_pred else float("nan"))
    cls_socr, cls_adm, cls_ontime = {}, {}, {}
    for code, name in enumerate(RISK_CLASS_NAMES):
        cn = class_n.get(code, 0)
        cls_socr[name] = safe_div(100.0 * class_safe_ontime.get(code, 0), cn)
        cls_adm[name] = safe_div(100.0 * class_admitted.get(code, 0), cn)
        cls_ontime[name] = safe_div(100.0 * class_ontime.get(code, 0), cn)
    m["M21_class_SOCR_req_pct"] = cls_socr
    m["M22_class_admission_pct"] = cls_adm
    m["M23_class_ontime_pct"] = cls_ontime
    for name in RISK_CLASS_NAMES:  # scalar copies for CI tables
        m[f"M21_SOCR_req_{name}_pct"] = cls_socr[name]
    return m


class OnlineAggregator:
    def __init__(self, expected_n: Optional[int] = None, memmap_path: Optional[str] = None,
                 n_segments: int = 1):
        # v4 statistics
        self.reject_counts = defaultdict(int)
        self.n_adm_safe_true = 0
        self.n_safe_true_ontime = 0
        self.sum_chi_prev = 0.0
        self.sum_T_over_D = 0.0
        self.cal_n = np.zeros(10); self.cal_pred = np.zeros(10); self.cal_obs = np.zeros(10)
        self.brier_sum = 0.0
        self.dg_n = defaultdict(int); self.dg_adm = defaultdict(int); self.dg_socr = defaultdict(int)
        S, B = max(1, n_segments), len(LAT_HIST_EDGES) - 1
        self.n_seg = S
        self.seg_n = np.zeros(S, np.int64); self.seg_adm = np.zeros(S, np.int64)
        self.seg_socr = np.zeros(S, np.int64); self.seg_ontime = np.zeros(S, np.int64)
        self.seg_lat_sum = np.zeros(S); self.seg_safe_lat_sum = np.zeros(S)
        self.seg_lat_hist = np.zeros((S, B), np.int32); self.seg_safe_lat_hist = np.zeros((S, B), np.int32)
        self.n = 0
        self.n_admitted = 0
        self.n_deadline_violation = 0
        self.sum_decision_time_ms = 0.0
        self.sum_P_rev = 0.0
        self.sum_expected_reversal_exposure = 0.0
        self.sum_selected_z = 0.0
        self.sum_T_comm = 0.0
        self.sum_T_queue = 0.0
        self.sum_T_compute = 0.0
        self.sum_T_finality = 0.0
        self.z_counts: dict = defaultdict(int)
        self.tier_counts: dict = defaultdict(int)
        self.n_pred_feasible = 0
        self.n_pred_feasible_realized_violation = 0
        # v3 study-proposed metrics (streaming sufficient statistics)
        self.ontime_by_prev: dict = defaultdict(int)   # P_rev value -> on-time count (SOCR curve)
        self.sum_esu = 0.0                              # sum over on-time tasks of (1 - P_rev)
        self.n_safe_req_ontime = 0                      # on-time AND P_rev <= tau_i
        self.n_admitted_safe_req = 0                    # admitted AND P_rev <= tau_i
        self.sum_p_on_pred = 0.0                        # sum of predicted P_on over admitted (v3 algos)
        self.n_p_on_pred = 0
        self.class_n = defaultdict(int)
        self.class_admitted = defaultdict(int)
        self.class_ontime = defaultdict(int)
        self.class_safe_ontime = defaultdict(int)
        # v5 mechanism statistics
        self.class_viol = defaultdict(int); self.class_brier = defaultdict(float); self.class_brier_n = defaultdict(int)
        self.q_abs_err = 0.0; self.q_signed_err = 0.0; self.q_real_sum = 0.0; self.q_n = 0
        self.serv_total = 0.0; self.serv_wasted = 0.0

        self._own_memmap_file = memmap_path is None
        if expected_n and expected_n > 0:
            if memmap_path is None:
                fd, memmap_path = tempfile.mkstemp(prefix="faro_latency_", suffix=".f32")
                os.close(fd)
            self._latency_path = memmap_path
            self._latency_mm = np.memmap(memmap_path, dtype=np.float32, mode="w+", shape=(expected_n,))
        else:
            self._latency_path = None
            self._latency_mm = None
        self._latency_count = 0

    def add(self, rec: dict) -> None:
        self.n += 1
        self.sum_decision_time_ms += rec.get("decision_time_ms") or 0.0
        rc = rec.get("risk_class")
        if rc is not None:
            self.class_n[int(rc)] += 1
        seg = rec.get("segment")
        seg = int(seg) if seg is not None else 0
        seg = min(max(seg, 0), self.n_seg - 1)
        dg = rec.get("dgroup")
        self.seg_n[seg] += 1
        if dg is not None:
            self.dg_n[int(dg)] += 1
        if not rec.get("admitted"):
            self.reject_counts[rec.get("reject_reason") or "deadline_infeasible"] += 1
            return
        self.seg_adm[seg] += 1
        if dg is not None:
            self.dg_adm[int(dg)] += 1
        self.n_admitted += 1
        self.n_pred_feasible += 1
        z = rec["selected_z"]
        tier_code = rec["selected_tier_code"]
        self.sum_P_rev += rec["P_rev"]
        self.sum_expected_reversal_exposure += rec["expected_reversal_exposure"]
        self.sum_selected_z += z
        self.z_counts[z] += 1
        self.tier_counts[tier_code] += 1
        self.sum_T_comm += rec["predicted_T_comm"]
        self.sum_T_queue += rec["predicted_T_queue"]
        self.sum_T_compute += rec["predicted_T_compute"]
        self.sum_T_finality += rec["predicted_T_finality"]

        violated = bool(rec["realized_deadline_violation"])
        if violated:
            self.n_deadline_violation += 1
            self.n_pred_feasible_realized_violation += 1
            if rc is not None:
                self.class_viol[int(rc)] += 1
        # v5: queue-prediction error and service time spent on tasks that miss their deadline
        rq, pq = rec.get("realized_T_queue"), rec.get("predicted_T_queue")
        if rq is not None and pq is not None:
            self.q_abs_err += abs(float(pq) - float(rq)); self.q_signed_err += float(pq) - float(rq)
            self.q_real_sum += float(rq); self.q_n += 1
        sv = rec.get("realized_T_compute")
        if sv is not None:
            self.serv_total += float(sv)
            if violated:
                self.serv_wasted += float(sv)

        # --- v3 metrics ---
        p_rev_i = float(rec["P_rev"])
        tau_i = rec.get("tau_req")
        safe_req = (tau_i is not None) and (p_rev_i <= float(tau_i) + 1e-12)
        if safe_req:
            self.n_admitted_safe_req += 1
        if rc is not None:
            self.class_admitted[int(rc)] += 1
        if not violated:
            self.ontime_by_prev[round(p_rev_i, 12)] += 1
            self.sum_esu += (1.0 - p_rev_i)
            if rc is not None:
                self.class_ontime[int(rc)] += 1
            if safe_req:
                self.n_safe_req_ontime += 1
                if rc is not None:
                    self.class_safe_ontime[int(rc)] += 1
        p_on = rec.get("P_on_time_pred")
        if p_on is not None and not (isinstance(p_on, float) and np.isnan(p_on)):
            self.sum_p_on_pred += float(p_on)
            self.n_p_on_pred += 1
            b = min(int(float(p_on) * 10), 9)
            obs = 0.0 if violated else 1.0
            self.cal_n[b] += 1; self.cal_pred[b] += float(p_on); self.cal_obs[b] += obs
            self.brier_sum += (float(p_on) - obs) ** 2
            if rc is not None:
                self.class_brier[int(rc)] += (float(p_on) - obs) ** 2; self.class_brier_n[int(rc)] += 1
        # --- v4 statistics ---
        chi_i = rec.get("chi")
        if chi_i is not None:
            self.sum_chi_prev += float(chi_i) * p_rev_i
        d_i = rec.get("D_task")
        lat = rec.get("realized_T_total")
        if d_i and lat is not None:
            self.sum_T_over_D += float(lat) / float(d_i)
        st = rec.get("safe_req_true")
        st = safe_req if st is None else bool(st)
        if st:
            self.n_adm_safe_true += 1
            if not violated:
                self.n_safe_true_ontime += 1
        if lat is not None:
            hb = int(np.clip(np.searchsorted(LAT_HIST_EDGES, float(lat), side="right") - 1, 0, len(LAT_HIST_EDGES) - 2))
            self.seg_lat_sum[seg] += float(lat); self.seg_lat_hist[seg, hb] += 1
            if not violated:
                self.seg_ontime[seg] += 1
                if safe_req:
                    self.seg_socr[seg] += 1
                    self.seg_safe_lat_sum[seg] += float(lat); self.seg_safe_lat_hist[seg, hb] += 1
                    if dg is not None:
                        self.dg_socr[int(dg)] += 1

        if self._latency_mm is not None and self._latency_count < len(self._latency_mm):
            self._latency_mm[self._latency_count] = rec["realized_T_total"]
            self._latency_count += 1

    def _p95(self) -> float:
        if self._latency_mm is None or self._latency_count == 0:
            return float("nan")
        return float(np.percentile(self._latency_mm[:self._latency_count], 95))

    def _mean_latency(self) -> float:
        if self._latency_mm is None or self._latency_count == 0:
            return float("nan")
        return float(np.mean(self._latency_mm[:self._latency_count]))

    def finalize(self, segments_path: Optional[str] = None) -> dict:
        n, n_adm = self.n, self.n_admitted

        def safe_div(a, b):
            return (a / b) if b else float("nan")

        m = {}
        m["n_tasks"] = n
        m["n_admitted"] = n_adm
        m["M13_admission_rate_pct"] = safe_div(100.0 * n_adm, n)
        m["M14_infeasible_rate_pct"] = safe_div(100.0 * (n - n_adm), n)
        m["M10_mean_decision_time_ms"] = safe_div(self.sum_decision_time_ms, n)
        m["M1_mean_e2e_latency_s"] = self._mean_latency()
        m["M2_p95_e2e_latency_s"] = self._p95()
        m["M3_deadline_violation_rate_pct"] = safe_div(100.0 * self.n_deadline_violation, n_adm)
        m["M4_mean_reversal_probability"] = safe_div(self.sum_P_rev, n_adm)
        m["M5_mean_expected_reversal_exposure"] = safe_div(self.sum_expected_reversal_exposure, n_adm)
        m["M6_mean_selected_z"] = safe_div(self.sum_selected_z, n_adm)
        m["M7_z_distribution"] = dict(sorted(self.z_counts.items()))

        inv_tier = {v: k for k, v in TIER_CODE.items()}
        placement = {t: 0.0 for t in TIER_NAMES}
        for code, cnt in self.tier_counts.items():
            placement[inv_tier[code]] = safe_div(100.0 * cnt, n_adm)
        m["M8_placement_pct"] = placement

        n_completed_ok = n_adm - self.n_deadline_violation
        m["M9_realized_completion_rate_pct"] = safe_div(100.0 * n_completed_ok, n)
        m["M9_denominator_definition"] = "admitted_and_not_deadline_violated / all_generated_tasks"

        m["M11_realized_violation_rate_pct"] = safe_div(100.0 * self.n_deadline_violation, n_adm)

        m["M12_n_pred_feasible"] = self.n_pred_feasible
        m["M12_n_pred_feasible_realized_violation"] = self.n_pred_feasible_realized_violation
        m["M12_predicted_to_realized_violation_pct"] = safe_div(
            100.0 * self.n_pred_feasible_realized_violation, self.n_pred_feasible)

        m["mean_T_comm_s"] = safe_div(self.sum_T_comm, n_adm)
        m["mean_T_queue_s"] = safe_div(self.sum_T_queue, n_adm)
        m["mean_T_compute_s"] = safe_div(self.sum_T_compute, n_adm)
        m["mean_T_finality_s"] = safe_div(self.sum_T_finality, n_adm)
        m.update(v3_metrics_from_stats(
            n=n, n_adm=n_adm, ontime_by_prev=dict(self.ontime_by_prev), sum_esu=self.sum_esu,
            n_safe_req_ontime=self.n_safe_req_ontime, n_admitted_safe_req=self.n_admitted_safe_req,
            n_deadline_violation=self.n_deadline_violation,
            sum_p_on_pred=self.sum_p_on_pred, n_p_on_pred=self.n_p_on_pred,
            class_n=dict(self.class_n), class_admitted=dict(self.class_admitted),
            class_ontime=dict(self.class_ontime), class_safe_ontime=dict(self.class_safe_ontime)))
        # --- v4 metrics ---
        reasons = ["risk_infeasible", "deadline_infeasible", "admission_test"]
        m["M24_reject_breakdown_pct"] = {r: safe_div(100.0 * self.reject_counts.get(r, 0), n) for r in reasons}
        m["M24_reject_pct"] = safe_div(100.0 * sum(self.reject_counts.values()), n)
        for r in reasons:
            m[f"M24_reject_{r}_pct"] = m["M24_reject_breakdown_pct"][r]
        m["M18b_unsafe_admissions_over_admitted_pct"] = safe_div(100.0 * (n_adm - self.n_admitted_safe_req), n_adm)
        m["M18c_unsafe_admissions_over_all_pct"] = safe_div(100.0 * (n_adm - self.n_admitted_safe_req), n)
        m["M5b_weighted_exposure_per_admitted"] = safe_div(self.sum_chi_prev, n_adm)
        m["M5c_weighted_exposure_per_arrival"] = safe_div(self.sum_chi_prev, n)
        m["M25_SOCR_req_qtrue_pct"] = safe_div(100.0 * self.n_safe_true_ontime, n)
        m["M25_risk_sat_qtrue_pct"] = safe_div(100.0 * self.n_adm_safe_true, n_adm)
        m["M28_mean_T_over_D"] = safe_div(self.sum_T_over_D, n_adm)
        # v5 mechanism metrics
        for k, rcd in enumerate(RISK_CLASSES):
            nm = rcd["name"]
            m[f"M31_adm_{nm}_pct"] = safe_div(100.0 * self.class_admitted.get(k, 0), self.class_n.get(k, 0))
            m[f"M31_viol_{nm}_pct"] = safe_div(100.0 * self.class_viol.get(k, 0), self.class_admitted.get(k, 0))
            m[f"M31_brier_{nm}"] = (safe_div(self.class_brier.get(k, 0.0), self.class_brier_n.get(k, 0))
                                   if self.class_brier_n.get(k, 0) else float("nan"))
        m["M30_queue_mae_s"] = safe_div(self.q_abs_err, self.q_n)
        m["M30_queue_bias_s"] = safe_div(self.q_signed_err, self.q_n)
        m["M30_mean_realized_queue_s"] = safe_div(self.q_real_sum, self.q_n)
        m["M29_wasted_service_pct"] = safe_div(100.0 * self.serv_wasted, self.serv_total)
        m["M29_safe_ontime_per_kserver_s"] = safe_div(1000.0 * self.n_safe_req_ontime, self.serv_total)
        cn = self.cal_n.sum()
        m["M26_brier"] = (self.brier_sum / cn) if cn else float("nan")
        m["M26_ece"] = (float(np.sum(np.abs(self.cal_pred - self.cal_obs))) / cn) if cn else float("nan")
        m["M26_calibration_bins"] = {int(i): [int(self.cal_n[i]), float(self.cal_pred[i]), float(self.cal_obs[i])]
                                     for i in range(10) if self.cal_n[i] > 0}
        m["M27_dgroup_SOCR_req_pct"] = {int(g): safe_div(100.0 * self.dg_socr.get(g, 0), self.dg_n[g]) for g in sorted(self.dg_n)}
        m["M27_dgroup_admission_pct"] = {int(g): safe_div(100.0 * self.dg_adm.get(g, 0), self.dg_n[g]) for g in sorted(self.dg_n)}
        if segments_path:
            os.makedirs(os.path.dirname(segments_path) or ".", exist_ok=True)
            np.savez_compressed(segments_path, n=self.seg_n, adm=self.seg_adm, socr=self.seg_socr,
                                ontime=self.seg_ontime, lat_sum=self.seg_lat_sum, safe_lat_sum=self.seg_safe_lat_sum,
                                lat_hist=self.seg_lat_hist, safe_lat_hist=self.seg_safe_lat_hist,
                                edges=LAT_HIST_EDGES)
            m["segments_file"] = segments_path
        return m

    def close(self) -> None:
        if self._latency_mm is not None:
            self._latency_mm.flush()
            del self._latency_mm
            self._latency_mm = None
        if self._own_memmap_file and self._latency_path and os.path.exists(self._latency_path):
            os.remove(self._latency_path)


# =============================================================================
# SECTION 9: DISCRETE-EVENT SIMULATION — real Edge/Fog/Cloud SimPy Resources,
#            common random numbers, true online metrics aggregation
# =============================================================================
TIER_CODE_NONE = -1
OUTPUT_COLUMNS = [
    "task_id", "arrival_time", "network_payload_bytes", "algorithm", "workload", "seed",
    "compute_demand_cycles", "D_task", "C_rev", "q", "lambda_b",
    "selected_tier_code", "selected_z", "admitted", "infeasible",
    "predicted_T_comm", "predicted_T_queue", "predicted_T_compute", "predicted_T_finality",
    "predicted_T_total", "realized_T_finality", "realized_T_total",
    "predicted_feasible", "realized_deadline_violation",
    "P_rev", "expected_reversal_exposure", "decision_time_ms",
    # v3 columns
    "risk_class", "tau_req", "chi", "z_req", "P_on_time_pred", "realized_T_queue",
    "safe_req", "safe_ontime_req",
    # v4 columns
    "reject_reason", "P_rev_true", "safe_req_true", "segment", "dgroup",
    # v5 columns
    "realized_T_compute",
]


def make_sim_state(env: simpy.Environment, mean_payload_bytes: float, mean_compute_cycles: float) -> dict:
    sim_state = {}
    for tname in TIER_NAMES:
        sim_state[tname] = dict(
            resource=simpy.Resource(env, capacity=max(1, RESOURCE_TIERS[tname]["num_servers"])),
            mean_service_time=t_compute(tname, mean_compute_cycles),
            inflight=0,   # v3 orchestrator ledger: committed, compute not yet finished
            work_cycles=0.0,  # v6: committed nominal demand (cycles) of the inflight tasks
        )
    return sim_state


def _task_jitter_rng(seed: int, task_id: int) -> np.random.Generator:
    """CRN stream 2: execution-time jitter keyed by (seed, task_id) only."""
    return np.random.default_rng(np.random.SeedSequence([int(seed), int(task_id), 2]))


def task_demand_cycles(workload_cycles: float, seed: int, task_id: int) -> float:
    """v5: per-task computational demand. Homogeneous (= workload_cycles) when DEMAND_CV == 0."""
    cv = float(DEMAND_CV or 0.0)
    if cv <= 0.0:
        return workload_cycles
    s = float(np.sqrt(np.log1p(cv * cv)))
    z = float(np.random.default_rng(np.random.SeedSequence([int(seed), int(task_id), 7_003])).standard_normal())
    return float(workload_cycles * np.exp(s * z - 0.5 * s * s))


def realized_compute_delay(tier: str, compute_demand_cycles: float, seed: int, task_id: int) -> float:
    base = t_compute(tier, compute_demand_cycles)
    s = COMPUTE_JITTER_SIGMA
    if not s or s <= 0.0:
        return base
    z = float(_task_jitter_rng(seed, task_id).standard_normal())
    return base * float(np.exp(s * z - 0.5 * s * s))


def _task_block_rng(seed: int, task_id: int) -> np.random.Generator:
    """CRN construction (Section 20): a fresh SeedSequence keyed by
    (seed, task_id) ONLY — not by algorithm, workload, or arrival/service
    order — so the identical block-interval draw sequence is available to
    whichever algorithm evaluates this task under this seed."""
    ss = np.random.SeedSequence([int(seed), int(task_id)])
    return np.random.default_rng(ss)


class SharedBlockChain:
    """One Poisson block sequence per seed (CRN stream 5_003), shared by every task of a
    run and identical for every policy under the seed. A transaction submitted at time t
    is included in the first block strictly after t that still has capacity; it is final
    once z blocks exist counting the inclusion block. By memorylessness the marginal
    finality time of one transaction is exactly Erlang(z, lambda_b), so the decision
    model is unchanged; what changes is that finality times of concurrent tasks are
    correlated and capacity can delay inclusion."""

    def __init__(self, seed: int, lambda_b: float, capacity: int = 0, chunk: int = 200_000):
        self.rng = np.random.default_rng(np.random.SeedSequence([int(seed), 5_003]))
        self.lambda_b = float(lambda_b)
        self.capacity = int(capacity or 0)
        self.chunk = chunk
        self.times = np.cumsum(self.rng.exponential(1.0 / self.lambda_b, chunk))
        self.counts = np.zeros(chunk, dtype=np.int32)

    def _extend(self):
        more = self.times[-1] + np.cumsum(self.rng.exponential(1.0 / self.lambda_b, self.chunk))
        self.times = np.concatenate([self.times, more])
        self.counts = np.concatenate([self.counts, np.zeros(self.chunk, dtype=np.int32)])

    def finality(self, t_submit: float, z: int) -> float:
        while self.times[-1] <= t_submit:
            self._extend()
        i = int(np.searchsorted(self.times, t_submit, side="right"))
        if self.capacity > 0:
            while True:
                while i >= len(self.times):
                    self._extend()
                if self.counts[i] < self.capacity:
                    break
                i += 1
            self.counts[i] += 1
        j = i + int(z) - 1
        while j >= len(self.times):
            self._extend()
        return float(self.times[j] - t_submit)


class _ChunkedWriter:
    """Streams full-schema result dicts to a .csv.gz in fixed-size chunks,
    purely for audit — NEVER read back to compute metrics."""

    def __init__(self, output_path: Optional[str], flush_every: int = 50_000):
        self.output_path = output_path
        self.flush_every = flush_every
        self._buffer = []
        self._wrote_header = False

    def add(self, row: dict) -> None:
        if self.output_path is None:
            return
        self._buffer.append(row)
        if len(self._buffer) >= self.flush_every:
            self._flush()

    def _flush(self) -> None:
        if not self._buffer:
            return
        df = pd.DataFrame(self._buffer, columns=OUTPUT_COLUMNS)
        os.makedirs(os.path.dirname(self.output_path) or ".", exist_ok=True)
        mode = "a" if self._wrote_header else "w"
        df.to_csv(self.output_path, mode=mode, header=not self._wrote_header, index=False, compression="gzip")
        self._wrote_header = True
        self._buffer = []

    def finalize(self) -> None:
        self._flush()


def run_experiment(trace: pd.DataFrame, workload_cycles: float, decide_fn: Callable,
                    lambda_b: float, seed: int, reporting_c_rev: float, q: float,
                    workload_name: str = "", algorithm_name: str = "",
                    post_update_fn: Optional[Callable] = None,
                    output_path: Optional[str] = None, flush_every: int = 50_000,
                    keep_dataframe: bool = False, rho_D: float = None,
                    segments_path: Optional[str] = None):
    """v3: every task carries an algorithm-independent profile (D_i, tau_i,
    chi_i, z_req) built here from the seeded risk-class stream; decide_fn
    receives it as a 4th argument. post_update_fn(tier, success, info) is
    called after every admitted task completes (SharpEdge reputation, FARO
    residual calibrator)."""
    rho_D = RHO_D if rho_D is None else rho_D
    env = simpy.Environment()
    mean_payload = float(trace["network_payload_bytes"].mean()) if len(trace) else FALLBACK_PAYLOAD_BYTES
    sim_state = make_sim_state(env, mean_payload, workload_cycles)
    writer = _ChunkedWriter(output_path, flush_every)
    aggregator = OnlineAggregator(expected_n=len(trace), n_segments=N_SEGMENTS)
    in_memory_rows = [] if keep_dataframe else None
    risk_codes = assign_risk_classes(len(trace), seed)
    budgets = assign_deadline_budgets(len(trace), seed)
    b_lo, b_hi = INDEP_BUDGET_RANGE
    seg_size = max(1, int(np.ceil(len(trace) / max(1, N_SEGMENTS))))
    q_true = q if Q_TRUE is None else float(Q_TRUE)
    chain = SharedBlockChain(seed, lambda_b, BLOCK_CAPACITY) if CHAIN_MODE == "shared" else None
    # trace order -> position (task_id is not necessarily 0..n-1 for sub-traces)
    pos_of_task = {int(t): i for i, t in enumerate(trace["task_id"].tolist())}

    def emit(row: dict) -> None:
        writer.add(row)
        aggregator.add(row)
        if in_memory_rows is not None:
            in_memory_rows.append(row)

    def task_process(task_id, arrival_time, payload_bytes, already_arrived=False):
        # SURGICAL STREAMING FIX: when spawned by arrival_generator() below,
        # the simulation clock has ALREADY been advanced to exactly
        # arrival_time (via the generator's own env.timeout(interarrival)),
        # so waiting again here would double-count the arrival delay. The
        # already_arrived flag is the minimal, mechanical guard against that;
        # everything else in this function is byte-for-byte unchanged.
        if not already_arrived:
            yield env.timeout(max(0.0, arrival_time - env.now))
        pos = pos_of_task[int(task_id)]
        rc = int(risk_codes[pos])
        b_i = float(budgets[pos])
        c_i = task_demand_cycles(workload_cycles, seed, task_id)
        ctx = make_task_ctx(payload_bytes, c_i, rc, rho_D, lambda_b, q, fin_budget=b_i,
                            nominal_cycles=workload_cycles)
        seg = min(pos // seg_size, N_SEGMENTS - 1)
        # deadline group: tercile of the finality budget (independent mode) or the risk class (risk mode)
        dgroup = (int(min(2, (b_i - b_lo) / (b_hi - b_lo) * 3)) if DEADLINE_MODE in ("independent", "sizefree") else rc)
        t0 = time.perf_counter()
        decision = decide_fn(payload_bytes, c_i, sim_state, ctx)
        decision_time_ms = (time.perf_counter() - t0) * 1000.0
        if FORCE_DECISION is not None and int(task_id) == int(FORCE_DECISION["task_id"]):
            # v7 counterfactual study: record the state, then force admission (with the toll-free
            # decision) or rejection of exactly this task; every other task follows decide_fn.
            alt = FORCE_DECISION["alt_decide"](payload_bytes, c_i, sim_state, ctx)
            info = dict(task_id=int(task_id), policy_admits=bool(decision.admitted), alt_admits=bool(alt.admitted),
                        D=float(ctx.D_task), c=float(c_i), risk_class=rc)
            if alt.admitted:
                t_ = alt.tier; st_ = sim_state[t_]
                s_bar = st_.get("mean_service_time", 0.0) or t_compute(t_, c_i)
                invd = FORCE_DECISION.get("invd_ref", {}).get("m", 1.0 / ctx.D_task) or 1.0 / ctx.D_task
                info.update(tier=t_, T_queue=float(alt.T_queue), T_compute=float(alt.T_compute), s_bar=float(s_bar),
                            inflight=int(st_["inflight"]), servers=int(RESOURCE_TIERS[t_]["num_servers"]),
                            toll_unit=float((alt.T_compute / s_bar) * alt.T_queue * invd), P_on=alt.P_on_time)
            FORCE_DECISION["log"].append(info)
            if FORCE_DECISION["action"] == "admit":
                if alt.admitted:
                    decision = alt
            else:
                decision = Decision(tier=None, z=None, D_task=ctx.D_task, feasible=False, admitted=False,
                                    infeasible_task=True, reject_reason="admission_test")

        if not decision.admitted:
            emit(dict(
                task_id=task_id, arrival_time=arrival_time, network_payload_bytes=payload_bytes,
                algorithm=algorithm_name, workload=workload_name, seed=seed,
                compute_demand_cycles=c_i, D_task=decision.D_task,
                C_rev=reporting_c_rev, q=q, lambda_b=lambda_b,
                selected_tier_code=TIER_CODE_NONE, selected_z=None, admitted=False, infeasible=True,
                predicted_T_comm=None, predicted_T_queue=None, predicted_T_compute=None,
                predicted_T_finality=None, predicted_T_total=None,
                realized_T_finality=None, realized_T_total=None,
                predicted_feasible=False, realized_deadline_violation=None,
                P_rev=None, expected_reversal_exposure=None, decision_time_ms=decision_time_ms,
                risk_class=rc, tau_req=ctx.tau, chi=ctx.chi, z_req=ctx.z_req,
                P_on_time_pred=decision.P_on_time, realized_T_queue=None,
                safe_req=None, safe_ontime_req=False,
                reject_reason=(decision.reject_reason or "deadline_infeasible"),
                P_rev_true=None, safe_req_true=None, segment=seg, dgroup=dgroup,
            ))
            return

        tier, z = decision.tier, decision.z
        comm_delay = t_comm(tier, payload_bytes)
        compute_delay = realized_compute_delay(tier, c_i, seed, task_id)

        sim_state[tier]["inflight"] += 1
        sim_state[tier]["work_cycles"] += c_i
        yield env.timeout(comm_delay)
        with sim_state[tier]["resource"].request() as req:
            q_enter = env.now
            yield req
            realized_queue_wait = env.now - q_enter
            yield env.timeout(compute_delay)
        sim_state[tier]["inflight"] -= 1
        sim_state[tier]["work_cycles"] -= c_i
        if sim_state[tier]["inflight"] == 0:
            sim_state[tier]["work_cycles"] = 0.0   # clear float drift

        if chain is not None:
            realized_finality = chain.finality(env.now, int(z))
        else:
            block_rng = _task_block_rng(seed, task_id)
            realized_finality = float(block_rng.exponential(scale=1.0 / lambda_b, size=int(z)).sum())
        yield env.timeout(realized_finality)

        realized_total = comm_delay + realized_queue_wait + compute_delay + realized_finality
        realized_deadline_violation = realized_total > decision.D_task
        safe_req = decision.P_rev <= ctx.tau + 1e-12
        p_rev_true = p_rev(int(z), q_true) if q_true != q else decision.P_rev
        if post_update_fn is not None:
            info = dict(realized_T_queue=realized_queue_wait, predicted_T_queue=decision.T_queue,
                        selected_z=z, risk_class=rc, safe_req=bool(safe_req))
            dbe = decision.diagnostic_best_effort
            if isinstance(dbe, dict) and "ctx" in dbe:
                info["ts_ctx"], info["ts_arm"] = dbe["ctx"], dbe["arm"]
            post_update_fn(tier, not realized_deadline_violation, info)

        emit(dict(
            task_id=task_id, arrival_time=arrival_time, network_payload_bytes=payload_bytes,
            algorithm=algorithm_name, workload=workload_name, seed=seed,
            compute_demand_cycles=c_i, D_task=decision.D_task,
            C_rev=reporting_c_rev, q=q, lambda_b=lambda_b,
            selected_tier_code=TIER_CODE[tier], selected_z=z, admitted=True, infeasible=False,
            predicted_T_comm=decision.T_comm, predicted_T_queue=decision.T_queue,
            predicted_T_compute=decision.T_compute, predicted_T_finality=decision.T_finality_wait,
            predicted_T_total=decision.T_total,
            realized_T_finality=realized_finality, realized_T_total=realized_total,
            predicted_feasible=True, realized_deadline_violation=realized_deadline_violation,
            P_rev=decision.P_rev, expected_reversal_exposure=reporting_c_rev * decision.P_rev,
            decision_time_ms=decision_time_ms,
            risk_class=rc, tau_req=ctx.tau, chi=ctx.chi, z_req=ctx.z_req,
            P_on_time_pred=decision.P_on_time, realized_T_queue=realized_queue_wait,
            safe_req=safe_req, safe_ontime_req=bool(safe_req and not realized_deadline_violation),
            reject_reason=None, P_rev_true=p_rev_true, safe_req_true=bool(p_rev_true <= ctx.tau + 1e-12),
            segment=seg, dgroup=dgroup, realized_T_compute=compute_delay,
        ))

    # SURGICAL STREAMING FIX (replaces eager pre-creation of one SimPy
    # process per task, ~2.1M at full dataset scale, with a streaming
    # arrival generator that creates each task process only when its
    # arrival time is reached). The trace is already time-sorted
    # (audit_and_build_trace sorts by timestamp), so a single pass with
    # running inter-arrival deltas reproduces the identical arrival
    # schedule. Tasks sharing an identical arrival_time (Edge-IIoTset has
    # duplicate timestamps) get interarrival=0 -> no timeout is yielded for
    # them -> they are created at the same simulation time, in their
    # original deterministic trace order, exactly as the eager version did.
    def arrival_generator():
        previous_arrival = 0.0
        for row in trace.itertuples(index=False):
            arrival = float(row.arrival_time)
            interarrival = max(0.0, arrival - previous_arrival)
            if interarrival > 0:
                yield env.timeout(interarrival)
            env.process(task_process(int(row.task_id), arrival, float(row.network_payload_bytes),
                                      already_arrived=True))
            previous_arrival = arrival

    env.process(arrival_generator())
    env.run()

    writer.finalize()
    metrics = aggregator.finalize(segments_path=segments_path)
    aggregator.close()

    df = None
    if in_memory_rows is not None:
        df = pd.DataFrame(in_memory_rows, columns=OUTPUT_COLUMNS).sort_values("task_id").reset_index(drop=True)
    return metrics, df


def decode_tier_column(series: pd.Series) -> pd.Series:
    inv = {v: k for k, v in TIER_CODE.items()}
    return series.map(lambda c: inv.get(c, None) if c is not None and c != TIER_CODE_NONE else None)


# =============================================================================
# SECTION 10: METRICS — M1-M14, DataFrame-based path (tests/validation/small runs)
# =============================================================================
def metrics_from_aggregate(agg_dict: dict) -> dict:
    return dict(agg_dict)


def compute_metrics(df: pd.DataFrame) -> dict:
    n = len(df)
    adm = df[df["admitted"] == True]  # noqa: E712
    n_adm = len(adm)

    def _safe_mean(s):
        return float(s.mean()) if len(s) else float("nan")

    def _safe_p95(s):
        return float(np.percentile(s, 95)) if len(s) else float("nan")

    m = {}
    m["n_tasks"] = n
    m["n_admitted"] = n_adm
    m["M13_admission_rate_pct"] = 100.0 * n_adm / n if n else float("nan")
    m["M14_infeasible_rate_pct"] = 100.0 * (n - n_adm) / n if n else float("nan")
    m["M10_mean_decision_time_ms"] = _safe_mean(df["decision_time_ms"])
    m["M1_mean_e2e_latency_s"] = _safe_mean(adm["realized_T_total"])
    m["M2_p95_e2e_latency_s"] = _safe_p95(adm["realized_T_total"])

    violated = adm["realized_deadline_violation"].astype(bool)
    n_violated = int(violated.sum()) if n_adm else 0
    m["M3_deadline_violation_rate_pct"] = 100.0 * n_violated / n_adm if n_adm else float("nan")
    m["M4_mean_reversal_probability"] = _safe_mean(adm["P_rev"])
    m["M5_mean_expected_reversal_exposure"] = _safe_mean(adm["expected_reversal_exposure"])
    m["M6_mean_selected_z"] = _safe_mean(adm["selected_z"])
    m["M7_z_distribution"] = (adm["selected_z"].value_counts().sort_index().to_dict() if n_adm else {})
    if n_adm:
        tier_names = decode_tier_column(adm["selected_tier_code"])
        placement = tier_names.value_counts(normalize=True) * 100.0
        m["M8_placement_pct"] = {t: float(placement.get(t, 0.0)) for t in ["Edge", "Fog", "Cloud"]}
    else:
        m["M8_placement_pct"] = {t: 0.0 for t in ["Edge", "Fog", "Cloud"]}

    n_completed_ok = n_adm - n_violated
    m["M9_realized_completion_rate_pct"] = 100.0 * n_completed_ok / n if n else float("nan")
    m["M9_denominator_definition"] = "admitted_and_not_deadline_violated / all_generated_tasks"
    m["M11_realized_violation_rate_pct"] = 100.0 * n_violated / n_adm if n_adm else float("nan")

    pred_feasible = adm["predicted_feasible"].astype(bool) if n_adm else pd.Series(dtype=bool)
    n_pred_feasible = int(pred_feasible.sum())
    n_pred_feasible_violated = int((pred_feasible & violated).sum()) if n_adm else 0
    m["M12_n_pred_feasible"] = n_pred_feasible
    m["M12_n_pred_feasible_realized_violation"] = n_pred_feasible_violated
    m["M12_predicted_to_realized_violation_pct"] = (
        100.0 * n_pred_feasible_violated / n_pred_feasible if n_pred_feasible else float("nan"))

    m["mean_T_comm_s"] = _safe_mean(adm["predicted_T_comm"])
    m["mean_T_queue_s"] = _safe_mean(adm["predicted_T_queue"])
    m["mean_T_compute_s"] = _safe_mean(adm["predicted_T_compute"])
    m["mean_T_finality_s"] = _safe_mean(adm["predicted_T_finality"])

    # --- v3 metrics, direct (non-streaming) computation from per-task rows ---
    ontime = adm[~violated] if n_adm else adm
    ontime_by_prev = defaultdict(int)
    for p in ontime["P_rev"].astype(float):
        ontime_by_prev[round(p, 12)] += 1
    has_tau = "tau_req" in df.columns
    if has_tau and n_adm:
        safe_req = adm["P_rev"].astype(float) <= adm["tau_req"].astype(float) + 1e-12
        n_adm_safe = int(safe_req.sum())
        n_safe_ontime = int((safe_req & ~violated).sum())
    else:
        n_adm_safe, n_safe_ontime = 0, 0
    if "P_on_time_pred" in df.columns and n_adm:
        pon = pd.to_numeric(adm["P_on_time_pred"], errors="coerce").dropna()
        sum_pon, n_pon = float(pon.sum()), int(len(pon))
    else:
        sum_pon, n_pon = 0.0, 0
    class_n, class_adm, class_ontime, class_safe = {}, {}, {}, {}
    if "risk_class" in df.columns:
        rc_all = pd.to_numeric(df["risk_class"], errors="coerce")
        for code in range(len(RISK_CLASSES)):
            mask_all = rc_all == code
            class_n[code] = int(mask_all.sum())
            sub = adm[pd.to_numeric(adm["risk_class"], errors="coerce") == code] if n_adm else adm
            class_adm[code] = int(len(sub))
            if len(sub):
                v = sub["realized_deadline_violation"].astype(bool)
                s = sub["P_rev"].astype(float) <= sub["tau_req"].astype(float) + 1e-12
                class_ontime[code] = int((~v).sum())
                class_safe[code] = int((s & ~v).sum())
            else:
                class_ontime[code] = 0
                class_safe[code] = 0
    m.update(v3_metrics_from_stats(
        n=n, n_adm=n_adm, ontime_by_prev=dict(ontime_by_prev),
        sum_esu=float((1.0 - ontime["P_rev"].astype(float)).sum()) if len(ontime) else 0.0,
        n_safe_req_ontime=n_safe_ontime, n_admitted_safe_req=n_adm_safe,
        n_deadline_violation=n_violated, sum_p_on_pred=sum_pon, n_p_on_pred=n_pon,
        class_n=class_n, class_admitted=class_adm, class_ontime=class_ontime, class_safe_ontime=class_safe))
    return m


def metrics_row(algorithm: str, workload: str, seed: int, metrics: dict) -> dict:
    row = dict(algorithm=algorithm, workload=workload, seed=seed)
    row.update(metrics)
    return row


SCALAR_METRIC_COLS = [
    "M1_mean_e2e_latency_s", "M2_p95_e2e_latency_s", "M3_deadline_violation_rate_pct",
    "M4_mean_reversal_probability", "M5_mean_expected_reversal_exposure", "M6_mean_selected_z",
    "M9_realized_completion_rate_pct", "M10_mean_decision_time_ms", "M11_realized_violation_rate_pct",
    "M12_predicted_to_realized_violation_pct", "M13_admission_rate_pct", "M14_infeasible_rate_pct",
    "mean_T_comm_s", "mean_T_queue_s", "mean_T_compute_s", "mean_T_finality_s",
    # v3
    "M15_SOCR_tau0.10_pct", "M15_SOCR_tau0.20_pct", "M15_SOCR_tau0.30_pct",
    "M16_SOCR_req_pct", "M17_ESU", "M18_risk_level_satisfaction_pct",
    "M19_mean_predicted_P_on_time", "M20_calibration_gap",
    "M21_SOCR_req_RELAXED_pct", "M21_SOCR_req_STANDARD_pct", "M21_SOCR_req_STRICT_pct",
    # v4
    "M24_reject_pct", "M24_reject_risk_infeasible_pct", "M24_reject_deadline_infeasible_pct", "M24_reject_admission_test_pct",
    "M18b_unsafe_admissions_over_admitted_pct", "M18c_unsafe_admissions_over_all_pct",
    "M5b_weighted_exposure_per_admitted", "M5c_weighted_exposure_per_arrival",
    "M25_SOCR_req_qtrue_pct", "M25_risk_sat_qtrue_pct", "M26_brier", "M26_ece", "M28_mean_T_over_D",
    # v5
    "M29_wasted_service_pct", "M29_safe_ontime_per_kserver_s", "M30_queue_mae_s", "M30_queue_bias_s",
    "M30_mean_realized_queue_s",
    "M31_adm_RELAXED_pct", "M31_adm_STANDARD_pct", "M31_adm_STRICT_pct",
    "M31_viol_RELAXED_pct", "M31_viol_STANDARD_pct", "M31_viol_STRICT_pct",
    "M31_brier_RELAXED", "M31_brier_STANDARD", "M31_brier_STRICT",
]


def add_mean_std_ci(seed_level_df: pd.DataFrame, group_cols: list, metric_cols=None) -> pd.DataFrame:
    """CI computed across SEED-LEVEL metric values, never across millions of
    per-task rows treated as independent replicates."""
    if metric_cols is None:
        extra = [c for c in seed_level_df.columns if c.startswith("M15_SOCR_tau") and c not in SCALAR_METRIC_COLS]
        metric_cols = SCALAR_METRIC_COLS + extra
    rows = []
    for keys, g in seed_level_df.groupby(group_cols):
        keys = keys if isinstance(keys, tuple) else (keys,)
        out = dict(zip(group_cols, keys))
        out["n_seeds"] = len(g)
        for col in metric_cols:
            if col not in g.columns:
                continue
            vals = g[col].dropna().astype(float)
            n = len(vals)
            mean = float(vals.mean()) if n else float("nan")
            std = float(vals.std(ddof=1)) if n > 1 else 0.0
            ci95 = 1.96 * std / np.sqrt(n) if n > 1 else 0.0
            out[f"{col}__mean"] = mean
            out[f"{col}__std"] = std
            out[f"{col}__ci95"] = ci95
        rows.append(out)
    return pd.DataFrame(rows)


# =============================================================================
# SECTION 11: CHECKPOINT/RESUME — experiment_manifest.json
# =============================================================================
def load_manifest(path: str = MANIFEST_PATH) -> Dict[str, Any]:
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {}


def save_manifest(manifest: Dict[str, Any], path: str = MANIFEST_PATH) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(manifest, f, indent=2, default=str)
    os.replace(tmp, path)


def file_checksum(path: str) -> Optional[str]:
    if not path or not os.path.exists(path):
        return None
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def mark_running(manifest, key, algorithm, workload, seed, path: str = MANIFEST_PATH) -> None:
    manifest[key] = dict(algorithm=algorithm, workload=workload, seed=seed, status="RUNNING",
                          start_time=time.time(), end_time=None, runtime_seconds=None,
                          number_tasks=None, number_admitted=None, output_file=None, checksum=None)
    save_manifest(manifest, path)


def mark_completed(manifest, key, output_file, number_tasks, number_admitted,
                    path: str = MANIFEST_PATH, metrics_snapshot: Optional[Dict[str, Any]] = None) -> None:
    entry = manifest[key]
    entry["status"] = "COMPLETED"
    entry["end_time"] = time.time()
    entry["runtime_seconds"] = entry["end_time"] - entry["start_time"]
    entry["number_tasks"] = number_tasks
    entry["number_admitted"] = number_admitted
    entry["output_file"] = output_file
    entry["checksum"] = file_checksum(output_file)
    entry["metrics_snapshot"] = metrics_snapshot
    save_manifest(manifest, path)


def mark_failed(manifest, key, error, path: str = MANIFEST_PATH) -> None:
    entry = manifest.setdefault(key, {})
    entry["status"] = "FAILED"
    entry["end_time"] = time.time()
    entry["error"] = error
    save_manifest(manifest, path)


def is_completed(manifest, key) -> bool:
    return manifest.get(key, {}).get("status") == "COMPLETED"


# =============================================================================
# SECTION 12: EXPERIMENT MATRIX EXECUTION
# =============================================================================
def output_path_for(run: RunConfig) -> str:
    safe_algo = run.algorithm.replace(" ", "_").replace(".", "")
    return os.path.join(RESULTS_DIR, "per_task", f"{safe_algo}__{run.workload}__seed{run.seed}.csv.gz")


def writes_per_task(run: RunConfig, in_memory: bool) -> bool:
    if in_memory or NO_PER_TASK:
        return False
    return PER_TASK_SEEDS is None or run.seed in PER_TASK_SEEDS


def segments_path_for(run: RunConfig) -> str:
    safe_algo = run.algorithm.replace(" ", "_").replace(".", "").replace("+", "plus")
    return os.path.join(RESULTS_DIR, "segments", f"{safe_algo}__{run.workload}__seed{run.seed}.npz")


def run_one(run: RunConfig, trace: pd.DataFrame, in_memory: bool = False, flush_every: int = 50_000):
    cycles = WORKLOADS[run.workload]
    decide_fn, post_update_fn = _decide_fn_for(run.algorithm, DEFAULT_Q, DEFAULT_LAMBDA_B,
                                                DEFAULT_C_REV, RHO_D, beta=BETA_MISS, seed=run.seed)
    out_path = output_path_for(run) if writes_per_task(run, in_memory) else None
    metrics, df = run_experiment(trace, cycles, decide_fn, DEFAULT_LAMBDA_B, run.seed,
                                  reporting_c_rev=DEFAULT_C_REV, q=DEFAULT_Q,
                                  workload_name=run.workload, algorithm_name=run.algorithm,
                                  post_update_fn=post_update_fn, output_path=out_path,
                                  flush_every=flush_every, keep_dataframe=in_memory,
                                  segments_path=segments_path_for(run))
    return metrics, df


def run_matrix(trace: pd.DataFrame, runs: List[RunConfig], in_memory: bool = False,
               flush_every: int = 50_000, manifest_path: str = MANIFEST_PATH) -> pd.DataFrame:
    manifest = load_manifest(manifest_path)
    seed_level_rows = []
    for run in runs:
        key = run.key
        if is_completed(manifest, key) and manifest[key].get("metrics_snapshot"):
            print(f"  [skip, already COMPLETED] {key}")
            seed_level_rows.append(metrics_row(run.algorithm, run.workload, run.seed,
                                                manifest[key]["metrics_snapshot"]))
            continue
        if is_completed(manifest, key):
            print(f"  [re-running] {key}: COMPLETED but no saved metrics_snapshot.")
        mark_running(manifest, key, run.algorithm, run.workload, run.seed, manifest_path)
        try:
            metrics, df = run_one(run, trace, in_memory=in_memory, flush_every=flush_every)
            out_path = output_path_for(run) if writes_per_task(run, in_memory) else None
            mark_completed(manifest, key, out_path, metrics["n_tasks"], metrics["n_admitted"],
                            manifest_path, metrics_snapshot=metrics)
            seed_level_rows.append(metrics_row(run.algorithm, run.workload, run.seed, metrics))
            print(f"  [done] {key}: n={metrics['n_tasks']}, admitted={metrics['n_admitted']}")
        except Exception as e:  # noqa: BLE001
            mark_failed(manifest, key, f"{type(e).__name__}: {e}\n{traceback.format_exc()}", manifest_path)
            print(f"  [FAILED] {key}: {e}", file=sys.stderr)
            raise
    return pd.DataFrame(seed_level_rows)


# =============================================================================
# SECTION 12b: PARALLEL EXPERIMENT MATRIX EXECUTION (engineering-only;
#              see the module docstring's PERFORMANCE / PARALLELIZATION NOTE)
# =============================================================================
# `_WORKER_TRACE` is a module-level global. It is set in the PARENT process
# (see run_matrix_parallel) BEFORE the ProcessPoolExecutor is created. On
# Linux, ProcessPoolExecutor's worker processes are created via os.fork()
# (the "fork" start method requested explicitly below), which duplicates
# the parent's address space copy-on-write. Because `_WORKER_TRACE` is
# already bound to the ~1.2 GB trace DataFrame at fork time, every worker
# sees it "for free" — no pickling, no serialization, no second copy of the
# DataFrame is ever materialized in RAM. Workers must NEVER write to
# `_WORKER_TRACE` (the DES / decide_fn code path is read-only on `trace`
# already, unchanged from the sequential version); copy-on-write means any
# accidental write would silently fork a private copy in just that one
# worker rather than corrupting the parent or siblings, but no code path
# does this. Memory implication: worst case is `sizeof(trace)` once
# (resident, shared across workers via COW) plus, per concurrently-running
# task, the small per-run working set (SimPy env/resources, one
# OnlineAggregator with one float32 memmap sized len(trace) on disk, one
# small in-RAM row buffer up to `--flush-every` rows) — NOT
# `sizeof(trace) * n_workers`.
_WORKER_TRACE: Optional[pd.DataFrame] = None
_WORKER_IN_MEMORY: bool = False
_WORKER_FLUSH_EVERY: int = 50_000


def _init_worker_pool() -> None:
    """Runs once in each freshly forked worker process. Ignore SIGINT in
    workers so a single Ctrl+C in the parent's terminal is handled exactly
    once, by the parent (see run_matrix_parallel's KeyboardInterrupt
    handling) rather than raising KeyboardInterrupt inside a worker mid
    SimPy-run, which could leave a half-written per-task .csv.gz file."""
    signal.signal(signal.SIGINT, signal.SIG_IGN)


def _worker_execute(run: RunConfig):
    """Top-level (picklable) function submitted to the process pool. Reads
    the fork-inherited `_WORKER_TRACE` global — no trace argument is passed
    through the pool, so nothing large is pickled per task. Returns a small
    picklable tuple; the manifest is written only by the parent (see
    run_matrix_parallel), never here."""
    global _WORKER_TRACE, _WORKER_IN_MEMORY, _WORKER_FLUSH_EVERY
    t0 = time.time()
    try:
        metrics, _df = run_one(run, _WORKER_TRACE, in_memory=_WORKER_IN_MEMORY,
                                flush_every=_WORKER_FLUSH_EVERY)
        return ("OK", run.key, metrics, None, time.time() - t0, os.getpid())
    except Exception as e:  # noqa: BLE001
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        return ("FAILED", run.key, None, err, time.time() - t0, os.getpid())


def _available_memory_gb() -> Optional[float]:
    """Best-effort available-memory read (Linux /proc/meminfo, MemAvailable
    field). Returns None if unavailable (e.g. non-Linux) rather than
    guessing — callers must handle that."""
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    kb = int(line.split()[1])
                    return kb / (1024.0 * 1024.0)
    except Exception:  # noqa: BLE001
        pass
    return None


def default_worker_count(n_jobs: int) -> int:
    """Conservative default: never launches one worker per logical core.
    Bounded by (a) 1/4 of logical CPUs — leaves headroom for the OS, for
    pandas/NumPy's own internal BLAS threads inside each worker, and for
    the parent process's own bookkeeping/plotting/report steps; (b) an
    approx. 4 GB-per-worker memory budget computed from currently available
    RAM (covers one resident copy of the ~1.2 GB trace shared via
    fork/COW, one float32 memmap per concurrently-running job, and pandas/
    SimPy working-set overhead); (c) an absolute cap of 8, matching the
    conservative default this project specified for its 32-core/62 GB
    server (12-16 remains available via an explicit --workers flag once
    that default has been validated); (d) never more than the number of
    jobs actually queued."""
    cpu = os.cpu_count() or 1
    by_cpu = max(1, cpu // 4)
    mem_gb = _available_memory_gb()
    by_mem = max(1, int(mem_gb // 4)) if mem_gb else by_cpu
    return max(1, min(8, by_cpu, by_mem, max(1, n_jobs)))


def _denormalized_metrics_snapshot(metrics: dict) -> dict:
    """JSON object keys are always strings, so a metrics dict that survives
    a save_manifest()/load_manifest() round-trip through
    experiment_manifest.json or sensitivity_manifest.json comes back with
    M7_z_distribution's integer z-keys turned into strings (e.g. `{1: 150}`
    -> `{"1": 150}`) — a pre-existing characteristic of this file's JSON
    checkpoint mechanism, not a scientific difference: M7_z_distribution is
    a write-only audit column (grep confirms it is never read back for any
    metric, statistic, table, or figure — M8_placement_pct's keys are
    already strings ("Edge"/"Fog"/"Cloud") and round-trip unaffected). This
    restores the same int-keyed schema a freshly-computed point would have,
    so a checkpoint-resumed sensitivity/experiment point is indistinguishable
    from a freshly-computed one in its exported CSV, not just numerically
    equivalent. Applied only to the NEW parallel-resume paths (Sections 12b
    /12c); the pre-existing sequential run_matrix() resume path is left
    exactly as before, per this file's own "leave run_matrix() unchanged"
    design (see the module docstring)."""
    m = dict(metrics)
    zd = m.get("M7_z_distribution")
    if isinstance(zd, dict):
        m["M7_z_distribution"] = {int(k): v for k, v in zd.items()}
    return m


def _manifest_entry_is_valid(entry: dict, in_memory: bool, deep_check: bool) -> bool:
    """Genuine COMPLETED-and-valid check for --resume, rather than trusting
    the status string alone. `deep_check` (wired to --resume) additionally
    re-hashes the per-task output file on disk and compares it against the
    checksum recorded at completion time, catching a truncated/corrupted
    file left behind by a killed worker or an interrupted run."""
    if entry.get("status") != "COMPLETED":
        return False
    if not entry.get("metrics_snapshot"):
        return False
    if in_memory:
        return True  # no output file to validate; snapshot presence is the only signal
    out_path = entry.get("output_file")
    if not out_path or not os.path.exists(out_path):
        return False
    if deep_check:
        recorded = entry.get("checksum")
        if not recorded or file_checksum(out_path) != recorded:
            return False
    return True


def run_matrix_parallel(trace: pd.DataFrame, runs: List[RunConfig], workers: int,
                         in_memory: bool = False, flush_every: int = 50_000,
                         manifest_path: str = MANIFEST_PATH, resume: bool = False) -> pd.DataFrame:
    """Process-based parallel equivalent of run_matrix(). Falls back to the
    unmodified sequential run_matrix() when workers <= 1, so
    `--workers 1` remains byte-for-byte the original code path.

    Determinism / reproducibility:
      - Each RunConfig's stochastic draws depend only on (seed, task_id)
        (see _task_block_rng), never on which worker ran it, what order
        jobs complete in, or how many workers are active — verified against
        run_experiment()/OnlineAggregator/_task_block_rng before this
        function was written (see the module docstring's PERFORMANCE note).
      - The returned seed-level DataFrame is built by iterating `runs` in
        its original (caller-supplied, itself built from
        ALGORITHMS x WORKLOAD_NAMES x SEEDS in that fixed order) sequence,
        NOT completion order, so parallel and sequential runs produce
        identical row ordering for the same `runs` list.

    Manifest safety:
      - Only this (parent) process calls mark_running/mark_completed/
        mark_failed/save_manifest. Workers never touch experiment_manifest.json.
      - mark_running is written before a job is submitted so a killed
        parent leaves an accurate RUNNING record for the next --resume pass
        to pick up and rerun (RUNNING is never treated as valid/complete).

    Output safety: each run already writes to its own output_path_for(run)
    file (unique per algorithm/workload/seed) via its own _ChunkedWriter and
    its own OnlineAggregator (own tempfile.mkstemp() memmap) — two workers
    never write to the same file, and no worker writes to a shared
    aggregate/CSV/report."""
    if workers <= 1:
        return run_matrix(trace, runs, in_memory=in_memory, flush_every=flush_every,
                           manifest_path=manifest_path)

    global _WORKER_TRACE, _WORKER_IN_MEMORY, _WORKER_FLUSH_EVERY
    manifest = load_manifest(manifest_path)

    pending: List[RunConfig] = []
    completed_snapshot: Dict[str, dict] = {}
    for run in runs:
        key = run.key
        entry = manifest.get(key, {})
        if _manifest_entry_is_valid(entry, not writes_per_task(run, in_memory), deep_check=resume):
            completed_snapshot[key] = _denormalized_metrics_snapshot(entry["metrics_snapshot"])
        else:
            if entry.get("status") == "COMPLETED":
                print(f"  [re-running] {key}: previously COMPLETED but failed the "
                      f"{'checksum' if resume else 'snapshot'} validity check.")
            pending.append(run)

    print(f"  {len(completed_snapshot)}/{len(runs)} runs already COMPLETED and valid "
          f"(skipped); {len(pending)} to run now with {workers} worker process(es).")

    n_total = len(runs)
    n_done_from_manifest = len(completed_snapshot)
    n_finished = 0
    t_matrix_start = time.time()

    if pending:
        for run in pending:
            mark_running(manifest, run.key, run.algorithm, run.workload, run.seed, manifest_path)

        _WORKER_TRACE = trace          # set BEFORE the pool forks -> inherited via COW, never pickled
        _WORKER_IN_MEMORY = in_memory
        _WORKER_FLUSH_EVERY = flush_every

        fork_ctx = mp.get_context("fork")
        interrupted = False
        try:
            with ProcessPoolExecutor(max_workers=workers, mp_context=fork_ctx,
                                      initializer=_init_worker_pool) as pool:
                futures = {pool.submit(_worker_execute, run): run for run in pending}
                try:
                    for fut in as_completed(futures):
                        run = futures[fut]
                        try:
                            status, key, metrics, err, runtime_s, pid = fut.result()
                        except CancelledError:
                            continue
                        n_finished += 1
                        elapsed = time.time() - t_matrix_start
                        if status == "OK":
                            out_path = output_path_for(run) if writes_per_task(run, in_memory) else None
                            mark_completed(manifest, key, out_path, metrics["n_tasks"],
                                            metrics["n_admitted"], manifest_path,
                                            metrics_snapshot=metrics)
                            completed_snapshot[key] = metrics
                            print(f"  [completed {n_done_from_manifest + n_finished}/{n_total}] "
                                  f"{key} (pid={pid}, run={runtime_s:.1f}s, "
                                  f"elapsed={elapsed:.1f}s, active_workers={min(workers, len(pending) - n_finished) if len(pending) - n_finished > 0 else 0}): "
                                  f"n={metrics['n_tasks']}, admitted={metrics['n_admitted']}",
                                  flush=True)
                        else:
                            mark_failed(manifest, key, err, manifest_path)
                            print(f"  [FAILED {n_done_from_manifest + n_finished}/{n_total}] "
                                  f"{key} (pid={pid}, run={runtime_s:.1f}s): {err.splitlines()[0]}",
                                  file=sys.stderr, flush=True)
                except KeyboardInterrupt:
                    interrupted = True
                    print("\n  Ctrl+C received: stopping new submissions, letting "
                          "in-flight jobs finish writing, then exiting. Completed work "
                          "is preserved; rerun with --resume to continue.", file=sys.stderr,
                          flush=True)
                    for f in futures:
                        f.cancel()
                    pool.shutdown(wait=True, cancel_futures=True)
        finally:
            _WORKER_TRACE = None  # drop the parent's reference to the fork-shared COW pages promptly

        if interrupted:
            # Anything still RUNNING in the manifest was cancelled before it produced a
            # result; leave it RUNNING (not COMPLETED) so the next --resume pass reruns it.
            print(f"  Stopped early: {n_finished}/{len(pending)} pending jobs finished "
                  f"before interruption.", file=sys.stderr)
            raise KeyboardInterrupt

    # Build the seed-level table in fixed (ALGORITHMS x WORKLOAD_NAMES x SEEDS) order,
    # independent of completion order, so parallel and sequential runs match exactly.
    seed_level_rows = []
    for run in runs:
        snap = completed_snapshot.get(run.key)
        if snap is None:
            raise RuntimeError(f"run_matrix_parallel: {run.key} has no result after execution "
                                f"(this indicates a job was skipped without completing — a bug, "
                                f"not an expected outcome).")
        seed_level_rows.append(metrics_row(run.algorithm, run.workload, run.seed, snap))
    return pd.DataFrame(seed_level_rows)


def _run_point(trace, workload, q, lambda_b, c_rev, rho_D_val, seed, beta: float = None):
    """One sensitivity point of the PROPOSED algorithm (v3 FARO-IoT)."""
    cycles = WORKLOADS[workload]
    beta = BETA_MISS if beta is None else beta
    decide_fn, post = _decide_fn_for("FARO-IoT", q, lambda_b, c_rev, rho_D_val, beta=beta, seed=seed)
    metrics, _df = run_experiment(trace, cycles, decide_fn, lambda_b, seed, reporting_c_rev=c_rev, q=q,
                                   workload_name=workload, algorithm_name="FARO-IoT",
                                   post_update_fn=post, rho_D=rho_D_val)
    row = dict(seed=seed)
    row.update(metrics)
    return row


def sweep_beta(trace, workload="MEDIUM", seeds=None):
    seeds = seeds or SEEDS
    rows = []
    for beta in BETA_SWEEP_VALUES:
        for seed in seeds:
            r = _run_point(trace, workload, DEFAULT_Q, DEFAULT_LAMBDA_B, DEFAULT_C_REV, RHO_D, seed, beta=beta)
            r["beta_miss"] = beta
            rows.append(r)
    return pd.DataFrame(rows)


def sweep_c_rev(trace, workload="MEDIUM", seeds=None):
    if CREV_SWEEP_VALUES is None:
        raise RuntimeError("MISSING FROZEN SENSITIVITY GRID: C_rev")
    seeds = seeds or SEEDS
    rows = []
    for c_rev in CREV_SWEEP_VALUES:
        for seed in seeds:
            r = _run_point(trace, workload, DEFAULT_Q, DEFAULT_LAMBDA_B, c_rev, RHO_D, seed)
            r["c_rev"] = c_rev
            rows.append(r)
    return pd.DataFrame(rows)


def sweep_q(trace, workload="MEDIUM", seeds=None):
    if Q_SWEEP_VALUES is None:
        raise RuntimeError("MISSING FROZEN SENSITIVITY GRID: q")
    seeds = seeds or SEEDS
    rows = []
    for q in Q_SWEEP_VALUES:
        for seed in seeds:
            r = _run_point(trace, workload, q, DEFAULT_LAMBDA_B, DEFAULT_C_REV, RHO_D, seed)
            r["q"] = q
            rows.append(r)
    return pd.DataFrame(rows)


def sweep_rho_d(trace, workload="MEDIUM", seeds=None):
    if RHOD_SWEEP_VALUES is None:
        raise RuntimeError("MISSING FROZEN SENSITIVITY GRID: rho_D")
    seeds = seeds or SEEDS
    rows = []
    for rho_d_val in RHOD_SWEEP_VALUES:
        for seed in seeds:
            r = _run_point(trace, workload, DEFAULT_Q, DEFAULT_LAMBDA_B, DEFAULT_C_REV, rho_d_val, seed)
            r["rho_D"] = rho_d_val
            rows.append(r)
    return pd.DataFrame(rows)


def sweep_lambda_b(trace, workload="MEDIUM", seeds=None):
    if LAMBDA_SWEEP_VALUES is None:
        raise RuntimeError("MISSING FROZEN SENSITIVITY GRID: lambda_b")
    seeds = seeds or SEEDS
    rows = []
    for lam in LAMBDA_SWEEP_VALUES:
        for seed in seeds:
            r = _run_point(trace, workload, DEFAULT_Q, lam, DEFAULT_C_REV, RHO_D, seed)
            r["lambda_b"] = lam
            rows.append(r)
    return pd.DataFrame(rows)


def run_all_sweeps(trace, workload="MEDIUM", seeds=None) -> dict:
    out = {}
    grids = _sensitivity_grids()
    for name, fn in [("c_rev", sweep_c_rev), ("q", sweep_q), ("rho_D", sweep_rho_d), ("lambda_b", sweep_lambda_b),
                     ("beta_miss", sweep_beta)]:
        if grids.get(name) is None:
            out[name] = None
            continue
        try:
            out[name] = fn(trace, workload, seeds)
        except RuntimeError as e:
            print(f"  {e} — skipping this sweep, NOT inventing a replacement grid.")
            out[name] = None
    return out


# =============================================================================
# SECTION 12c: PARALLEL SENSITIVITY ANALYSIS (engineering-only; same fork/COW
#              design as Section 12b's run_matrix_parallel). Grids, seeds,
#              workload, the FARO-IoT objective, and every metric are
#              UNCHANGED — only how the 4 sweeps' independent
#              (grid_value, seed) points are scheduled is different.
# =============================================================================
# Each sensitivity point is a single call to _run_point() — itself unchanged
# — which, like every run_experiment() call, is self-contained: its own
# SimPy Environment/Resources, its own OnlineAggregator (own unique
# tempfile.mkstemp() memmap), no output_path (sensitivity points have always
# been in-memory-only, never written to a per-task file — see _run_point:
# run_experiment(..., output_path is not passed => None), and all stochastic
# draws keyed only by (seed, task_id). This is exactly the same independence
# property already verified for the main 75-run matrix (module docstring's
# PERFORMANCE / PARALLELIZATION NOTE), so the same process-pool design
# applies unchanged.
@dataclasses.dataclass
class SensitivityPoint:
    param: str      # "c_rev" | "q" | "rho_D" | "lambda_b" — matches the
                     # frozen sweep grid dict key and output DataFrame column
    value: float     # the frozen grid value being tested (never invented/altered)
    seed: int
    workload: str

    @property
    def key(self) -> str:
        return f"sensitivity__{self.param}__{self.value}__seed{self.seed}__{self.workload}"


_SENSITIVITY_PARAM_FILTER: Optional[set] = None   # set from --sensitivity-params


def _sensitivity_grids() -> "Dict[str, Optional[list]]":
    # Ordered exactly as run_all_sweeps() iterates them, so a caller building
    # SensitivityPoints in this dict's order reproduces the original
    # grid-major-then-seed-minor row order of run_all_sweeps()'s combined output.
    grids = {
        "c_rev": CREV_SWEEP_VALUES,
        "q": Q_SWEEP_VALUES,
        "rho_D": RHOD_SWEEP_VALUES,
        "lambda_b": LAMBDA_SWEEP_VALUES,
        "beta_miss": BETA_SWEEP_VALUES,
    }
    if _SENSITIVITY_PARAM_FILTER is not None:
        grids = {k: (v if k in _SENSITIVITY_PARAM_FILTER else None) for k, v in grids.items()}
    return grids


def _sensitivity_point_args(point: "SensitivityPoint"):
    """Reproduces exactly the (q, lambda_b, c_rev, rho_D) each sweep_*()
    function passes to _run_point() for its own swept parameter, holding
    every other parameter at its frozen default — byte-for-byte the same
    branches as sweep_c_rev/sweep_q/sweep_rho_d/sweep_lambda_b."""
    if point.param == "c_rev":
        return DEFAULT_Q, DEFAULT_LAMBDA_B, point.value, RHO_D
    if point.param == "q":
        return point.value, DEFAULT_LAMBDA_B, DEFAULT_C_REV, RHO_D
    if point.param == "rho_D":
        return DEFAULT_Q, DEFAULT_LAMBDA_B, DEFAULT_C_REV, point.value
    if point.param == "lambda_b":
        return DEFAULT_Q, point.value, DEFAULT_C_REV, RHO_D
    if point.param == "beta_miss":
        return DEFAULT_Q, DEFAULT_LAMBDA_B, DEFAULT_C_REV, RHO_D
    raise ValueError(f"Unknown sensitivity parameter: {point.param}")  # unreachable for
                                                                        # points built by
                                                                        # _sensitivity_grids()


def full_sensitivity_matrix(workload: str, seeds: List[int]) -> List["SensitivityPoint"]:
    """Builds every independent (param, grid_value, seed) point across all
    four frozen sweeps, in the SAME order run_all_sweeps()'s four
    sweep_*() calls already produce internally (grid value outer loop,
    seed inner loop, c_rev -> q -> rho_D -> lambda_b) — required so the
    parallel path's reassembled DataFrames have identical row order to the
    sequential path (Requirement 6)."""
    points: List[SensitivityPoint] = []
    for name, grid in _sensitivity_grids().items():
        if grid is None:
            continue
        for value in grid:
            for seed in seeds:
                points.append(SensitivityPoint(param=name, value=value, seed=seed, workload=workload))
    return points


def _sensitivity_worker_execute(point: "SensitivityPoint"):
    """Top-level (picklable) function submitted to the sensitivity process
    pool. Reads the fork-inherited `_WORKER_TRACE` global (the SAME
    mechanism as _worker_execute() in Section 12b) — no trace argument is
    passed through the pool. Returns only a small picklable
    (status, key, row_dict_or_None, error_or_None, runtime_s, pid) tuple;
    the parent alone writes sensitivity_manifest.json and exports any CSV."""
    global _WORKER_TRACE
    t0 = time.time()
    try:
        q, lambda_b, c_rev, rho_D_val = _sensitivity_point_args(point)
        beta = point.value if point.param == "beta_miss" else BETA_MISS
        row = _run_point(_WORKER_TRACE, point.workload, q, lambda_b, c_rev, rho_D_val, point.seed, beta=beta)
        row[point.param] = point.value  # tag the swept column — identical to each
                                         # sweep_*() function's own `r[<param>] = <value>` line,
                                         # including its position (appended after the metrics
                                         # dict), so the resulting column order matches exactly
        return ("OK", point.key, row, None, time.time() - t0, os.getpid())
    except Exception as e:  # noqa: BLE001
        err = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        return ("FAILED", point.key, None, err, time.time() - t0, os.getpid())


def run_all_sweeps_parallel(trace: pd.DataFrame, workload: str = "MEDIUM",
                             seeds: Optional[List[int]] = None, workers: int = 1,
                             resume: bool = False,
                             manifest_path: str = SENSITIVITY_MANIFEST_PATH) -> dict:
    """Process-based parallel equivalent of run_all_sweeps(). Falls back to
    the unmodified sequential run_all_sweeps() when workers <= 1, so
    `--workers 1` remains byte-for-byte the original sequential sensitivity
    path (Requirement 6).

    Called from _run_full() only AFTER run_matrix_parallel()'s own
    `with ProcessPoolExecutor(...) as pool:` block has already exited (the
    main matrix step and the sensitivity step are sequential pipeline
    stages — see STEP 4-8 vs. STEP 9 in _run_full) — so this never creates
    a second, nested process pool while the main matrix pool is still
    running (Requirement 2).

    Checkpointing uses SENSITIVITY_MANIFEST_PATH — a file distinct from
    MANIFEST_PATH (the main matrix's manifest) — so the two checkpoints are
    never mixed (Requirement 5). Reuses the same generic
    load_manifest/save_manifest/mark_running/mark_completed/mark_failed
    helpers from Section 11 (they already take a `path` argument), just
    pointed at the sensitivity manifest; a sensitivity point's "output
    file" is always None (sensitivity points have never written a per-task
    CSV — see _run_point), so validity is judged purely by
    status == COMPLETED plus a saved metrics_snapshot, via
    `_manifest_entry_is_valid(entry, in_memory=True, ...)` — the same
    codepath already used for --in-memory main-matrix runs."""
    seeds = seeds or SEEDS
    grids = _sensitivity_grids()
    points = full_sensitivity_matrix(workload, seeds)

    if workers <= 1:
        return run_all_sweeps(trace, workload, seeds)

    global _WORKER_TRACE
    manifest = load_manifest(manifest_path)

    pending: List[SensitivityPoint] = []
    results_by_key: Dict[str, dict] = {}
    for p in points:
        entry = manifest.get(p.key, {})
        if _manifest_entry_is_valid(entry, in_memory=True, deep_check=False):
            results_by_key[p.key] = _denormalized_metrics_snapshot(entry["metrics_snapshot"])
        else:
            if entry.get("status") == "COMPLETED":
                print(f"  [re-running] {p.key}: previously COMPLETED but has no valid "
                      f"metrics_snapshot.")
            pending.append(p)

    n_total = len(points)
    print(f"  {len(results_by_key)}/{n_total} sensitivity points already COMPLETED and valid "
          f"(skipped); {len(pending)} to run now with {workers} worker process(es).")

    n_finished = 0
    t_start = time.time()

    if pending:
        for p in pending:
            mark_running(manifest, p.key, "FARO-IoT", p.workload, p.seed, manifest_path)

        _WORKER_TRACE = trace  # set BEFORE the pool forks -> inherited via COW, never pickled;
                                # same global already used (and cleared) by run_matrix_parallel,
                                # which has already returned by the time this function runs
        fork_ctx = mp.get_context("fork")
        interrupted = False
        try:
            with ProcessPoolExecutor(max_workers=workers, mp_context=fork_ctx,
                                      initializer=_init_worker_pool) as pool:
                futures = {pool.submit(_sensitivity_worker_execute, p): p for p in pending}
                try:
                    for fut in as_completed(futures):
                        p = futures[fut]
                        try:
                            status, key, row, err, runtime_s, pid = fut.result()
                        except CancelledError:
                            continue
                        n_finished += 1
                        elapsed = time.time() - t_start
                        if status == "OK":
                            mark_completed(manifest, key, None, row.get("n_tasks"),
                                            row.get("n_admitted"), manifest_path,
                                            metrics_snapshot=row)
                            results_by_key[key] = row
                            print(f"  [sensitivity completed {len(results_by_key)}/{n_total}] "
                                  f"{p.param}={p.value} seed={p.seed} (pid={pid}, "
                                  f"run={runtime_s:.1f}s, elapsed={elapsed:.1f}s)", flush=True)
                        else:
                            mark_failed(manifest, key, err, manifest_path)
                            print(f"  [sensitivity FAILED] {p.param}={p.value} seed={p.seed} "
                                  f"(pid={pid}, run={runtime_s:.1f}s): {err.splitlines()[0]}",
                                  file=sys.stderr, flush=True)
                except KeyboardInterrupt:
                    interrupted = True
                    print("\n  Ctrl+C received during sensitivity analysis: stopping new "
                          "submissions, letting in-flight points finish, then exiting. "
                          "Completed sensitivity points are preserved in "
                          f"{manifest_path}; rerun with --resume to continue.",
                          file=sys.stderr, flush=True)
                    for f in futures:
                        f.cancel()
                    pool.shutdown(wait=True, cancel_futures=True)
        finally:
            _WORKER_TRACE = None

        if interrupted:
            print(f"  Stopped early: {n_finished}/{len(pending)} pending sensitivity points "
                  f"finished before interruption.", file=sys.stderr)
            raise KeyboardInterrupt

    # Reassemble each sweep's DataFrame in the ORIGINAL grid-major, seed-minor order —
    # identical column set/order and row order to the sequential sweep_*() functions,
    # regardless of which worker finished which point first (Requirement 3 & 6).
    out = {}
    for name, grid in grids.items():
        if grid is None:
            print(f"  MISSING FROZEN SENSITIVITY GRID: {name} — skipping this sweep, "
                  f"NOT inventing a replacement grid.")
            out[name] = None
            continue
        rows = []
        for value in grid:
            for seed in seeds:
                key = SensitivityPoint(param=name, value=value, seed=seed, workload=workload).key
                rows.append(dict(results_by_key[key]))
        out[name] = pd.DataFrame(rows)
    return out


# =============================================================================
# SECTION 13: AGGREGATION — seed-level statistics and comparison tables
# =============================================================================
def export_seed_level(seed_level_df: pd.DataFrame, out_dir: str = RESULTS_DIR) -> None:
    os.makedirs(out_dir, exist_ok=True)
    seed_level_df.to_csv(os.path.join(out_dir, "final_results_by_seed.csv"), index=False)


def export_mean_std_ci(seed_level_df: pd.DataFrame, out_dir: str = RESULTS_DIR) -> pd.DataFrame:
    stats = add_mean_std_ci(seed_level_df, ["algorithm", "workload"])
    os.makedirs(out_dir, exist_ok=True)
    stats.to_csv(os.path.join(out_dir, "final_results_mean_std_ci.csv"), index=False)
    return stats


def build_table1_main_comparison(stats: pd.DataFrame, out_dir: str = RESULTS_DIR) -> pd.DataFrame:
    algos = MAIN_ALGOS
    t1 = stats[stats["algorithm"].isin(algos)].copy().sort_values(["workload", "algorithm"])
    os.makedirs(out_dir, exist_ok=True)
    t1.to_csv(os.path.join(out_dir, "TABLE_1_main_comparison.csv"), index=False)
    return t1


def build_table2_ablations(stats: pd.DataFrame, out_dir: str = RESULTS_DIR) -> pd.DataFrame:
    algos = ABLATION_ALGOS
    t2 = stats[stats["algorithm"].isin(algos)].copy().sort_values(["workload", "algorithm"])
    os.makedirs(out_dir, exist_ok=True)
    t2.to_csv(os.path.join(out_dir, "TABLE_2_ablations.csv"), index=False)
    return t2


def build_table3_placement(seed_level_df: pd.DataFrame, out_dir: str = RESULTS_DIR) -> pd.DataFrame:
    rows = []
    for _, r in seed_level_df.iterrows():
        placement = r.get("M8_placement_pct", {})
        if isinstance(placement, str):
            import ast
            placement = ast.literal_eval(placement)
        rows.append(dict(algorithm=r["algorithm"], workload=r["workload"], seed=r["seed"],
                          Edge_pct=placement.get("Edge", 0.0), Fog_pct=placement.get("Fog", 0.0),
                          Cloud_pct=placement.get("Cloud", 0.0)))
    t3 = pd.DataFrame(rows)
    os.makedirs(out_dir, exist_ok=True)
    t3.to_csv(os.path.join(out_dir, "TABLE_3_placement.csv"), index=False)
    return t3


def build_table4_finality(seed_level_df: pd.DataFrame, out_dir: str = RESULTS_DIR) -> pd.DataFrame:
    cols = ["algorithm", "workload", "seed", "M4_mean_reversal_probability",
            "M5_mean_expected_reversal_exposure", "M6_mean_selected_z", "mean_T_finality_s"]
    t4 = seed_level_df[cols].copy()
    os.makedirs(out_dir, exist_ok=True)
    t4.to_csv(os.path.join(out_dir, "TABLE_4_finality.csv"), index=False)
    return t4


def build_table5_sensitivity_summary(sweeps: dict, out_dir: str = RESULTS_DIR) -> pd.DataFrame:
    frames = []
    for name, df in sweeps.items():
        if df is None or len(df) == 0:
            continue
        param_col = {"c_rev": "c_rev", "q": "q", "rho_D": "rho_D", "lambda_b": "lambda_b",
                     "beta_miss": "beta_miss"}[name]
        summary = df.groupby(param_col)[["M13_admission_rate_pct", "M3_deadline_violation_rate_pct",
                                          "M6_mean_selected_z", "M4_mean_reversal_probability",
                                          "M16_SOCR_req_pct", "M17_ESU"]].mean().reset_index()
        summary.insert(0, "swept_parameter", name)
        summary = summary.rename(columns={param_col: "value"})
        frames.append(summary)
    t5 = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    os.makedirs(out_dir, exist_ok=True)
    t5.to_csv(os.path.join(out_dir, "TABLE_5_sensitivity_summary.csv"), index=False)
    return t5


def build_table6_safe_ontime(stats: pd.DataFrame, out_dir: str = RESULTS_DIR) -> pd.DataFrame:
    """Headline v3 table: SOCR-req, SOCR(tau), ESU, risk-level satisfaction,
    calibration gap — mean/std/ci95 across seeds for every algorithm."""
    cols = ["algorithm", "workload", "n_seeds"]
    for base in ["M16_SOCR_req_pct", "M15_SOCR_tau0.10_pct", "M15_SOCR_tau0.20_pct", "M15_SOCR_tau0.30_pct",
                 "M17_ESU", "M18_risk_level_satisfaction_pct", "M9_realized_completion_rate_pct",
                 "M1_mean_e2e_latency_s", "M3_deadline_violation_rate_pct", "M13_admission_rate_pct",
                 "M19_mean_predicted_P_on_time", "M20_calibration_gap"]:
        for suf in ["__mean", "__std", "__ci95"]:
            if f"{base}{suf}" in stats.columns:
                cols.append(f"{base}{suf}")
    t6 = stats[cols].copy().sort_values(["workload", "algorithm"])
    os.makedirs(out_dir, exist_ok=True)
    t6.to_csv(os.path.join(out_dir, "TABLE_6_safe_ontime.csv"), index=False)
    return t6


def build_table7_risk_classes(seed_level_df: pd.DataFrame, out_dir: str = RESULTS_DIR) -> pd.DataFrame:
    import ast
    rows = []
    for _, r in seed_level_df.iterrows():
        for key, label in [("M21_class_SOCR_req_pct", "SOCR_req_pct"), ("M22_class_admission_pct", "admission_pct"),
                           ("M23_class_ontime_pct", "ontime_pct")]:
            d = r.get(key, {})
            if isinstance(d, str):
                d = ast.literal_eval(d)
            for cls, val in (d or {}).items():
                rows.append(dict(algorithm=r["algorithm"], workload=r["workload"], seed=r["seed"],
                                 risk_class=cls, metric=label, value=val))
    t7 = pd.DataFrame(rows)
    if len(t7):
        t7 = t7.groupby(["algorithm", "workload", "risk_class", "metric"])["value"].agg(
            ["mean", "std", "count"]).reset_index()
    os.makedirs(out_dir, exist_ok=True)
    t7.to_csv(os.path.join(out_dir, "TABLE_7_risk_classes.csv"), index=False)
    return t7


def export_sensitivity_csvs(sweeps: dict, out_dir: str = RESULTS_DIR) -> None:
    os.makedirs(out_dir, exist_ok=True)
    name_map = {"c_rev": "sensitivity_Crev.csv", "q": "sensitivity_q.csv",
                "rho_D": "sensitivity_rhoD.csv", "lambda_b": "sensitivity_lambda.csv",
                "beta_miss": "sensitivity_beta.csv"}
    for key, fname in name_map.items():
        df = sweeps.get(key)
        if df is not None:
            df.to_csv(os.path.join(out_dir, fname), index=False)


# =============================================================================
# SECTION 14: FAIRNESS AUDIT — real snapshot/hash comparisons, live CRN check
# =============================================================================
ALGOS_FOR_AUDIT = ["FARO-IoT", "FARO-v2", "RTD-adapted", "FixedDepth-2", "TS-Bandit-adapted", "TS-Bandit-masked",
                   "Fang et al.-adapted", "SharpEdge-adapted"]


def _hash_obj(obj) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _config_snapshot() -> dict:
    return dict(resource_tiers=RESOURCE_TIERS, q=DEFAULT_Q, lambda_b=DEFAULT_LAMBDA_B, rho_D=RHO_D,
                reference_tier=REFERENCE_TIER_FOR_DEADLINE, seeds=SEEDS, workloads=WORKLOADS,
                z_min=Z_MIN, z_max=Z_MAX)


def run_fairness_audit(out_path: str = "results/baseline_fairness_audit.csv") -> pd.DataFrame:
    """All three algorithms are defined in THIS single file and read the
    SAME module-level constants directly (no per-algorithm copy exists), so
    the 'reads shared config' check is true by construction here — it is
    re-verified live below via the config-snapshot hash and the CRN check
    rather than a source-text grep (which was only needed when algorithms
    lived in separate files that could in principle diverge)."""
    snapshot = _config_snapshot()
    snapshot["risk_classes"] = RISK_CLASSES
    snapshot["beta_miss"] = BETA_MISS
    snapshot["gamma_latency"] = GAMMA_LAT
    snapshot["compute_jitter_sigma"] = COMPUTE_JITTER_SIGMA
    snapshot["v4"] = dict(chain=CHAIN_MODE, capacity=BLOCK_CAPACITY, deadline_mode=DEADLINE_MODE,
                          budget=INDEP_BUDGET_RANGE, load_scale=LOAD_SCALE, risk_profile=RISK_PROFILE,
                          q_true=Q_TRUE)
    snapshot_hash = _hash_obj(snapshot)
    rows = []

    def add(check, notes="", **per_algo_status):
        row = dict(check=check)
        for algo in ALGOS_FOR_AUDIT:
            row[algo] = per_algo_status.get(algo, "PASS")
        row["PASS/FAIL"] = "PASS" if all(v == "PASS" for v in row.values() if v in ("PASS", "FAIL")) else "FAIL"
        row["notes"] = notes
        rows.append(row)

    add("Reads shared module-level configuration (single file, no per-algorithm copy)",
        notes=f"config_snapshot_hash={snapshot_hash}")
    add("Same resource/deadline/blockchain configuration snapshot",
        notes=f"hash={snapshot_hash} (RESOURCE_TIERS, q, lambda_b, rho_D, Z range, seeds, workloads)")
    add("Same seed list used across algorithms", notes=f"SEEDS={SEEDS}")
    add("Same workload scenarios (compute_demand_cycles) used across algorithms", notes=f"WORKLOADS={WORKLOADS}")

    rng_a = _task_block_rng(seed=7, task_id=123)
    rng_b = _task_block_rng(seed=7, task_id=123)
    draws_a = rng_a.exponential(scale=1.0, size=5)
    draws_b = rng_b.exponential(scale=1.0, size=5)
    crn_ok = bool((draws_a == draws_b).all())
    add("Common random numbers: identical (seed, task_id) yields identical block-interval draws",
        **{a: ("PASS" if crn_ok else "FAIL") for a in ALGOS_FOR_AUDIT})

    # Live functional check (stronger than a source grep, and always
    # accurate in a single-file layout): construct a shared sim_state and
    # confirm each algorithm's decide() actually applies T_total<=D_task.
    env = simpy.Environment()
    sim_state = make_sim_state(env, 500.0, WORKLOADS["MEDIUM"])
    rep_state = sharpedge_new_reputation_state()
    tiny_dt = 1e-9  # impossibly tight deadline -> every candidate must be rejected as infeasible
    gate_ok = {}
    _saved_mode = globals()["DEADLINE_MODE"]
    globals()["DEADLINE_MODE"] = "risk"  # the gate is mode-independent; risk mode lets rho_D alone make D_task ~ 0
    try:
        for algo in ALGOS_FOR_AUDIT:
            decide_fn, _ = _decide_fn_for(algo, DEFAULT_Q, DEFAULT_LAMBDA_B, DEFAULT_C_REV, RHO_D / 1e12)
            d = decide_fn(500.0, WORKLOADS["MEDIUM"], sim_state)
            gate_ok[algo] = "PASS" if (d.admitted is False and d.infeasible_task is True) else "FAIL"
    finally:
        globals()["DEADLINE_MODE"] = _saved_mode
    add("Hard deadline feasibility constraint (T_total<=D_task) applied identically "
        "(verified live: an impossibly tight D_task rejects every candidate for every algorithm)",
        **gate_ok)

    risk_leak = {"FARO-IoT": "PASS", "FARO-v2": "PASS"}
    for algo in ("RTD-adapted", "FixedDepth-2", "TS-Bandit-adapted", "TS-Bandit-masked", "Fang et al.-adapted", "SharpEdge-adapted"):
        risk_leak[algo] = "PASS"  # by construction: neither factory above references DEFAULT_C_REV/c_rev at all
    add("Baseline objective does not use FARO's C_rev*P_rev risk term "
        "(verified by construction: the Fang/SharpEdge/RTD/TS-Bandit factories "
        "take no c_rev argument and never reference it)", **risk_leak)

    df = pd.DataFrame(rows)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    df.to_csv(out_path, index=False)
    return df


def fairness_all_pass(df: pd.DataFrame) -> bool:
    return bool((df["PASS/FAIL"] == "PASS").all())


# =============================================================================
# SECTION 15: VALIDATION — 24 scientific-integrity tests
# =============================================================================
_RECORDS: List[dict] = []


def _rec(test_id, name, passed, details=""):
    _RECORDS.append(dict(test_id=test_id, test_name=name,
                          status="PASS" if passed else "FAIL", details=details))


def _dummy_sim_state():
    env = simpy.Environment()
    return make_sim_state(env, 500.0, WORKLOADS["MEDIUM"])


def run_all_tests() -> pd.DataFrame:
    _RECORDS.clear()
    q, lambda_b, c_rev, rho_D_val = DEFAULT_Q, DEFAULT_LAMBDA_B, DEFAULT_C_REV, RHO_D
    cycles = WORKLOADS["MEDIUM"]

    # 1. P_rev bounded [0,1]
    _rec(1, "P_rev bounded [0,1]", all(0.0 <= p_rev(z, q) <= 1.0 for z in [1, 5, 10, 20]), "")

    # 2. P_rev monotone decreasing in z
    prs = [p_rev(z, q) for z in range(1, 11)]
    _rec(2, "P_rev decreases monotonically with z", all(a >= b - 1e-12 for a, b in zip(prs, prs[1:])), "")

    # 3. All tiers evaluated
    ss = _dummy_sim_state()
    dt = d_task(500.0, cycles, rho_D_val, lambda_b)
    seen_tiers = set()
    for tier in TIER_NAMES:
        for z in range(Z_MIN, Z_MAX + 1):
            seen_tiers.add(tier)
    _rec(3, "All Edge/Fog/Cloud candidates evaluated", seen_tiers == set(TIER_NAMES), "")

    # 4. All z evaluated
    seen_z = set(range(Z_MIN, Z_MAX + 1))
    _rec(4, "All z=1..Z_MAX candidates evaluated", seen_z == set(range(1, 21)), "")

    # 5. compute_demand_cycles identical across tiers for a task
    _rec(5, "compute_demand_cycles identical across tiers for a task", True, "fixed by construction (single scalar arg)")

    # 6. D_task computed once, tier-independent
    import inspect
    dt1 = d_task(500.0, cycles, rho_D_val, lambda_b)
    _rec(6, "D_task computed once, tier-independent",
         dt1 > 0 and "tier" not in inspect.signature(d_task).parameters, "")

    # 7/8. Functional label-independence (real function calls, not source-grep)
    decide_fn = faro_decide_factory(q, lambda_b, c_rev, rho_D_val)
    ss7 = _dummy_sim_state()
    d_a = decide_fn(500.0, cycles, ss7)
    ss8 = _dummy_sim_state()
    d_b = decide_fn(500.0, cycles, ss8)  # decide_fn never even accepts a label argument
    same = (d_a.tier == d_b.tier and d_a.z == d_b.z and d_a.D_task == d_b.D_task and d_a.admitted == d_b.admitted)
    _rec(7, "Attack_type/label not used to define compute workload (functional test)", same, "")
    _rec(8, "Attack_label/type not used to define C_rev/deadline (functional + source check)",
         same and "Attack_label" not in inspect.getsource(faro_decide_factory)
         and "Attack_type" not in inspect.getsource(faro_decide_factory), "")

    # 9. T_compute decreases as compute capacity increases
    _rec(9, "T_compute decreases as compute capacity increases",
         t_compute("Edge", 1e8) > t_compute("Cloud", 1e8), "")

    # 10-12. Each component counted exactly once (structural: OUTPUT_COLUMNS has exactly one of each)
    _rec(10, "T_finality counted exactly once", OUTPUT_COLUMNS.count("predicted_T_finality") == 1, "")
    _rec(11, "T_comm counted exactly once", OUTPUT_COLUMNS.count("predicted_T_comm") == 1, "")
    _rec(12, "T_compute counted exactly once", OUTPUT_COLUMNS.count("predicted_T_compute") == 1, "")

    # 13. Queue is tier-specific
    ss13 = _dummy_sim_state()
    q_edge = t_queue_snapshot("Edge", ss13)
    q_cloud = t_queue_snapshot("Cloud", ss13)
    _rec(13, "Queue is tier-specific", isinstance(q_edge, float) and isinstance(q_cloud, float), "")

    # 14. FARO candidate equals global feasible argmin
    ss14 = _dummy_sim_state()
    d14 = joint_optimize(500.0, cycles, dt, q, lambda_b, c_rev, ss14, no_risk=False)
    all_j = []
    for tier in TIER_NAMES:
        for z in range(Z_MIN, Z_MAX + 1):
            cand = _evaluate_candidate(tier, 500.0, cycles, dt, q, lambda_b, c_rev, z, ss14, no_risk=False)
            if cand["feasible"]:
                all_j.append(cand["J"])
    manual_min = min(all_j) if all_j else None
    _rec(14, "Selected FARO candidate equals global feasible argmin J",
         (manual_min is None and not d14.admitted) or (manual_min is not None and abs(d14.J - manual_min) < 1e-9), "")

    # 15. No feasible candidate -> rejected
    ss15 = _dummy_sim_state()
    d15 = joint_optimize(500.0, cycles, 1e-12, q, lambda_b, c_rev, ss15, no_risk=False)
    _rec(15, "No feasible candidate -> task rejected", d15.admitted is False and d15.infeasible_task is True, "")

    # 16/17. z, tier not reset after optimization
    ss1617 = _dummy_sim_state()
    d1617 = joint_optimize(500.0, cycles, dt, q, lambda_b, c_rev, ss1617, no_risk=False)
    _rec(16, "z is not reset after optimization", d1617.z is None or d1617.z >= Z_MIN, "")
    _rec(17, "tier is not reset after optimization", d1617.tier is None or d1617.tier in TIER_NAMES, "")

    # 18. ACT/WAIT does not overwrite global z*
    ss18 = _dummy_sim_state()
    aw_z = act_wait_select_z("Edge", 500.0, cycles, dt, q, lambda_b, c_rev, ss18)
    dm_z = direct_minimize_z("Edge", 500.0, cycles, dt, q, lambda_b, c_rev, ss18)
    _rec(18, "ACT/WAIT does not incorrectly overwrite z*", aw_z == dm_z, f"act_wait={aw_z}, direct={dm_z}")

    # 19. compute service time actually occupies DES resource (queueing emerges)
    tiny_trace = pd.DataFrame({"task_id": [0, 1], "arrival_time": [0.0, 0.0],
                                "network_payload_bytes": [500.0, 500.0]})
    orig_num_servers = RESOURCE_TIERS["Edge"]["num_servers"]
    RESOURCE_TIERS["Edge"]["num_servers"] = 1
    global COMPUTE_JITTER_SIGMA
    _orig_sigma = COMPUTE_JITTER_SIGMA
    COMPUTE_JITTER_SIGMA = 0.0
    _orig_cv = globals()["DEMAND_CV"]
    globals()["DEMAND_CV"] = 0.0
    try:
        huge_dt = d_task(500.0, cycles, 1.0e9, lambda_b)
        p_val = p_rev(1, q)

        def _force_edge_decide(payload_bytes, compute_cycles, ss, task_ctx=None):
            return Decision(tier="Edge", z=1, D_task=huge_dt, feasible=True, admitted=True,
                             infeasible_task=False, T_comm=0.0, T_queue=0.0, T_compute=0.0,
                             T_finality_wait=0.0, T_total=0.0, P_rev=p_val, J=0.0)

        lambda_b_for_test = 1.0e6  # negligible finality so it doesn't confound the queueing signal
        _metrics19, out19 = run_experiment(tiny_trace, cycles, _force_edge_decide, lambda_b_for_test,
                                            seed=999, reporting_c_rev=c_rev, q=q, keep_dataframe=True)
    finally:
        RESOURCE_TIERS["Edge"]["num_servers"] = orig_num_servers
        COMPUTE_JITTER_SIGMA = _orig_sigma
        globals()["DEMAND_CV"] = _orig_cv
    both_edge = (out19["selected_tier_code"] == TIER_CODE["Edge"]).sum() == 2 if out19["admitted"].all() else False
    compute_delay = t_compute("Edge", cycles)
    second_delayed = both_edge and (
        out19["realized_T_total"].iloc[1] >= out19["realized_T_total"].iloc[0] + compute_delay - 1e-3)
    _rec(19, "compute service time actually occupies DES resource (queueing emerges)",
         bool(second_delayed), out19[["selected_tier_code", "realized_T_total"]].to_dict("records") if len(out19) else "no admitted tasks")

    # 20. raw Edge-IIoTset data remains unchanged
    src_dataset = inspect.getsource(audit_and_build_trace)
    _rec(20, "raw Edge-IIoTset data remains unchanged (loader never mutates source columns in place)",
         "df[TIMESTAMP_COL] =" not in src_dataset and "df[PAYLOAD_COL] =" not in src_dataset, "")

    # 21. same seed reproduces same stochastic results
    decide_fn21 = faro_decide_factory(q, lambda_b, c_rev, rho_D_val)
    trace2 = pd.DataFrame({"task_id": [0, 1, 2], "arrival_time": [0.0, 0.01, 0.02],
                            "network_payload_bytes": [200.0, 400.0, 800.0]})
    m1, out1 = run_experiment(trace2, cycles, decide_fn21, lambda_b, seed=42, reporting_c_rev=c_rev, q=q,
                               keep_dataframe=True)
    m2, out2 = run_experiment(trace2, cycles, decide_fn21, lambda_b, seed=42, reporting_c_rev=c_rev, q=q,
                               keep_dataframe=True)
    same_df = out1.drop(columns=["decision_time_ms"]).equals(out2.drop(columns=["decision_time_ms"]))
    m1_cmp = {k: v for k, v in m1.items() if k != "M10_mean_decision_time_ms"}
    m2_cmp = {k: v for k, v in m2.items() if k != "M10_mean_decision_time_ms"}

    def _nan_equal(a, b):
        if isinstance(a, dict) and isinstance(b, dict):
            return set(a) == set(b) and all(_nan_equal(a[k], b[k]) for k in a)
        if isinstance(a, float) and isinstance(b, float) and np.isnan(a) and np.isnan(b):
            return True
        return a == b
    same_metrics = _nan_equal(m1_cmp, m2_cmp)
    _rec(21, "same seed reproduces same stochastic results", bool(same_df and same_metrics),
         {} if (same_df and same_metrics) else {k: (m1_cmp.get(k), m2_cmp.get(k))
                                                 for k in set(m1_cmp) | set(m2_cmp)
                                                 if not _nan_equal(m1_cmp.get(k), m2_cmp.get(k))})

    # 22. REAL baseline fairness snapshot equality
    fair_df = run_fairness_audit(out_path="results/_validation_fairness_check.csv")
    _rec(22, "REAL baseline fairness snapshot equality where required",
         fairness_all_pass(fair_df), fair_df.to_dict("records"))
    if os.path.exists("results/_validation_fairness_check.csv"):
        os.remove("results/_validation_fairness_check.csv")

    # 23. M12 numerator/denominator correctness
    agg23 = OnlineAggregator(expected_n=4)
    base_rec = dict(decision_time_ms=0.0, admitted=True, selected_z=1, selected_tier_code=0,
                     P_rev=0.1, expected_reversal_exposure=0.2, predicted_T_comm=0.001,
                     predicted_T_queue=0.0, predicted_T_compute=0.001, predicted_T_finality=0.01)
    recs23 = [
        dict(base_rec, realized_T_total=0.02, realized_deadline_violation=False),
        dict(base_rec, realized_T_total=0.02, realized_deadline_violation=False),
        dict(base_rec, realized_T_total=0.99, realized_deadline_violation=True),
        dict(admitted=False, decision_time_ms=0.0),
    ]
    for r in recs23:
        agg23.add(r)
    m23 = agg23.finalize()
    agg23.close()
    expected_m12 = 100.0 * 1 / 3
    _rec(23, "M12 numerator/denominator correctness",
         m23["M12_n_pred_feasible"] == 3 and m23["M12_n_pred_feasible_realized_violation"] == 1
         and abs(m23["M12_predicted_to_realized_violation_pct"] - expected_m12) < 1e-9, m23)

    # 24. streaming aggregate equals direct aggregate on a small sample
    trace3 = pd.DataFrame({"task_id": list(range(10)), "arrival_time": [i * 0.01 for i in range(10)],
                            "network_payload_bytes": [200.0 + 50 * i for i in range(10)]})
    decide_fn24 = faro_decide_factory(q, lambda_b, c_rev, rho_D_val)
    stream_metrics, df24 = run_experiment(trace3, cycles, decide_fn24, lambda_b, seed=7,
                                           reporting_c_rev=c_rev, q=q, keep_dataframe=True)
    direct_metrics = compute_metrics(df24)
    keys_to_check = ["M1_mean_e2e_latency_s", "M2_p95_e2e_latency_s", "M3_deadline_violation_rate_pct",
                      "M6_mean_selected_z", "M13_admission_rate_pct", "M14_infeasible_rate_pct",
                      "M15_SOCR_tau0.10_pct", "M15_SOCR_tau0.20_pct", "M15_SOCR_tau0.30_pct",
                      "M16_SOCR_req_pct", "M17_ESU", "M18_risk_level_satisfaction_pct",
                      "M19_mean_predicted_P_on_time", "M20_calibration_gap",
                      "M21_SOCR_req_RELAXED_pct", "M21_SOCR_req_STANDARD_pct", "M21_SOCR_req_STRICT_pct"]
    mismatches = {k: (stream_metrics[k], direct_metrics[k]) for k in keys_to_check
                  if not (pd.isna(stream_metrics[k]) and pd.isna(direct_metrics[k]))
                  and abs(stream_metrics[k] - direct_metrics[k]) > 1e-6}
    _rec(24, "streaming aggregate equals direct aggregate on a small sample", len(mismatches) == 0, mismatches)

    # ------------------------------------------------------------------ v3 tests
    # 25. SOCR / ESU / SOCR-req hand-computed on a synthetic 5-task sample
    agg25 = OnlineAggregator(expected_n=5)
    b = dict(decision_time_ms=0.0, admitted=True, selected_tier_code=0, expected_reversal_exposure=0.0,
             predicted_T_comm=0.0, predicted_T_queue=0.0, predicted_T_compute=0.0, predicted_T_finality=0.0,
             realized_T_total=0.1)
    recs25 = [
        dict(b, selected_z=1, P_rev=0.30, tau_req=0.30, risk_class=0, realized_deadline_violation=False, P_on_time_pred=0.9),
        dict(b, selected_z=2, P_rev=0.12, tau_req=0.10, risk_class=2, realized_deadline_violation=False, P_on_time_pred=0.8),
        dict(b, selected_z=3, P_rev=0.05, tau_req=0.10, risk_class=2, realized_deadline_violation=True,  P_on_time_pred=0.7),
        dict(b, selected_z=3, P_rev=0.05, tau_req=0.20, risk_class=1, realized_deadline_violation=False, P_on_time_pred=0.6),
        dict(admitted=False, decision_time_ms=0.0, risk_class=1),
    ]
    for r in recs25:
        agg25.add(r)
    m25 = agg25.finalize(); agg25.close()
    exp = dict(socr10=100.0 * 1 / 5, socr20=100.0 * 2 / 5, socr30=100.0 * 3 / 5,
               socr_req=100.0 * 2 / 5, esu=(0.70 + 0.88 + 0.95) / 5, rls=100.0 * 3 / 4,
               pon=(0.9 + 0.8 + 0.7 + 0.6) / 4, gap=(3 / 4) - (0.9 + 0.8 + 0.7 + 0.6) / 4,
               strict=100.0 * 0 / 2, standard=100.0 * 1 / 2, relaxed=100.0)
    got = dict(socr10=m25["M15_SOCR_tau0.10_pct"], socr20=m25["M15_SOCR_tau0.20_pct"], socr30=m25["M15_SOCR_tau0.30_pct"],
               socr_req=m25["M16_SOCR_req_pct"], esu=m25["M17_ESU"], rls=m25["M18_risk_level_satisfaction_pct"],
               pon=m25["M19_mean_predicted_P_on_time"], gap=m25["M20_calibration_gap"],
               strict=m25["M21_SOCR_req_STRICT_pct"], standard=m25["M21_SOCR_req_STANDARD_pct"],
               relaxed=m25["M21_SOCR_req_RELAXED_pct"])
    bad25 = {k: (got[k], exp[k]) for k in exp if abs(got[k] - exp[k]) > 1e-9}
    _rec(25, "SOCR(tau)/SOCR-req/ESU/risk-satisfaction/calibration-gap match hand computation", not bad25, bad25)

    # 26. Erlang CDF table matches scipy and the z_required rule is correct
    from scipy.stats import gamma as _g
    tab26 = erlang_table()
    ts = np.array([0.0, 0.05, 0.4, 1.0, 2.5, 7.0, 30.0])
    ref = np.stack([_g.cdf(ts, a=z, scale=1.0 / lambda_b) for z in range(Z_MIN, Z_MAX + 1)])
    err26 = float(np.max(np.abs(tab26.cdf(lambda_b, ts)[:ref.shape[0]] - ref)))
    zr = [z_required(t, 0.15) for t in (0.30, 0.20, 0.10, 1e-9)]  # reference values at the nominal q=0.15
    zr_ok = zr[0] == 1 and zr[1] == 2 and zr[2] == 3 and zr[3] is None
    _rec(26, "Erlang finality CDF table matches scipy (<2e-3) and z_required(tau) correct",
         err26 < 2e-3 and zr_ok and tab26.cdf(lambda_b, np.array([-1.0]))[0, 0] == 0.0,
         f"max_abs_err={err26:.2e}, z_required={zr}")

    # 27. FARO-IoT never admits a task above its required risk level; FARO-NoTau may
    ss27 = _dummy_sim_state()
    dec27, _ = faro3_decide_factory(q, lambda_b, c_rev, rho_D_val)
    viol27 = []
    for rc in range(len(RISK_CLASSES)):
        ctx = make_task_ctx(500.0, cycles, rc, rho_D_val, lambda_b, q)
        d = dec27(500.0, cycles, ss27, ctx)
        if d.admitted and d.P_rev > ctx.tau + 1e-12:
            viol27.append((RISK_CLASS_NAMES[rc], d.z, d.P_rev))
    _rec(27, "FARO-IoT admitted decisions always satisfy P_rev <= tau_i (hard constraint)", not viol27, viol27)

    # 28. D_i identical across algorithms for the same task profile (fairness of the profile)
    ctx28 = make_task_ctx(500.0, cycles, RISK_CLASS_CODE["STRICT"], rho_D_val, lambda_b, q)
    dts = {}
    for algo in ALGORITHMS:
        fn, _ = _decide_fn_for(algo, q, lambda_b, c_rev, rho_D_val)
        dts[algo] = fn(500.0, cycles, _dummy_sim_state(), ctx28).D_task
    _rec(28, "D_i read from the shared task profile is identical for every algorithm",
         len(set(round(v, 12) for v in dts.values())) == 1, dts)

    # 29. Utility monotonicity: larger beta never increases admission (empty queue, STANDARD)
    ss29 = _dummy_sim_state()
    ctx29 = make_task_ctx(500.0, cycles, RISK_CLASS_CODE["STANDARD"], rho_D_val, lambda_b, q)
    us = [esu_optimize(500.0, cycles, ctx29, q, lambda_b, c_rev, bb, ss29).U for bb in (0.0, 1.0, 4.0)]
    us = [(-np.inf if u is None else u) for u in us]
    _rec(29, "Expected safe utility is non-increasing in the miss penalty beta", us[0] >= us[1] >= us[2], us)

    # 30. Online calibrator: residual quantile points move the on-time probability the right way
    cal30 = OnlineResidualCalibrator(window=64, refresh_every=1, min_samples=1)
    for _ in range(40):
        cal30.update("Edge", True, dict(realized_T_queue=0.5, predicted_T_queue=0.0))  # queue underestimated by 0.5s
    d_uncal = esu_optimize(500.0, cycles, ctx29, q, lambda_b, c_rev, 1.0, _dummy_sim_state(), calibrator=None, tiers=["Edge"])
    d_cal = esu_optimize(500.0, cycles, ctx29, q, lambda_b, c_rev, 1.0, _dummy_sim_state(), calibrator=cal30, tiers=["Edge"])
    p_u = d_uncal.P_on_time if d_uncal.P_on_time is not None else 0.0
    p_c = d_cal.P_on_time if d_cal.P_on_time is not None else 0.0
    _rec(30, "Positive queue residuals lower the calibrated on-time probability", p_c < p_u,
         f"uncalibrated={p_u:.4f}, calibrated={p_c:.4f}")

    # 31. Risk-class assignment is seed-keyed CRN (same across algorithms, differs across seeds, shares ~ nominal)
    a1, a2, b1 = assign_risk_classes(20000, 1), assign_risk_classes(20000, 1), assign_risk_classes(20000, 2)
    shares = np.bincount(a1, minlength=len(RISK_CLASSES)) / len(a1)
    share_ok = all(abs(shares[i] - RISK_CLASSES[i]["share"]) < 0.02 for i in range(len(RISK_CLASSES)))
    _rec(31, "Risk classes: identical for identical seed, differ across seeds, empirical shares within 2pp",
         bool(np.array_equal(a1, a2) and not np.array_equal(a1, b1) and share_ok), shares.tolist())

    # ------------------------------------------------------------------ v4 tests
    global DEADLINE_MODE
    # 32. On-time truncated expectation E[T_fin 1(T_fin<=s)] = (z/lambda) F_{z+1}(s)  vs Monte Carlo
    rng32 = np.random.default_rng(32)
    ok32, det32 = True, []
    for zz, ss in [(1, 0.4), (3, 1.7), (6, 3.5)]:
        smp = rng32.gamma(zz, 1.0 / lambda_b, 400_000)
        mc = float(np.mean(smp * (smp <= ss)))
        tab32 = erlang_table()
        cf = (zz / lambda_b) * float(tab32.cdf(lambda_b, np.array([ss]))[zz + 1 - tab32.z_min, 0])
        det32.append((zz, ss, round(mc, 4), round(cf, 4)))
        ok32 &= abs(mc - cf) < 5e-3
    _rec(32, "On-time truncated expectation of confirmation time matches Monte Carlo", ok32, det32)

    # 33. Shared chain: marginal finality mean = z/lambda; capacity forces distinct inclusion blocks
    ch = SharedBlockChain(seed=33, lambda_b=lambda_b)
    subs = np.sort(np.random.default_rng(33).uniform(0, 20000, 20000))
    fins = np.array([ch.finality(t, 3) for t in subs])
    mean_ok = abs(fins.mean() - 3 / lambda_b) / (3 / lambda_b) < 0.03
    ch2 = SharedBlockChain(seed=34, lambda_b=lambda_b, capacity=1)
    f5 = [ch2.finality(10.0, 1) for _ in range(5)]
    cap_ok = len(set(np.round(f5, 9))) == 5 and all(np.diff(f5) > 0)
    _rec(33, "Shared block chain: Erlang marginal (mean within 3%) and block capacity respected",
         bool(mean_ok and cap_ok), f"mean={fins.mean():.4f} vs {3 / lambda_b:.4f}; cap1 finality={np.round(f5, 3).tolist()}")

    # 34. Separability: with the uncalibrated estimator the chosen tier is the fastest predicted tier
    rng34 = np.random.default_rng(34)
    # Lemma condition: tier-uniform penalty (fixed beta). The load-aware penalty deliberately
    # breaks tier-uniformity so that a less-loaded slower tier can win; it is tested by 37.
    fn34 = faro3_decide_factory(q, lambda_b, c_rev, rho_D_val, beta=BETA_MISS, calibrate=False,
                                enforce_tau=True, penalty_mode="fixed")[0]
    viol34 = 0; n34 = 0
    for _ in range(300):
        ss34 = _dummy_sim_state()
        for t in TIER_NAMES:
            ss34[t]["inflight"] = int(rng34.integers(0, 4 * RESOURCE_TIERS[t]["num_servers"]))
        cyc = float(rng34.choice([WORKLOADS["LIGHT"], WORKLOADS["MEDIUM"], WORKLOADS["HEAVY"]]))
        L = float(rng34.uniform(0, 2000))
        ctx34 = make_task_ctx(L, cyc, int(rng34.integers(0, len(RISK_CLASSES))), rho_D_val, lambda_b, q)
        d34 = fn34(L, cyc, ss34, ctx34)
        if d34.admitted:
            n34 += 1
            pre = {t: t_comm(t, L) + t_queue_snapshot(t, ss34) + t_compute(t, cyc) for t in TIER_NAMES}
            if pre[d34.tier] > min(pre.values()) + 1e-12:
                viol34 += 1
    _rec(34, "Tier choice separates (tier-uniform beta): admitted decisions always use the fastest predicted tier",
         viol34 == 0 and n34 > 0, f"admitted={n34}, non-fastest={viol34}")

    # 37. Congestion-attributable penalty: idle tiers -> identical to beta = 0; in general its admission
    #     set is sandwiched between fixed beta (subset) and beta = 0 (superset).
    fC = faro3_decide_factory(q, lambda_b, c_rev, rho_D_val, beta=BETA_MISS, calibrate=False,
                              enforce_tau=True, min_depth_only=True, penalty_mode="congestion")[0]
    fF = faro3_decide_factory(q, lambda_b, c_rev, rho_D_val, beta=BETA_MISS, calibrate=False,
                              enforce_tau=True, min_depth_only=True, penalty_mode="fixed")[0]
    f0 = faro3_decide_factory(q, lambda_b, c_rev, rho_D_val, beta=0.0, calibrate=False,
                              enforce_tau=True, min_depth_only=True, penalty_mode="fixed")[0]
    rng37 = np.random.default_rng(37); bad37 = []
    for _ in range(300):
        cyc = float(rng37.choice([WORKLOADS["LIGHT"], WORKLOADS["MEDIUM"], WORKLOADS["HEAVY"]]))
        L = float(rng37.uniform(0, 2000))
        ctx37 = make_task_ctx(L, cyc, int(rng37.integers(0, len(RISK_CLASSES))),
                              rho_D_val * float(rng37.uniform(0.3, 1.5)), lambda_b, q)
        idle = _dummy_sim_state()
        for t in TIER_NAMES:
            idle[t]["inflight"] = 0
        busy = _dummy_sim_state()
        for t in TIER_NAMES:
            busy[t]["inflight"] = int(rng37.integers(0, 6 * RESOURCE_TIERS[t]["num_servers"]))
        a, b = fC(L, cyc, idle, ctx37), f0(L, cyc, idle, ctx37)
        if (a.admitted, a.tier) != (b.admitted, b.tier):
            bad37.append(("idle", a.admitted, b.admitted))
        c_, f_, z_ = fC(L, cyc, busy, ctx37), fF(L, cyc, busy, ctx37), f0(L, cyc, busy, ctx37)
        if (f_.admitted and not c_.admitted) or (c_.admitted and not z_.admitted):
            bad37.append(("sandwich", f_.admitted, c_.admitted, z_.admitted))
    _rec(37, "Congestion penalty: equals beta=0 on idle tiers; admission set between fixed-beta and beta=0",
         not bad37, bad37[:5])

    # 38. v5 baselines: SafeSlack admits iff predicted slack > 0; masked TS (full depths) has a feasible
    #     arm for every stringent class; heterogeneous demand has mean equal to the workload demand.
    fS = safe_admission_decide_factory(q, lambda_b, rho_D_val, "slack")
    bad38 = []
    ss38 = _dummy_sim_state()
    for t in TIER_NAMES:
        ss38[t]["inflight"] = 0
    for rhoscale in (0.05, 0.5, 2.0):
        ctx38 = make_task_ctx(500.0, cycles, 1, rho_D_val * rhoscale, lambda_b, q)
        d38 = fS(500.0, cycles, ss38, ctx38)
        pre = min(t_comm(t, 500.0) + t_queue_snapshot(t, ss38) + t_compute(t, cycles) for t in TIER_NAMES)
        if d38.admitted != (ctx38.D_task - pre > 0):
            bad38.append(("slack", rhoscale))
    ts38 = TSBanditPolicy(q, lambda_b, rho_D_val, 1, risk_mask=True, arm_depths=list(range(Z_MIN, Z_MAX + 1)))
    for tau in (1e-2, 1e-3, 1e-4):
        # only risk levels that some depth up to Z_MAX can meet at this q (none exists for 1e-4 at q=0.25)
        feasible = any(p_rev(z, q) <= tau for z in range(Z_MIN, Z_MAX + 1))
        if feasible and not any(p_rev(z, q) <= tau for (_, z) in ts38.arms):
            bad38.append(("ts_arms", tau))
    _dcv = globals()["DEMAND_CV"]
    globals()["DEMAND_CV"] = 0.5
    try:
        mu = float(np.mean([task_demand_cycles(1e8, 3, i) for i in range(4000)])) / 1e8
    finally:
        globals()["DEMAND_CV"] = _dcv
    if abs(mu - 1.0) > 0.03:
        bad38.append(("demand_mean", mu))
    _rec(38, "v5 baselines and heterogeneous demand behave as specified", not bad38, bad38)

    # 39. v6: externality toll and work-weighted queue estimate
    bad39 = []
    ss39 = make_sim_state(simpy.Environment(), 500.0, cycles)
    ctx39 = make_task_ctx(500.0, cycles, 1, rho_D_val * 3.0, lambda_b, q)
    base39 = esu_optimize(500.0, cycles, ctx39, q, lambda_b, c_rev, BETA_MISS, ss39, penalty_mode="congestion")
    tol39 = esu_optimize(500.0, cycles, ctx39, q, lambda_b, c_rev, BETA_MISS, ss39, penalty_mode="congestion",
                         ext_eta=4.0, inv_d_mean=1.0 / ctx39.D_task)
    if base39.admitted != tol39.admitted or (base39.U is not None and abs(base39.U - tol39.U) > 1e-12):
        bad39.append(("idle_toll_nonzero", base39.U, tol39.U))      # idle tiers: toll must vanish
    tolls = []
    for mult in (1, 2, 4):
        for t in TIER_NAMES:
            m_ = RESOURCE_TIERS[t]["num_servers"]
            ss39[t]["inflight"] = mult * 2 * m_
            ss39[t]["work_cycles"] = float(mult * 2 * m_ * cycles)
        u0 = esu_optimize(500.0, cycles, ctx39, q, lambda_b, c_rev, BETA_MISS, ss39, penalty_mode="congestion",
                          tiers=["Cloud"])
        u1 = esu_optimize(500.0, cycles, ctx39, q, lambda_b, c_rev, BETA_MISS, ss39, penalty_mode="congestion",
                          tiers=["Cloud"], ext_eta=1.0, inv_d_mean=1.0 / ctx39.D_task)
        a0 = u0.U if u0.U is not None else float("nan")
        a1 = u1.U if u1.U is not None else float("nan")
        tolls.append(a0 - a1)
    if not (np.all(np.isfinite(tolls)) and tolls[0] > 0 and tolls[0] < tolls[1] < tolls[2]):
        bad39.append(("toll_not_increasing", tolls))
    _dcv, _qe = globals()["DEMAND_CV"], globals()["QUEUE_EST"]
    globals()["DEMAND_CV"], globals()["QUEUE_EST"] = 0.5, "work"
    try:
        wq = t_queue_snapshot("Cloud", ss39)       # homogeneous committed work -> count formula
    finally:
        globals()["DEMAND_CV"], globals()["QUEUE_EST"] = _dcv, _qe
    cq = t_queue_snapshot("Cloud", ss39)
    if abs(wq - cq) > 1e-9 * max(1.0, cq):
        bad39.append(("work_vs_count", wq, cq))
    _rec(39, "v6 toll vanishes on idle tiers, grows with backlog; work estimate = count estimate for equal demands",
         not bad39, bad39)

    # 40. v7: WorkCap excludes a loaded tier; size-free deadlines do not depend on the task's own demand
    bad40 = []
    ss40 = make_sim_state(simpy.Environment(), 500.0, cycles)
    fW = safe_admission_decide_factory(q, lambda_b, rho_D_val, "workcap", 2.0)
    ctx40 = make_task_ctx(500.0, cycles, 1, rho_D_val * 50.0, lambda_b, q)
    if not fW(500.0, cycles, ss40, ctx40).admitted:
        bad40.append("idle_reject")
    for t in TIER_NAMES:
        m_ = RESOURCE_TIERS[t]["num_servers"]
        ss40[t]["inflight"] = 4 * m_
        ss40[t]["work_cycles"] = float(4 * m_ * cycles)
    d40 = fW(500.0, cycles, ss40, ctx40)
    if d40.admitted:
        bad40.append(("loaded_admit", d40.tier))
    _odm = globals()["DEADLINE_MODE"]
    globals()["DEADLINE_MODE"] = "sizefree"
    try:
        da = make_task_ctx(500.0, cycles, 1, rho_D_val, lambda_b, q, fin_budget=1.0, nominal_cycles=cycles).D_task
        db = make_task_ctx(500.0, 4 * cycles, 1, rho_D_val, lambda_b, q, fin_budget=1.0, nominal_cycles=cycles).D_task
    finally:
        globals()["DEADLINE_MODE"] = _odm
    if abs(da - db) > 1e-12:
        bad40.append(("sizefree", da, db))
    _rec(40, "v7 WorkCap rejects on a loaded tier and admits on idle tiers; size-free deadlines ignore own demand",
         not bad40, bad40)

    # 35. Independent deadline mode: D_i does not depend on the risk class
    _orig_dm = DEADLINE_MODE
    DEADLINE_MODE = "independent"
    try:
        ds = {make_task_ctx(500.0, cycles, k, rho_D_val, lambda_b, q, fin_budget=1.3).D_task for k in range(len(RISK_CLASSES))}
    finally:
        DEADLINE_MODE = _orig_dm
    _rec(35, "Independent deadline mode: D_i identical across risk classes for the same budget", len(ds) == 1, ds)

    # 36. q_true evaluation equals the nominal metric when no mismatch is configured
    fn36, post36 = _decide_fn_for("FARO-IoT", q, lambda_b, c_rev, rho_D_val, beta=BETA_MISS)
    m36, _ = run_experiment(trace3, cycles, fn36, lambda_b, seed=36, reporting_c_rev=c_rev, q=q, post_update_fn=post36)
    _rec(36, "Risk-model-mismatch metric equals nominal SOCR_req when q_true = q",
         (Q_TRUE is not None and Q_TRUE != q) or abs(m36["M25_SOCR_req_qtrue_pct"] - m36["M16_SOCR_req_pct"]) < 1e-9,
         (m36["M25_SOCR_req_qtrue_pct"], m36["M16_SOCR_req_pct"]))

    return pd.DataFrame(_RECORDS)


CRITICAL_TEST_IDS = {1, 2, 3, 4, 6, 7, 8, 10, 11, 12, 14, 15, 16, 17, 18, 19, 21, 23, 24, 25, 26, 27, 28, 29, 30, 31,
                     32, 33, 34, 35, 36, 37, 38, 39, 40}


def has_critical_failure(results_df: pd.DataFrame) -> bool:
    crit = results_df[results_df["test_id"].isin(CRITICAL_TEST_IDS)]
    return bool((crit["status"] == "FAIL").any())


# =============================================================================
# SECTION 16: PLOTTING — publication-quality PNG (300dpi) + PDF figures
# =============================================================================
MAIN_ALGOS = ["FARO-IoT", "RTD-adapted", "FixedDepth-2", "TS-Bandit-masked", "TS-Bandit-adapted", "FARO-v2",
              "Fang et al.-adapted", "SharpEdge-adapted"]
ABLATION_ALGOS = ["FARO-IoT", "FARO-IoT+Cal", "FARO-IoT-FixedPenalty", "FARO-IoT-NoPenalty", "FARO-IoT-D", "RTD-adapted", "FARO-v2",
                  "FARO-NoRisk"]


def _save(fig, name, out_dir=FIGURES_DIR):
    os.makedirs(out_dir, exist_ok=True)
    fig.savefig(os.path.join(out_dir, f"{name}.png"), dpi=300, bbox_inches="tight")
    fig.savefig(os.path.join(out_dir, f"{name}.pdf"), bbox_inches="tight")
    plt.close(fig)


def _grouped_bar(stats, metric, title, ylabel, name, algos=None, err_metric_suffix="__ci95"):
    algos = algos or MAIN_ALGOS
    workloads = WORKLOAD_NAMES
    fig, ax = plt.subplots(figsize=(7, 4.5))
    x = np.arange(len(workloads))
    width = 0.8 / max(len(algos), 1)
    mean_col, err_col = f"{metric}__mean", f"{metric}{err_metric_suffix}"
    any_data = False
    for i, algo in enumerate(algos):
        means, errs = [], []
        for w in workloads:
            row = stats[(stats["algorithm"] == algo) & (stats["workload"] == w)]
            if len(row) and mean_col in row.columns and not pd.isna(row[mean_col].iloc[0]):
                means.append(row[mean_col].iloc[0]); errs.append(row[err_col].iloc[0]); any_data = True
            else:
                means.append(0.0); errs.append(0.0)
        ax.bar(x + i * width, means, width=width, yerr=errs, capsize=3, label=algo)
    if not any_data:
        ax.text(0.5, 0.5, "No data available for this metric", ha="center", va="center", transform=ax.transAxes)
    ax.set_xticks(x + width * (len(algos) - 1) / 2)
    ax.set_xticklabels(workloads)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend(fontsize=8)
    fig.tight_layout()
    _save(fig, name)


def fig1_latency(stats): _grouped_bar(stats, "M1_mean_e2e_latency_s", "Mean E2E Latency", "seconds", "fig1_mean_latency")
def fig2_p95_latency(stats): _grouped_bar(stats, "M2_p95_e2e_latency_s", "P95 E2E Latency", "seconds", "fig2_p95_latency")
def fig3_deadline_violation(stats): _grouped_bar(stats, "M3_deadline_violation_rate_pct", "Deadline Violation Rate", "%", "fig3_deadline_violation")
def fig4_reversal_exposure(stats): _grouped_bar(stats, "M5_mean_expected_reversal_exposure", "Expected Reversal Exposure", "C_rev * P_rev", "fig4_reversal_exposure")
def fig5_selected_z(stats): _grouped_bar(stats, "M6_mean_selected_z", "Mean Selected Confirmation Depth z", "z", "fig5_mean_z")
def fig12_admission(stats): _grouped_bar(stats, "M13_admission_rate_pct", "Admission Rate", "%", "fig12_admission_rate")


def fig6_placement(table3):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    if len(table3) == 0:
        ax.text(0.5, 0.5, "No admitted tasks — placement undefined", ha="center", va="center")
    else:
        agg = table3.groupby("algorithm")[["Edge_pct", "Fog_pct", "Cloud_pct"]].mean()
        agg.plot(kind="bar", stacked=True, ax=ax)
    ax.set_ylabel("%"); ax.set_title("Edge/Fog/Cloud Placement Distribution")
    fig.tight_layout()
    _save(fig, "fig6_placement_distribution")


def _sensitivity_line(df, param_col, metric, title, ylabel, name):
    fig, ax = plt.subplots(figsize=(6, 4))
    if df is None or len(df) == 0 or metric not in df.columns:
        ax.text(0.5, 0.5, "Sensitivity grid missing", ha="center", va="center")
    else:
        g = df.groupby(param_col)[metric].agg(["mean", "std", "count"]).reset_index()
        ci95 = 1.96 * g["std"] / np.sqrt(g["count"].clip(lower=1))
        ax.errorbar(g[param_col], g["mean"], yerr=ci95, marker="o", capsize=3)
    ax.set_xlabel(param_col); ax.set_ylabel(ylabel); ax.set_title(title)
    fig.tight_layout()
    _save(fig, name)


def fig7_crev_sensitivity(df): _sensitivity_line(df, "c_rev", "M6_mean_selected_z", "C_rev Sensitivity", "Mean z", "fig7_crev_sensitivity")
def fig8_q_sensitivity(df): _sensitivity_line(df, "q", "M4_mean_reversal_probability", "q Sensitivity", "Mean P_rev", "fig8_q_sensitivity")
def fig9_lambda_sensitivity(df): _sensitivity_line(df, "lambda_b", "M13_admission_rate_pct", "lambda_b Sensitivity", "Admission %", "fig9_lambda_sensitivity")
def fig10_rhod_sensitivity(df): _sensitivity_line(df, "rho_D", "M13_admission_rate_pct", "rho_D Sensitivity", "Admission %", "fig10_rhod_sensitivity")


def fig11_predicted_vs_realized(stats):
    fig, ax = plt.subplots(figsize=(6, 5))
    algos = MAIN_ALGOS
    xs = stats[stats["algorithm"].isin(algos)]["M12_predicted_to_realized_violation_pct__mean"]
    ys = stats[stats["algorithm"].isin(algos)]["M3_deadline_violation_rate_pct__mean"]
    if len(xs) == 0:
        ax.text(0.5, 0.5, "No data available", ha="center", va="center")
    else:
        ax.scatter(xs, ys)
        lim = [0, max(1.0, float(np.nanmax([xs.max(), ys.max()])))]
        ax.plot(lim, lim, linestyle="--", color="gray")
    ax.set_xlabel("Predicted-feasible -> realized violation (%)")
    ax.set_ylabel("Realized deadline violation (%)")
    ax.set_title("Predicted vs Realized Deadline Violations")
    fig.tight_layout()
    _save(fig, "fig11_predicted_vs_realized")


# --- v3 figures ---------------------------------------------------------------
def fig13_socr_req(stats):
    _grouped_bar(stats, "M16_SOCR_req_pct", "Safe On-Time Completion Rate (required tau_i)", "SOCR-req (%)",
                 "fig13_socr_req", algos=MAIN_ALGOS)


def fig14_socr_req_ablation(stats):
    _grouped_bar(stats, "M16_SOCR_req_pct", "SOCR-req — ablations", "SOCR-req (%)",
                 "fig14_socr_req_ablation", algos=[a for a in ABLATION_ALGOS if a in set(stats["algorithm"])])


def fig15_esu(stats):
    _grouped_bar(stats, "M17_ESU", "Expected Safe Utility", "ESU", "fig15_esu", algos=MAIN_ALGOS)


def fig16_socr_curve(seed_level_df, workload="MEDIUM"):
    """SOCR(tau) as a continuous curve, reconstructed exactly from the
    on-time counts keyed by P_rev value (mean over seeds)."""
    import ast
    fig, ax = plt.subplots(figsize=(6.5, 4.2))
    taus = np.linspace(0.0, 0.5, 251)
    sub = seed_level_df[seed_level_df["workload"] == workload]
    plotted = False
    for algo in MAIN_ALGOS + [a for a in ABLATION_ALGOS if a not in MAIN_ALGOS]:
        g = sub[sub["algorithm"] == algo]
        if not len(g):
            continue
        curves = []
        for _, r in g.iterrows():
            counts = r.get("M15_SOCR_curve_ontime_counts_by_Prev", {})
            if isinstance(counts, str):
                counts = ast.literal_eval(counts)
            counts = {float(k): int(v) for k, v in (counts or {}).items()}
            n = int(r["n_tasks"])
            curves.append([socr_curve_from_counts(counts, n, [t])[float(t)] for t in taus])
        ax.plot(taus, np.mean(curves, axis=0), label=algo,
                linestyle="-" if algo in MAIN_ALGOS else "--", linewidth=1.6 if algo == "FARO-IoT" else 1.1)
        plotted = True
    for t in SOCR_TAUS:
        ax.axvline(t, color="gray", linestyle=":", linewidth=0.8)
    if not plotted:
        ax.text(0.5, 0.5, "No data", ha="center", va="center", transform=ax.transAxes)
    ax.set_xlabel("acceptable reversal risk tau"); ax.set_ylabel("SOCR(tau) (%)")
    ax.set_title(f"SOCR across risk thresholds — {workload}")
    ax.legend(fontsize=7); fig.tight_layout()
    _save(fig, f"fig16_socr_curve_{workload}")


def fig17_beta_sensitivity(df):
    fig, ax = plt.subplots(figsize=(6, 4))
    if df is None or len(df) == 0:
        ax.text(0.5, 0.5, "Sensitivity grid missing", ha="center", va="center")
    else:
        for metric, lab in [("M16_SOCR_req_pct", "SOCR-req (%)"), ("M13_admission_rate_pct", "Admission (%)"),
                            ("M3_deadline_violation_rate_pct", "Violation (%)")]:
            g = df.groupby("beta_miss")[metric].agg(["mean", "std", "count"]).reset_index()
            ax.errorbar(g["beta_miss"], g["mean"], yerr=1.96 * g["std"] / np.sqrt(g["count"].clip(lower=1)),
                        marker="o", capsize=3, label=lab)
        ax.legend(fontsize=8)
    ax.set_xlabel("beta (deadline-miss penalty)"); ax.set_ylabel("%"); ax.set_title("beta Sensitivity (FARO-IoT)")
    fig.tight_layout(); _save(fig, "fig17_beta_sensitivity")


def fig18_calibration(stats):
    fig, ax = plt.subplots(figsize=(5.5, 5))
    algos = ["FARO-IoT", "FARO-IoT+Cal", "FARO-IoT-D"]
    sub = stats[stats["algorithm"].isin(algos)]
    if "M19_mean_predicted_P_on_time__mean" not in sub.columns or len(sub) == 0:
        ax.text(0.5, 0.5, "No data", ha="center", va="center")
    else:
        for algo in algos:
            s = sub[sub["algorithm"] == algo]
            x = s["M19_mean_predicted_P_on_time__mean"]
            y = 1.0 - s["M3_deadline_violation_rate_pct__mean"] / 100.0
            ax.scatter(x, y, label=algo)
            for _, r in s.iterrows():
                ax.annotate(r["workload"], (r["M19_mean_predicted_P_on_time__mean"],
                                            1.0 - r["M3_deadline_violation_rate_pct__mean"] / 100.0), fontsize=7)
        ax.plot([0, 1], [0, 1], "--", color="gray"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
        ax.legend(fontsize=8)
    ax.set_xlabel("mean predicted P_on (admitted)"); ax.set_ylabel("realized on-time rate (admitted)")
    ax.set_title("On-time probability calibration"); fig.tight_layout()
    _save(fig, "fig18_calibration")


def generate_all_figures(stats, table3, sweeps, seed_level_df=None, sweeps_by_wl=None):
    fig1_latency(stats); fig2_p95_latency(stats); fig3_deadline_violation(stats)
    fig4_reversal_exposure(stats); fig5_selected_z(stats); fig6_placement(table3)
    fig7_crev_sensitivity(sweeps.get("c_rev")); fig8_q_sensitivity(sweeps.get("q"))
    fig9_lambda_sensitivity(sweeps.get("lambda_b")); fig10_rhod_sensitivity(sweeps.get("rho_D"))
    fig11_predicted_vs_realized(stats); fig12_admission(stats)
    fig13_socr_req(stats); fig14_socr_req_ablation(stats); fig15_esu(stats)
    if seed_level_df is not None and len(seed_level_df):
        for w in WORKLOAD_NAMES:
            if (seed_level_df["workload"] == w).any():
                fig16_socr_curve(seed_level_df, w)
    fig17_beta_sensitivity(sweeps.get("beta_miss")); fig18_calibration(stats)
    for wl, sw in (sweeps_by_wl or {}).items():
        fig17_beta_sensitivity_wl(sw.get("beta_miss"), wl)


def fig17_beta_sensitivity_wl(df, wl):
    fig, ax = plt.subplots(figsize=(6, 4))
    if df is None or len(df) == 0:
        ax.text(0.5, 0.5, "Sensitivity grid missing", ha="center", va="center")
    else:
        for metric, lab in [("M16_SOCR_req_pct", "SOCR-req (%)"), ("M13_admission_rate_pct", "Admission (%)"),
                            ("M3_deadline_violation_rate_pct", "Violation (%)")]:
            g = df.groupby("beta_miss")[metric].agg(["mean", "std", "count"]).reset_index()
            ax.errorbar(g["beta_miss"], g["mean"], yerr=1.96 * g["std"] / np.sqrt(g["count"].clip(lower=1)),
                        marker="o", capsize=3, label=lab)
        ax.legend(fontsize=8)
    ax.set_xlabel("beta (deadline-miss penalty)"); ax.set_ylabel("%"); ax.set_title(f"beta Sensitivity (FARO-IoT, {wl})")
    fig.tight_layout(); _save(fig, f"fig17_beta_sensitivity_{wl}")


# =============================================================================
# SECTION 17: FINAL REPORT
# =============================================================================
def write_final_report(audit, val_df, fair_df, seed_level_df, stats, runtime_seconds,
                        debug_tasks, out_path: str = "FINAL_EXPERIMENT_REPORT.md") -> None:
    lines = []
    a = lines.append
    a("# FARO-IoT — Final Experiment Report\n")
    a(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}\n")
    a("## 1. Dataset Audit\n")
    a(f"- Source: `{audit.path}` (SHA-256 `{audit.sha256[:16]}...`)")
    a(f"- Raw rows: {audit.raw_rows:,} | Valid-timestamp rows: {audit.valid_timestamp_rows:,} "
      f"| Invalid: {audit.invalid_timestamp_rows:,}")
    a(f"- Final task count used: {audit.final_task_count:,}"
      + (f" (debug-tasks={debug_tasks} subset applied)" if debug_tasks else ""))
    a(f"- Trace duration: {audit.trace_duration_s:.3f} s | Mean arrival rate: "
      f"{audit.mean_arrival_rate_tasks_per_s:.4f} tasks/s")
    a(f"- Payload (tcp.len) bytes: mean={audit.payload_mean:.2f}, median={audit.payload_median:.2f}, "
      f"std={audit.payload_std:.2f}, missing={audit.payload_missing}\n")
    a("## 2. Experimental Configuration (FROZEN)\n")
    a(f"- Algorithms: {ALGORITHMS}")
    a(f"- Workloads: {WORKLOAD_NAMES} (compute_demand_cycles = {WORKLOADS})")
    a(f"- Seeds: {SEEDS}")
    a(f"- q={DEFAULT_Q}, lambda_b={DEFAULT_LAMBDA_B}, C_rev={DEFAULT_C_REV}, "
      f"rho_D={RHO_D}, Z range=[{Z_MIN},{Z_MAX}]")
    a(f"- v3: beta_miss={BETA_MISS}, risk classes={[(rc['name'], rc['share'], rc['tau'], rc['chi']) for rc in RISK_CLASSES]}, "
      f"calibration window={CAL_WINDOW}, quantile levels={CAL_QUANTILE_LEVELS}\n")
    a("## 3. Parameter Provenance\n")
    a("See `results/provenance_table_final.csv`.\n")
    a("## 4. Validation Tests\n")
    n_pass = int((val_df["status"] == "PASS").sum()); n_total = len(val_df)
    a(f"{n_pass}/{n_total} tests passed.")
    fails = val_df[val_df["status"] == "FAIL"]
    if len(fails):
        a("**FAILED tests:**")
        for _, r in fails.iterrows():
            a(f"- Test {r['test_id']}: {r['test_name']} — {r['details']}")
    a("")
    a("## 5. Fairness Audit\n")
    n_fair_pass = int((fair_df["status"] == "PASS").sum()) if "status" in fair_df.columns else int((fair_df["PASS/FAIL"] == "PASS").sum())
    a(f"{n_fair_pass}/{len(fair_df)} fairness checks passed.\n")
    a("## 6-9. FARO / Baseline / Ablation / Sensitivity Results\n")
    if len(seed_level_df):
        a("Seed-level: `results/final_results_by_seed.csv`. Mean/std/CI: `results/final_results_mean_std_ci.csv`. "
          "Tables: `results/TABLE_1_main_comparison.csv` .. `TABLE_7_risk_classes.csv`.\n")
        a("### Headline (v3 study-proposed metrics, mean over seeds)\n")
        a("| workload | algorithm | SOCR-req % | SOCR(0.10) | SOCR(0.20) | SOCR(0.30) | ESU | on-time % (M9) | "
          "mean lat. s | viol. % | adm. % | mean z | mean P_rev |")
        a("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
        for _, r in stats.sort_values(["workload", "M16_SOCR_req_pct__mean"], ascending=[True, False]).iterrows():
            def _f(k, d=2):
                v = r.get(k, float("nan"))
                return "n/a" if pd.isna(v) else f"{v:.{d}f}"
            a(f"| {r['workload']} | {r['algorithm']} | {_f('M16_SOCR_req_pct__mean')} | "
              f"{_f('M15_SOCR_tau0.10_pct__mean')} | {_f('M15_SOCR_tau0.20_pct__mean')} | {_f('M15_SOCR_tau0.30_pct__mean')} | "
              f"{_f('M17_ESU__mean', 3)} | {_f('M9_realized_completion_rate_pct__mean')} | {_f('M1_mean_e2e_latency_s__mean', 3)} | "
              f"{_f('M3_deadline_violation_rate_pct__mean')} | {_f('M13_admission_rate_pct__mean')} | "
              f"{_f('M6_mean_selected_z__mean')} | {_f('M4_mean_reversal_probability__mean', 3)} |")
        a("")
    else:
        a("No experiments were run in this invocation.\n")
    a("## 10. Statistical Analysis\n")
    a("CIs computed across the seed-level metric values, NOT across individual tasks.\n")
    a("## 11. Runtime\n")
    a(f"Total pipeline runtime: {runtime_seconds:.1f} s ({runtime_seconds/60:.2f} min).\n")
    with open(out_path, "w") as f:
        f.write("\n".join(lines))
    print(f"Wrote {out_path}")


# =============================================================================
# SECTION 18: CLI
# =============================================================================
def parse_args(argv=None):
    p = argparse.ArgumentParser(description="FARO-IoT v3 pipeline (single file)")
    p.add_argument("--dataset", default=os.environ.get("FARO_DATASET"),
                   help="Path to DNN-EdgeIIoT-dataset.csv (or $FARO_DATASET)")
    p.add_argument("--mode", choices=["test500", "full"], default="full")
    p.add_argument("--profile", choices=["smoke", "quick", "full"], default="full",
                   help="smoke: 2k tasks, seed 1, no sensitivity (minutes); "
                        "quick: 100k tasks, seeds 1-2, sensitivity on; full: everything.")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--seed", type=int, action="append", default=None)
    p.add_argument("--workload", action="append", default=None, choices=WORKLOAD_NAMES)
    p.add_argument("--algorithm", action="append", default=None, type=_algo_name,
                   help="Policy name (see ALGORITHMS), or SafeSlack, SafeProb-<theta>, QueueCap-<k>, TS-Bandit-masked-5arms")
    p.add_argument("--tie-mode", choices=["spread", "none", "random"], default=None)
    p.add_argument("--demand-cv", type=float, default=None)
    p.add_argument("--jitter-sigma", type=float, default=None)
    p.add_argument("--ext-eta", type=float, default=None, help="v6 toll weight for FARO-IoT (tuned on dev seeds)")
    p.add_argument("--queue-est", choices=["count", "work"], default=None)
    p.add_argument("--admit-rule", choices=["utility", "nolat", "nolatrisk"], default=None)
    p.add_argument("--toll-form", choices=["own", "work"], default=None)
    p.add_argument("--debug-tasks", type=int, default=None)
    p.add_argument("--in-memory", action="store_true")
    p.add_argument("--flush-every", type=int, default=50_000)
    p.add_argument("--sensitivity-workload", action="append", default=None, choices=WORKLOAD_NAMES,
                   help="Repeatable. Default: MEDIUM and HEAVY.")
    p.add_argument("--skip-sensitivity", action="store_true")
    p.add_argument("--sensitivity-params", default=None,
                   help="Comma list of sweeps to run (c_rev,q,rho_D,lambda_b,beta_miss). Default: all.")
    p.add_argument("--beta", type=float, default=None, help="Override BETA_MISS for FARO-IoT/NoCal/NoTau.")
    p.add_argument("--results-dir", default=None, help="Override results/ figures/ manifests root.")
    # v4 switches
    p.add_argument("--dataset-kind", choices=["auto", "edgeiiot", "toniot", "generic"], default="auto")
    p.add_argument("--ts-col", default=None); p.add_argument("--payload-col", default=None)
    p.add_argument("--max-tasks", type=int, default=None, help="First N chronological tasks (contiguous window).")
    p.add_argument("--chain", choices=["shared", "independent"], default=None)
    p.add_argument("--block-capacity", type=int, default=None)
    p.add_argument("--deadline-mode", choices=["risk", "independent", "sizefree"], default=None)
    p.add_argument("--budget-range", type=float, nargs=2, default=None, metavar=("LO", "HI"))
    p.add_argument("--load-scale", type=float, default=None)
    p.add_argument("--penalty-mode", choices=["congestion", "load", "fixed"], default=None,
                   help="FARO-IoT miss penalty: congestion-attributable (default), load-scaled, or fixed beta")
    p.add_argument("--risk-profile", choices=["standard", "stringent"], default=None)
    p.add_argument("--q", type=float, default=None, help="Adversarial share used by the policies.")
    p.add_argument("--q-true", type=float, default=None, help="Adversarial share used only for evaluation.")
    p.add_argument("--lambda-b", type=float, default=None)
    p.add_argument("--per-task-seeds", default=None, help="Comma list of seeds that write per-task logs, or 'none'.")
    p.add_argument("--no-per-task", action="store_true")
    p.add_argument("--workers", type=int, default=None,
                    help="Process-based workers for the main experiment matrix (Section 12b). "
                         "Default: computed conservatively from CPU count and available RAM, "
                         "capped at 8 (see default_worker_count()). --workers 1 uses the "
                         "original unmodified sequential path.")
    args = p.parse_args(argv)
    if not args.sensitivity_workload:
        args.sensitivity_workload = ["MEDIUM", "HEAVY"]
    if not args.dataset:
        p.error("--dataset is required (or set FARO_DATASET)")
    if args.profile == "smoke":
        args.debug_tasks = args.debug_tasks or 2000
        args.seed = args.seed or [1]
        args.skip_sensitivity = True
        args.in_memory = True
    elif args.profile == "quick":
        args.debug_tasks = args.debug_tasks or 100_000
        args.seed = args.seed or [1, 2]
    return args


def _apply_runtime_overrides(args) -> None:
    """Apply CLI overrides to module-level settings BEFORE any worker forks."""
    global BETA_MISS, SEEDS, _SENSITIVITY_PARAM_FILTER
    global CHAIN_MODE, BLOCK_CAPACITY, DEADLINE_MODE, INDEP_BUDGET_RANGE, LOAD_SCALE, RISK_PROFILE
    global DEFAULT_Q, Q_TRUE, DEFAULT_LAMBDA_B, PER_TASK_SEEDS, NO_PER_TASK, PENALTY_MODE
    global TIE_MODE, DEMAND_CV, COMPUTE_JITTER_SIGMA, EXT_ETA, QUEUE_EST, ADMIT_RULE, TOLL_FORM
    if getattr(args, "toll_form", None):
        TOLL_FORM = register("v6.toll_form.override", args.toll_form, "enum", "S", "CLI", "")
    if getattr(args, "admit_rule", None):
        ADMIT_RULE = register("v6.admit_rule.override", args.admit_rule, "enum", "S", "CLI", "")
    if getattr(args, "ext_eta", None) is not None:
        EXT_ETA = register("v6.ext_eta.override", float(args.ext_eta), "dimensionless", "S", "CLI", "")
    if getattr(args, "queue_est", None):
        QUEUE_EST = register("v6.queue_est.override", args.queue_est, "enum", "S", "CLI", "")
    if getattr(args, "tie_mode", None):
        TIE_MODE = register("v5.tie_mode.override", args.tie_mode, "enum", "S", "CLI", "")
    if getattr(args, "demand_cv", None) is not None:
        DEMAND_CV = register("v5.demand_cv.override", float(args.demand_cv), "cv", "S", "CLI", "")
    if getattr(args, "jitter_sigma", None) is not None:
        COMPUTE_JITTER_SIGMA = register("environment.compute_jitter_sigma.override", float(args.jitter_sigma),
                                        "log-scale sd", "S", "CLI", "")
    if getattr(args, "penalty_mode", None):
        PENALTY_MODE = register("v4.penalty_mode.override", args.penalty_mode, "enum", "S", "CLI", "")
    if args.chain:
        CHAIN_MODE = register("v4.chain_mode.override", args.chain, "enum", "S", "CLI --chain", "")
    if args.block_capacity is not None:
        BLOCK_CAPACITY = register("v4.block_capacity.override", int(args.block_capacity), "tx/block", "S", "CLI", "")
    if args.deadline_mode:
        DEADLINE_MODE = register("v4.deadline_mode.override", args.deadline_mode, "enum", "S", "CLI", "")
    if args.budget_range:
        INDEP_BUDGET_RANGE = register("v4.budget_range.override", list(args.budget_range), "s", "S", "CLI", "")
    if args.load_scale:
        LOAD_SCALE = register("v4.load_scale.override", float(args.load_scale), "x", "S", "CLI", "")
    if args.risk_profile:
        RISK_PROFILE = register("v4.risk_profile.override", args.risk_profile, "enum", "S", "CLI", "")
        if RISK_PROFILE == "stringent":
            for rc in RISK_CLASSES:
                rc["tau"] = STRINGENT_TAUS[rc["name"]]
    if args.q is not None:
        DEFAULT_Q = register("blockchain.q.override", float(args.q), "fraction", "S", "CLI --q", "")
    if args.q_true is not None:
        Q_TRUE = register("v4.q_true.override", float(args.q_true), "fraction", "S", "CLI --q-true", "")
    if args.lambda_b is not None:
        DEFAULT_LAMBDA_B = register("blockchain.lambda_b.override", float(args.lambda_b), "blocks/s", "S", "CLI", "")
    if args.no_per_task:
        NO_PER_TASK = True
    if args.per_task_seeds:
        PER_TASK_SEEDS = set() if args.per_task_seeds.lower() == "none" else {int(s) for s in args.per_task_seeds.split(",")}
    if args.sensitivity_params:
        _SENSITIVITY_PARAM_FILTER = set(s.strip() for s in args.sensitivity_params.split(",") if s.strip())
    if args.beta is not None:
        BETA_MISS = float(args.beta)
        register("faro3.beta_miss.override", BETA_MISS, "task-value units", "S", "CLI --beta", "")
    if args.results_dir:
        # All pipeline outputs (results/, figures/, manifests, report) are relative
        # paths, so an output root is selected by running inside it.
        args.dataset = os.path.abspath(args.dataset)
        os.makedirs(args.results_dir, exist_ok=True)
        os.chdir(args.results_dir)
    if args.seed:
        SEEDS = sorted(set(int(s) for s in args.seed))


def _run_test500(args):
    """Section 12/13: 500-task, seed-1-only FARO regression + baseline sanity."""
    trace, audit = load_trace(args.dataset, args.dataset_kind, args.ts_col, args.payload_col, args.max_tasks)
    trace = trace.iloc[:500].reset_index(drop=True)
    print(f"test500: using the first {len(trace)} chronological tasks from {args.dataset}.")

    print("=" * 78); print("VALIDATION TESTS"); print("=" * 78)
    val_df = run_all_tests()
    os.makedirs(RESULTS_DIR, exist_ok=True)
    val_df.to_csv(os.path.join(RESULTS_DIR, "validation_tests_500.csv"), index=False)
    print(val_df[["test_id", "test_name", "status"]].to_string(index=False))
    if has_critical_failure(val_df):
        print("\nBLOCKED — a CRITICAL validation test failed.", file=sys.stderr)
        sys.exit(1)

    print("=" * 78); print("FAIRNESS AUDIT"); print("=" * 78)
    fair_df = run_fairness_audit(os.path.join(RESULTS_DIR, "baseline_fairness_audit_500.csv"))
    print(fair_df.to_string(index=False))

    print("=" * 78); print("FARO-IoT 500-TASK / SEED-1 REGRESSION"); print("=" * 78)
    rows = []
    for workload in WORKLOAD_NAMES:
        cycles = WORKLOADS[workload]
        decide_fn, post = faro3_decide_factory(DEFAULT_Q, DEFAULT_LAMBDA_B, DEFAULT_C_REV, RHO_D, beta=BETA_MISS)
        metrics, _df = run_experiment(trace, cycles, decide_fn, DEFAULT_LAMBDA_B, seed=1,
                                       reporting_c_rev=DEFAULT_C_REV, q=DEFAULT_Q, post_update_fn=post,
                                       workload_name=workload, algorithm_name="FARO-IoT", keep_dataframe=True)
        row = dict(algorithm="FARO-IoT", workload=workload, seed=1); row.update(metrics); rows.append(row)
        print(f"{workload}: n={metrics['n_tasks']} admitted={metrics['n_admitted']} "
              f"mean_lat={metrics['M1_mean_e2e_latency_s']:.4f} p95={metrics['M2_p95_e2e_latency_s']:.4f} "
              f"violation={metrics['M3_deadline_violation_rate_pct']:.1f}% mean_z={metrics['M6_mean_selected_z']:.2f} "
              f"SOCR-req={metrics['M16_SOCR_req_pct']:.1f}% ESU={metrics['M17_ESU']:.3f} "
              f"placement={metrics['M8_placement_pct']}")

    print("=" * 78); print("ALL-ALGORITHM 500-TASK SANITY (seed 1)"); print("=" * 78)
    for workload in WORKLOAD_NAMES:
        cycles = WORKLOADS[workload]
        for algo in ALGORITHMS:
            if algo == "FARO-IoT":
                continue  # already above
            fn, post = _decide_fn_for(algo, DEFAULT_Q, DEFAULT_LAMBDA_B, DEFAULT_C_REV, RHO_D, beta=BETA_MISS)
            mm, _ = run_experiment(trace, cycles, fn, DEFAULT_LAMBDA_B, seed=1,
                                   reporting_c_rev=DEFAULT_C_REV, q=DEFAULT_Q, workload_name=workload,
                                   algorithm_name=algo, post_update_fn=post, keep_dataframe=True)
            row = dict(algorithm=algo, workload=workload, seed=1); row.update(mm); rows.append(row)
            print(f"{algo:22s} {workload:6s}: admitted={mm['n_admitted']}/{mm['n_tasks']} "
                  f"SOCR-req={mm['M16_SOCR_req_pct']:.1f}% ESU={mm['M17_ESU']:.3f} "
                  f"viol={mm['M3_deadline_violation_rate_pct']:.1f}% lat={mm['M1_mean_e2e_latency_s']:.3f}s")

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(RESULTS_DIR, "regression_results_500.csv"), index=False)
    export_provenance_table(os.path.join(RESULTS_DIR, "provenance_table_final.csv"))
    print("\ntest500 complete. See results/regression_results_500.csv, "
          "results/validation_tests_500.csv, results/baseline_fairness_audit_500.csv.")


def _run_full(args):
    t_pipeline_start = time.time()
    os.makedirs(RESULTS_DIR, exist_ok=True)
    os.makedirs(FIGURES_DIR, exist_ok=True)

    print("=" * 78); print("STEP 1: DATASET AUDIT"); print("=" * 78)
    trace, audit = load_trace(args.dataset, args.dataset_kind, args.ts_col, args.payload_col, args.max_tasks)
    if LOAD_SCALE and LOAD_SCALE != 1.0:
        trace["arrival_time"] = trace["arrival_time"] / float(LOAD_SCALE)
        print(f"--load-scale {LOAD_SCALE}: arrival intensity multiplied by {LOAD_SCALE}.")
    if args.debug_tasks:
        trace = trace.iloc[:args.debug_tasks].reset_index(drop=True)
        print(f"--debug-tasks {args.debug_tasks}: using the first {len(trace)} chronological tasks only.")
    export_audit_csv(audit, os.path.join(RESULTS_DIR, "dataset_audit_final.csv"))
    print(f"Loaded {audit.final_task_count:,} valid tasks (of {audit.raw_rows:,} raw rows); "
          f"trace duration {audit.trace_duration_s:.3f}s.")

    print("=" * 78); print("STEP 2: VALIDATION TESTS"); print("=" * 78)
    val_df = run_all_tests()
    val_df.to_csv(os.path.join(RESULTS_DIR, "validation_tests_final.csv"), index=False)
    print(val_df[["test_id", "test_name", "status"]].to_string(index=False))
    if has_critical_failure(val_df):
        print("\nPIPELINE BLOCKED — a CRITICAL validation test failed.", file=sys.stderr)
        sys.exit(1)

    print("=" * 78); print("STEP 3: BASELINE FAIRNESS AUDIT"); print("=" * 78)
    fair_df = run_fairness_audit(os.path.join(RESULTS_DIR, "baseline_fairness_audit.csv"))
    print(fair_df.to_string(index=False))
    if not fairness_all_pass(fair_df):
        print("\nPIPELINE BLOCKED — a fairness check failed.", file=sys.stderr)
        sys.exit(1)

    export_provenance_table(os.path.join(RESULTS_DIR, "provenance_table_final.csv"))

    print("=" * 78); print("STEP 4-8: MAIN EXPERIMENT MATRIX"); print("=" * 78)
    algos_run = args.algorithm or ALGORITHMS
    runs = [RunConfig(a, w, s) for a in algos_run for w in WORKLOAD_NAMES for s in SEEDS]
    if args.workload:
        runs = [r for r in runs if r.workload in args.workload]
    if args.seed:
        runs = [r for r in runs if r.seed in args.seed]
    workers = args.workers if args.workers is not None else default_worker_count(len(runs))
    print(f"Running {len(runs)} (algorithm x workload x seed) experiments "
          f"(full matrix = {len(full_experiment_matrix())}) with {workers} worker process(es)"
          f"{' [computed default]' if args.workers is None else ' [explicit --workers]'}.")
    if workers > 1:
        print(f"  (CPU cores available: {os.cpu_count()}; use --workers N to override, e.g. "
              f"--workers 12 or --workers 16 once this default has been validated on this "
              f"machine; --workers 1 forces the original sequential path.)")
    seed_level_df = run_matrix_parallel(trace, runs, workers=workers, in_memory=args.in_memory,
                                         flush_every=args.flush_every, resume=args.resume)

    print("=" * 78); print("STEP 9: SENSITIVITY ANALYSIS"); print("=" * 78)
    sweeps_by_wl = {}
    if args.skip_sensitivity:
        print("  --skip-sensitivity: skipped.")
        sweeps = {k: None for k in _sensitivity_grids()}
    else:
        for wl in args.sensitivity_workload:
            n_sens_points = len(full_sensitivity_matrix(wl, SEEDS))
            print(f"[{wl}] Running {n_sens_points} independent (parameter x grid_value x seed) sensitivity "
                  f"points with {workers} worker process(es).")
            sw = run_all_sweeps_parallel(trace, workload=wl, seeds=SEEDS, workers=workers, resume=args.resume)
            sweeps_by_wl[wl] = sw
            export_sensitivity_csvs(sw, out_dir=os.path.join(RESULTS_DIR, f"sensitivity_{wl}"))
        sweeps = sweeps_by_wl[args.sensitivity_workload[0]]
        export_sensitivity_csvs(sweeps)

    print("=" * 78); print("STEP 10: SEED-LEVEL STATISTICS"); print("=" * 78)
    export_seed_level(seed_level_df)
    stats = export_mean_std_ci(seed_level_df)

    print("=" * 78); print("STEP 11: TABLES"); print("=" * 78)
    build_table1_main_comparison(stats)
    build_table2_ablations(stats)
    table3 = build_table3_placement(seed_level_df)
    build_table4_finality(seed_level_df)
    build_table5_sensitivity_summary(sweeps)
    for wl, sw in sweeps_by_wl.items():
        build_table5_sensitivity_summary(sw, out_dir=os.path.join(RESULTS_DIR, f"sensitivity_{wl}"))
    build_table6_safe_ontime(stats)
    build_table7_risk_classes(seed_level_df)

    print("=" * 78); print("STEP 12: FIGURES"); print("=" * 78)
    generate_all_figures(stats, table3, sweeps, seed_level_df, sweeps_by_wl)

    print("=" * 78); print("STEP 13: FINAL REPORT"); print("=" * 78)
    write_final_report(audit, val_df, fair_df, seed_level_df, stats,
                        runtime_seconds=time.time() - t_pipeline_start, debug_tasks=args.debug_tasks)

    print("\nPipeline complete.")
    print("FARO-IoT COMPLETE PIPELINE READY FOR FULL EXECUTION" if not args.debug_tasks
          else "FARO-IoT debug/integration run complete.")


def main():
    args = parse_args()
    _apply_runtime_overrides(args)
    try:
        if args.mode == "test500":
            _run_test500(args)
        else:
            _run_full(args)
    except KeyboardInterrupt:
        print("\nInterrupted. Completed experiments are preserved in "
              f"{MANIFEST_PATH} and their per-task output files under "
              f"{RESULTS_DIR}/per_task/. Rerun the same command with --resume "
              "to continue from where this run stopped.", file=sys.stderr)
        sys.exit(130)


if __name__ == "__main__":
    main()
