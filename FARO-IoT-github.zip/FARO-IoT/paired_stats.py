#!/usr/bin/env python3
"""FARO-IoT v4 -- paired segment-level statistics.

Reads the per-run segment files written by faro_iot.py
(results/segments/<algo>__<WL>__seed<k>.npz: per contiguous trace segment
n, adm, socr, ontime, lat_sum, safe_lat_sum, lat_hist, safe_lat_hist, edges)
and reports, for FARO-IoT against each comparator and workload:

  * paired difference in SOCR_req (percentage points) with a 95 % CI from a
    stratified block bootstrap: within every seed the same 48 contiguous
    segments are resampled for BOTH policies (common random numbers make the
    segments paired), seeds are kept as strata;
  * latency non-inferiority against a pre-specified margin (default 10 %):
    ratio of mean latency (admitted tasks) and of p95 latency (merged
    histograms) FARO / comparator; non-inferior iff the upper 95 % bound of
    (ratio - 1) is below the margin. Reported both over all admitted tasks
    and over safe-on-time tasks (the admitted sets differ, so both matter).

Usage:
  python paired_stats.py --results-dir runs/v4/E1_main [--ref FARO-IoT]
         [--comparators RTD-adapted FixedDepth-2 ...] [--B 2000] [--margin 0.10]
Writes <results-dir>/results/PAIRED_STATS.csv and PAIRED_STATS.md.
"""
import argparse
import glob
import os
import re
import sys

import numpy as np
import pandas as pd

DEFAULT_COMPARATORS = ["RTD-adapted", "FixedDepth-1", "FixedDepth-2", "FixedDepth-3", "FixedDepth-4",
                       "FixedDepth-6", "FARO-v2", "TS-Bandit-masked", "TS-Bandit-adapted",
                       "FARO-IoT-FixedPenalty", "FARO-IoT-NoPenalty", "FARO-IoT-D", "FARO-IoT+Cal",
                       "Fang et al.-adapted", "SharpEdge-adapted"]
FNAME = re.compile(r"^(?P<algo>.+)__(?P<wl>[A-Z]+)__seed(?P<seed>\d+)\.npz$")


def safe_name(algo: str) -> str:
    # must match faro_iot.segments_path_for
    return algo.replace(" ", "_").replace(".", "").replace("+", "plus")


def load_segments(seg_dir: str):
    """{(safe_algo, WL, seed): dict of arrays}"""
    out = {}
    for f in glob.glob(os.path.join(seg_dir, "*.npz")):
        m = FNAME.match(os.path.basename(f))
        if not m:
            continue
        z = np.load(f)
        out[(m["algo"], m["wl"], int(m["seed"]))] = {k: z[k] for k in z.files}
    return out


def p95_from_hist(hist: np.ndarray, edges: np.ndarray) -> float:
    tot = hist.sum()
    if tot <= 0:
        return float("nan")
    cdf = np.cumsum(hist) / tot
    i = int(np.searchsorted(cdf, 0.95))
    i = min(i, len(hist) - 1)
    lo, hi = edges[i], edges[i + 1]
    prev = cdf[i - 1] if i > 0 else 0.0
    frac = (0.95 - prev) / max(cdf[i] - prev, 1e-12)
    return float(np.exp(np.log(lo) + frac * (np.log(hi) - np.log(lo))))  # log-spaced bins


def stats_from(a, idx):
    """Aggregate a policy's stacked segment arrays over the row index idx."""
    n = a["n"][idx].sum(); adm = a["adm"][idx].sum()
    sc = a["socr"][idx].sum()
    return dict(
        socr=100.0 * sc / max(n, 1),
        mean_lat=a["lat_sum"][idx].sum() / max(a["lat_hist"][idx].sum(), 1),
        mean_safe_lat=a["safe_lat_sum"][idx].sum() / max(sc, 1),
        p95=p95_from_hist(a["lat_hist"][idx].sum(0), a["edges"]),
        p95_safe=p95_from_hist(a["safe_lat_hist"][idx].sum(0), a["edges"]),
    )


def stack(runs, seeds):
    """Concatenate the segment arrays of the given seeds; returns arrays + seed label per row."""
    keys = ["n", "adm", "socr", "ontime", "lat_sum", "safe_lat_sum", "lat_hist", "safe_lat_hist"]
    out = {k: np.concatenate([runs[s][k] for s in seeds]) for k in keys}
    out["edges"] = runs[seeds[0]]["edges"]
    lab = np.concatenate([np.full(len(runs[s]["n"]), s) for s in seeds])
    return out, lab


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results-dir", required=True, help="run root that contains results/segments")
    ap.add_argument("--ref", default="FARO-IoT")
    ap.add_argument("--comparators", nargs="*", default=None)
    ap.add_argument("--B", type=int, default=2000)
    ap.add_argument("--margin", type=float, default=0.10)
    ap.add_argument("--seed", type=int, default=20260925)
    args = ap.parse_args()

    seg_dir = os.path.join(args.results_dir, "results", "segments")
    if not os.path.isdir(seg_dir):
        seg_dir = os.path.join(args.results_dir, "segments")
    allseg = load_segments(seg_dir)
    if not allseg:
        sys.exit(f"no segment files under {seg_dir}")
    present = sorted({k[0] for k in allseg})
    ref = safe_name(args.ref)
    if args.comparators:
        comps = [c for c in args.comparators if safe_name(c) in present and safe_name(c) != ref]
    else:  # every policy present in the run directory (names as stored in segment files)
        comps = [c for c in present if c != ref]
    wls = sorted({k[1] for k in allseg if k[0] == ref}, key=["LIGHT", "MEDIUM", "HEAVY"].index)
    rng = np.random.default_rng(args.seed)
    rows = []
    for wl in wls:
        ref_runs = {k[2]: v for k, v in allseg.items() if k[0] == ref and k[1] == wl}
        for comp in comps:
            c_runs = {k[2]: v for k, v in allseg.items() if k[0] == safe_name(comp) and k[1] == wl}
            seeds = sorted(set(ref_runs) & set(c_runs))
            if not seeds:
                continue
            A, lab = stack(ref_runs, seeds)
            C, _ = stack(c_runs, seeds)
            if len(A["n"]) != len(C["n"]) or not np.array_equal(A["n"], C["n"]):
                print(f"[warn] {wl} {comp}: segment task counts differ -> not paired, skipped")
                continue
            full = np.arange(len(A["n"]))
            sa, sc = stats_from(A, full), stats_from(C, full)
            strata = [np.where(lab == s)[0] for s in seeds]
            d_socr = np.empty(args.B); r_mean = np.empty(args.B); r_p95 = np.empty(args.B)
            r_mean_s = np.empty(args.B); r_p95_s = np.empty(args.B)
            for b in range(args.B):
                idx = np.concatenate([rng.choice(st, size=len(st), replace=True) for st in strata])
                xa, xc = stats_from(A, idx), stats_from(C, idx)
                d_socr[b] = xa["socr"] - xc["socr"]
                r_mean[b] = xa["mean_lat"] / xc["mean_lat"] - 1.0
                r_p95[b] = xa["p95"] / xc["p95"] - 1.0
                r_mean_s[b] = xa["mean_safe_lat"] / xc["mean_safe_lat"] - 1.0
                r_p95_s[b] = xa["p95_safe"] / xc["p95_safe"] - 1.0
            q = lambda v: (float(np.nanpercentile(v, 2.5)), float(np.nanpercentile(v, 97.5)))
            lo, hi = q(d_socr)
            rm, rp, rms, rps = q(r_mean), q(r_p95), q(r_mean_s), q(r_p95_s)
            rows.append(dict(
                workload=wl, comparator=comp, seeds=len(seeds), segments=len(full),
                SOCR_ref=sa["socr"], SOCR_comp=sc["socr"], dSOCR_pp=sa["socr"] - sc["socr"],
                dSOCR_lo=lo, dSOCR_hi=hi,
                SOCR_better=("yes" if lo > 0 else ("no (worse)" if hi < 0 else "n.s.")),
                meanlat_ratio_m1=sa["mean_lat"] / sc["mean_lat"] - 1.0, meanlat_hi=rm[1],
                p95_ratio_m1=sa["p95"] / sc["p95"] - 1.0, p95_hi=rp[1],
                safe_meanlat_ratio_m1=sa["mean_safe_lat"] / sc["mean_safe_lat"] - 1.0, safe_meanlat_hi=rms[1],
                safe_p95_ratio_m1=sa["p95_safe"] / sc["p95_safe"] - 1.0, safe_p95_hi=rps[1],
                latency_NI=("yes" if (rm[1] < args.margin and rp[1] < args.margin) else "no"),
                safe_latency_NI=("yes" if (rms[1] < args.margin and rps[1] < args.margin) else "no"),
            ))
    df = pd.DataFrame(rows)
    out_dir = os.path.join(args.results_dir, "results")
    os.makedirs(out_dir, exist_ok=True)
    df.to_csv(os.path.join(out_dir, "PAIRED_STATS.csv"), index=False)
    with open(os.path.join(out_dir, "PAIRED_STATS.md"), "w") as fh:
        fh.write(f"# Paired statistics: {args.ref} vs comparators\n\n")
        fh.write(f"Stratified block bootstrap (B={args.B}, strata = seeds, blocks = contiguous trace segments). "
                 f"Latency non-inferiority margin = {100 * args.margin:.0f}% on mean and p95 "
                 f"(upper 95% bound of ratio-1 must be below the margin).\n\n")
        if len(df):
            show = df[["workload", "comparator", "SOCR_ref", "SOCR_comp", "dSOCR_pp", "dSOCR_lo", "dSOCR_hi",
                       "SOCR_better", "meanlat_ratio_m1", "meanlat_hi", "p95_ratio_m1", "p95_hi", "latency_NI",
                       "safe_latency_NI"]].copy()
            for c in ["SOCR_ref", "SOCR_comp", "dSOCR_pp", "dSOCR_lo", "dSOCR_hi"]:
                show[c] = show[c].map(lambda v: f"{v:.2f}")
            for c in ["meanlat_ratio_m1", "meanlat_hi", "p95_ratio_m1", "p95_hi"]:
                show[c] = show[c].map(lambda v: f"{100 * v:+.1f}%")
            try:
                fh.write(show.to_markdown(index=False))
            except ImportError:  # tabulate not installed
                fh.write(show.to_string(index=False))
            fh.write("\n")
    with pd.option_context("display.width", 200, "display.max_columns", 30):
        print(df[["workload", "comparator", "dSOCR_pp", "dSOCR_lo", "dSOCR_hi", "SOCR_better",
                  "meanlat_ratio_m1", "meanlat_hi", "p95_hi", "latency_NI"]].round(3).to_string(index=False))
    print(f"\nwrote {out_dir}/PAIRED_STATS.csv and PAIRED_STATS.md")


if __name__ == "__main__":
    main()
