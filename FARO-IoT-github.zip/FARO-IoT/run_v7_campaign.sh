#!/usr/bin/env bash
# FARO-IoT v7 campaign: reviewer fixes on top of v6 (results in runs/v6 are kept and reused).
#   F03  size-aware baselines WorkCap-w and SizeGate-g        F04  wider tuning grids for every tuned baseline
#   F03b deadlines independent of task size (sizefree mode)    V9   bounded attacker share (rerun)
#   F02b toll validation by paired admit/reject counterfactuals
# FARO-IoT is unchanged (eta = 4 from v6); every experiment is re-run for FARO-IoT and the tuned baselines only,
# so paired intervals are computed inside each directory.
#
#   cd FARO-IoT
#   export FARO_DATASET=data/Edge_IIoTset/DNN-EdgeIIoT-dataset.csv
#   export UNSW_PATH=data/UNSW_NB15/unsw_nb15_trace.csv
#   nohup bash run_v7_campaign.sh > v7_campaign.log 2>&1 &
set -uo pipefail
PY=${PY:-python}
WORKERS=${WORKERS:-20}
ROOT=${ROOT:-runs/v7}
HERE=$(cd "$(dirname "$0")" && pwd); cd "$HERE"
DATA=$(realpath "${FARO_DATASET:?set FARO_DATASET}")
UNSW=${UNSW_PATH:-}; [[ -n "$UNSW" ]] && UNSW=$(realpath "$UNSW")
ONLY=${ONLY:-"T0 T V NEW TV"}
mkdir -p "$ROOT"
exec 9>"$ROOT/.lock"; flock -n 9 || { echo "another v7 campaign is running -- exit"; exit 1; }
want() { [[ " $ONLY " == *" $1 "* ]]; }
stamp() { date '+%F %T'; }
run_exp() {
  local name=$1 data=$2; shift 2; local dir="$ROOT/$name"
  if [[ -f "$dir/DONE" ]]; then echo "[$(stamp)] $name already done -- skip"; return 0; fi
  mkdir -p "$dir"; echo "[$(stamp)] >>> $name : $*"
  $PY faro_iot.py --dataset "$data" --profile full --workers "$WORKERS" --resume --results-dir "$dir" \
      --no-per-task --skip-sensitivity "$@" > "$dir/run.log" 2>&1
  if grep -q "Pipeline complete" "$dir/run.log"; then
    $PY paired_stats.py --results-dir "$dir" --B 2000 > "$dir/paired_stats.log" 2>&1 || true
    touch "$dir/DONE"; echo "[$(stamp)] <<< $name done"
  else echo "[$(stamp)] !!! $name FAILED -- see $dir/run.log"; tail -15 "$dir/run.log"; fi
}
S3=(--seed 1 --seed 2 --seed 3)

if want T0; then
  mkdir -p "$ROOT/T0_test500"
  ( cd "$ROOT/T0_test500" && $PY "$HERE/faro_iot.py" --dataset "$DATA" --mode test500 > run.log 2>&1 )
  grep -q "test500 complete" "$ROOT/T0_test500/run.log" || { echo "T0 FAILED"; tail -30 "$ROOT/T0_test500/run.log"; exit 1; }
  echo "[$(stamp)] T0 test500 passed (40 tests)"
fi

# T -- wider grids on development seeds 101-102, same three regimes and rule as v6
TUNE=(--seed 101 --seed 102
      --algorithm QueueCap-1 --algorithm QueueCap-2 --algorithm QueueCap-3 --algorithm QueueCap-4 --algorithm QueueCap-8
      --algorithm SafeProb-0.5 --algorithm SafeProb-0.7 --algorithm SafeProb-0.8 --algorithm SafeProb-0.9
      --algorithm SafeProb-0.95 --algorithm SafeProb-0.99
      --algorithm WorkCap-1 --algorithm WorkCap-2 --algorithm WorkCap-3 --algorithm WorkCap-4 --algorithm WorkCap-8
      --algorithm SizeGate-0.05 --algorithm SizeGate-0.1 --algorithm SizeGate-0.2 --algorithm SizeGate-0.4 --algorithm SizeGate-0.8)
if want T; then
  run_exp T_risk  "$DATA" "${TUNE[@]}"
  run_exp T_indep "$DATA" --deadline-mode independent --budget-range 0.5 4.0 "${TUNE[@]}"
  run_exp T_cv    "$DATA" --demand-cv 0.5 "${TUNE[@]}"
  $PY select_tuned_v7.py "$ROOT" || exit 1
fi
[[ -f "$ROOT/tuned.env" ]] || { echo "tuned.env missing: run stage T first"; exit 1; }
source "$ROOT/tuned.env"
echo "[$(stamp)] using eta=$ETA QueueCap-$KCAP SafeProb-$THETA WorkCap-$WCAP SizeGate-$GATE"
E=(--ext-eta "$ETA")
POL=(--algorithm FARO-IoT --algorithm "QueueCap-$KCAP" --algorithm "SafeProb-$THETA" --algorithm "WorkCap-$WCAP" --algorithm "SizeGate-$GATE")
CORE=("${POL[@]}" --algorithm FARO-IoT-NoToll --algorithm FARO-IoT-NoPenalty --algorithm RTD-adapted
      --algorithm FixedDepth-3 --algorithm TS-Bandit-masked --algorithm SafeSlack)

if want NEW; then   # new experiments first: deadlines independent of task size, and the missing V9 row
  run_exp V10_sizefree_cv0.0 "$DATA" "${E[@]}" --deadline-mode sizefree --budget-range 0.5 4.0 "${S3[@]}" "${CORE[@]}"
  run_exp V10_sizefree_cv0.5 "$DATA" "${E[@]}" --deadline-mode sizefree --budget-range 0.5 4.0 --demand-cv 0.5 "${S3[@]}" "${CORE[@]}"
  run_exp V10_sizefree_cv1.0 "$DATA" "${E[@]}" --deadline-mode sizefree --budget-range 0.5 4.0 --demand-cv 1.0 "${S3[@]}" "${CORE[@]}"
  run_exp V9_bounded_q "$DATA" "${E[@]}" --q 0.25 --q-true 0.25 --deadline-mode independent --budget-range 0.5 4.0 "${CORE[@]}"
fi

if want V; then     # every v6 experiment again, FARO-IoT and the four tuned baselines only
  run_exp V1_main  "$DATA" "${E[@]}" --q-true 0.25 "${POL[@]}"
  run_exp V2_indep "$DATA" "${E[@]}" --deadline-mode independent --budget-range 0.5 4.0 "${POL[@]}"
  [[ -n "$UNSW" && -e "$UNSW" ]] && run_exp V3_unsw "$UNSW" "${E[@]}" --dataset-kind toniot --max-tasks 2000000 "${POL[@]}"
  run_exp V4_stringent "$DATA" "${E[@]}" --risk-profile stringent --deadline-mode independent --budget-range 2 12 \
    --workload MEDIUM --workload HEAVY "${POL[@]}"
  for k in 4 16 64;    do run_exp "V5_MEDIUM_x$k" "$DATA" "${E[@]}" --load-scale $k --workload MEDIUM "${POL[@]}"; done
  for k in 0.25 0.5 2; do run_exp "V5_HEAVY_x$k"  "$DATA" "${E[@]}" --load-scale $k --workload HEAVY  "${POL[@]}"; done
  run_exp V5_LIGHT_x64 "$DATA" "${E[@]}" --load-scale 64 --workload LIGHT "${POL[@]}"
  run_exp V6_jitter0.5 "$DATA" "${E[@]}" --jitter-sigma 0.5 "${S3[@]}" "${POL[@]}"
  run_exp V6_jitter1.0 "$DATA" "${E[@]}" --jitter-sigma 1.0 "${S3[@]}" "${POL[@]}"
  run_exp V6_demand0.5 "$DATA" "${E[@]}" --demand-cv 0.5 "${S3[@]}" "${POL[@]}"
  run_exp V6_demand1.0 "$DATA" "${E[@]}" --demand-cv 1.0 "${S3[@]}" "${POL[@]}"
  if [[ -n "$UNSW" && -e "$UNSW" ]]; then
    run_exp V7_unsw_ties_none   "$UNSW" "${E[@]}" --dataset-kind toniot --max-tasks 2000000 --tie-mode none   "${S3[@]}" "${POL[@]}"
    run_exp V7_unsw_ties_random "$UNSW" "${E[@]}" --dataset-kind toniot --max-tasks 2000000 --tie-mode random "${S3[@]}" "${POL[@]}"
  fi
  for c in 40 80 160; do run_exp "V8_capacity$c" "$DATA" "${E[@]}" --block-capacity $c "${S3[@]}" "${POL[@]}"; done
  run_exp V8_chain_independent "$DATA" "${E[@]}" --chain independent "${S3[@]}" "${POL[@]}"
  run_exp V9_lambda_1.0 "$DATA" "${E[@]}" --lambda-b 1.0 --deadline-mode independent --budget-range 1 8  "${S3[@]}" "${POL[@]}"
  run_exp V9_lambda_0.5 "$DATA" "${E[@]}" --lambda-b 0.5 --deadline-mode independent --budget-range 2 16 "${S3[@]}" "${POL[@]}"
fi

if want TV; then    # toll validation: paired admit/reject counterfactuals (300k-task window, 3 seeds x 80 points)
  for cv in 0.0 1.0; do
    out="$ROOT/V12_toll_validation/toll_validation_cv$cv.csv"
    if [[ -f "$out" ]]; then echo "[$(stamp)] toll validation cv=$cv done -- skip"; continue; fi
    echo "[$(stamp)] >>> toll validation cv=$cv"
    $PY toll_validation.py --dataset "$DATA" --workers "$WORKERS" --demand-cv $cv --out "$out" \
      > "$ROOT/V12_toll_validation_cv$cv.log" 2>&1 && echo "[$(stamp)] <<< toll validation cv=$cv done" \
      || { echo "[$(stamp)] !!! toll validation cv=$cv FAILED"; tail -15 "$ROOT/V12_toll_validation_cv$cv.log"; }
  done
fi
echo "[$(stamp)] CAMPAIGN FINISHED -- zip with:  zip -r v7_results.zip $ROOT"
