# Data

The two traces are public but are not redistributed in this repository. Download them from their original
sources and place them as shown below. Both are used only as arrival processes: the arrival time and the
payload size of each record drive the simulation, and their attack labels are never read by any policy.

```
data/
├── Edge_IIoTset/
│   └── DNN-EdgeIIoT-dataset.csv
└── UNSW_NB15/
    ├── raw/UNSW-NB15_1.csv ... UNSW-NB15_4.csv
    └── unsw_nb15_trace.csv        <- created by prepare_unsw_nb15.py
```

## Edge-IIoTset

Ferrag et al., "Edge-IIoTset: A new comprehensive realistic cyber security dataset of IoT and IIoT
applications for centralized and federated learning", IEEE Access 10, 2022, https://doi.org/10.1109/ACCESS.2022.3165809

Use the file `DNN-EdgeIIoT-dataset.csv` from the dataset's "Selected dataset for ML and DL" folder.

- The packet timestamp (`frame.time`) gives the arrival time, and the TCP length (`tcp.len`) gives the payload.
- A strict parser discards 122,782 records whose timestamp does not match the expected format, which leaves 2,096,419 tasks.
- The timestamp holds the year and the time of day but no reliable calendar date. Arrivals are therefore placed on one 24-hour axis.

## UNSW-NB15

Moustafa and Slay, "UNSW-NB15: A comprehensive data set for network intrusion detection systems", MilCIS 2015,
https://doi.org/10.1109/MilCIS.2015.7348942

Download the four raw CSV files `UNSW-NB15_1.csv` to `UNSW-NB15_4.csv` (2,540,047 records), then build the trace:

```bash
python prepare_unsw_nb15.py data/UNSW_NB15/raw/UNSW-NB15_{1,2,3,4}.csv --out data/UNSW_NB15/unsw_nb15_trace.csv
```

The simulator is then run with `--dataset-kind toniot --max-tasks 2000000`:

- The flow start time gives the arrival time.
- The source bytes give the payload, clipped to 65,535 bytes.
- The first two million flows in time order are used.
