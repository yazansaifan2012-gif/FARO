# FARO-IoT v7 (28 Sep 2026): reviewer fixes

FARO-IoT itself is unchanged: eta = 4 and the same code path. v7 reproduces v6 exactly (checked).

| Reviewer point | Change |
|---|---|
| F03 | New size-aware baselines, both risk-feasible (depth z_req) with FCFS service: **WorkCap-w** excludes a tier whose committed nominal work plus the task's service exceeds w mean service times per server; **SizeGate-g** is RTD plus a hard gate on FARO-IoT's toll term, (s_i/S_r)·T_q·mean(1/D) ≤ g. |
| F03b | New `--deadline-mode sizefree`: D_i = rho_D·(edge time at the workload's nominal demand) + b_i, so D_i does not depend on the task's own demand. |
| F04 | Wider development grids: QueueCap {1,2,3,4,8}, SafeProb {0.5,…,0.99}, WorkCap {1,2,3,4,8}, SizeGate {0.05,…,0.8}. Same rule and dev seeds 101–102. |
| F02b | `toll_validation.py`: paired admit/reject counterfactuals (300k-task window, 3 seeds × 80 points, CV 0 and 1). Measures the change in other tasks' safe on-time completions against the toll FARO-IoT charges. |
| V9 | Bounded attacker share rerun; test 38 fixed. |
| Tests | Test 40 (WorkCap, size-free deadlines). 40/40 pass. |

Dev-seed smoke test (seed 101, 80k tasks, HEAVY): SizeGate comes close to FARO-IoT, e.g. 52.97 vs 52.28 at CV 0.5. The v7 campaign decides whether FARO-IoT adds value beyond the toll-shaped gate. If it does not, the contribution is narrowed accordingly.
