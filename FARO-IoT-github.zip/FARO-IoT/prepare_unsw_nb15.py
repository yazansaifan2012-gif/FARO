#!/usr/bin/env python3
"""Build the UNSW-NB15 arrival trace used by faro_iot.py from the four raw UNSW-NB15 CSV files.

The raw files (UNSW-NB15_1.csv ... UNSW-NB15_4.csv, 2,540,047 records in total) have no header row and
49 columns. The simulator needs one row per flow with:
    ts        flow start time in seconds (raw column 29, "stime")
    src_bytes source-to-destination bytes (raw column 8, "sbytes"); faro_iot.py clips it to 65,535 bytes
    label     raw column 49 (0 normal, 1 attack); never read by any policy
    type      raw column 48 ("attack_cat"); never read by any policy
Rows are sorted by start time. faro_iot.py --max-tasks 2000000 keeps the first two million in time order,
and --tie-mode controls how flows that share a one-second timestamp are spread.

Usage:
    python prepare_unsw_nb15.py data/UNSW_NB15/raw/UNSW-NB15_{1,2,3,4}.csv --out data/UNSW_NB15/unsw_nb15_trace.csv
"""
import argparse
import pandas as pd

STIME, SBYTES, ATTACK_CAT, LABEL = 28, 7, 47, 48   # zero-based column positions in the raw files


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("raw", nargs="+", help="raw UNSW-NB15_*.csv files")
    p.add_argument("--out", required=True, help="output trace CSV")
    a = p.parse_args()
    parts = []
    for f in a.raw:
        d = pd.read_csv(f, header=None, usecols=[SBYTES, STIME, ATTACK_CAT, LABEL], low_memory=False)
        parts.append(pd.DataFrame({
            "ts": pd.to_numeric(d[STIME], errors="coerce"),
            "src_bytes": pd.to_numeric(d[SBYTES], errors="coerce"),
            "label": pd.to_numeric(d[LABEL], errors="coerce"),
            "type": d[ATTACK_CAT].fillna("Normal").astype(str).str.strip().replace("", "Normal"),
        }))
        print(f"{f}: {len(d):,} records")
    t = pd.concat(parts, ignore_index=True).dropna(subset=["ts", "src_bytes"])
    t = t.sort_values("ts", kind="mergesort").reset_index(drop=True)
    t.to_csv(a.out, index=False)
    print(f"wrote {len(t):,} flows to {a.out} (time span {t.ts.iloc[-1] - t.ts.iloc[0]:,.0f} s)")


if __name__ == "__main__":
    main()
